#include "flightControlSystem_capi.h"
#include "flightControlSystem.h"
#include "flightControlSystem_private.h"
int_T nmtwkzsqud [ 2 ] ; static RegMdlInfo rtMdlInfo_flightControlSystem [
181 ] = { { "pjles00mjh" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , (
void * ) "flightControlSystem" } , { "hpijc0phcq" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "e3kwjfmtyq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "gnaa0kdq4f" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "clwgr5jdek" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "hb5mq1jp4d" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ibbiqytpnr" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "kgkmz2ehxp" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "lq5gtrqmfy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "i0nykibtoa" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "fpqg1jdlo0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "gabr0rnvjj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "dyc32xehtl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "gvrocgqiar" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "chqb5yk4na" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ohupmhckxo" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "indibvooxj" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "lwnnlvnhdo" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "hxh5tgi533" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "fj00x4sgwu" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "nqkihlj0vf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ckpmcwhwmu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "l5zi4xqiqo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "je33m1dqwd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "imbf3wrgri" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "orji2pbk05" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ezsua5bijx" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "omkirkweac" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "lrsxga1mux" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "edl35owv4q" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "jig1nknlld" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "npn1dfesfs" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "iffergcei1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "bsr3dujuk0" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "crxyn1tssm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "lwj4qypsny" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "bpvdgm2xq5" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "hrtts4l5bc" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "mqmoncitu3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "k5baggiqtb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "ei3m5g1hta" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "hn4i3fu15a" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "lbu5phzg3y" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "mtaqz0ggi1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "mfdtth4fkl" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "cn2vepzj0w" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "dfqhc4tws4" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ph1mky0ofs" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "femqyyfyjs" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "nu4qaxumex" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "dmp1xsadgu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "eo4bbte2ey" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "lhjbdsj2rjg" ,
MDL_INFO_NAME_MDLREF_DWORK , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"lhjbdsj2rj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "h5liyesltnn" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "k0lgy5kzmig" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "d2rcqsbpxyc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "kekotmnbk54" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "no25hyfktuo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ht3wudfgy2u" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "iesycof4wox" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "eev4eat4b5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "cspyln32yuv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "dhuzh5wmni3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "b1hr2q0zjhm" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "nllkaxiwhzw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ircitwx3zdm" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "h5liyesltn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "k0lgy5kzmi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "d2rcqsbpxy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "kekotmnbk5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "no25hyfktu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ht3wudfgy2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "iesycof4wo" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "cspyln32yu" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "dhuzh5wmni" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "b1hr2q0zjh" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "nllkaxiwhz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ircitwx3zd" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "b42rzqdx01" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "o2f5l50guo" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "m0l5se3ogg" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "bog0frvixl" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "o5hyd2bjrc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "pyvd4pdf3i" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "gwlyno50ln" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ha1ipjbq54" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "f4qzdbbxmw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "k3yxem35zg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "dw0zngvhyq" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "o0d2t1xos2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "oplbkbi520" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "eyt3piuhqz" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "kegjp2lgms" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "nwvibpjmp0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "lsjhvu4egy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "bxsrqc204k" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "ic5jb3movn" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "n4xf3lkvmk" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "cyp5v4ller" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "mr51bswvyz" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "otjykwnhb3" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( void * )
"Control System" } , { "o3myonyzve" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 ,
- 1 , ( void * ) "flightControlSystem" } , { "cbxjbqi34b" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "kwdvu5ctzj" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ng2z3yysbc" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "e0j2slboh1" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "geavflab1i" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "lc0erw2cz2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "flqbd5kc2h" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ifzbhw4mrw" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( void * )
"Enabled Subsystem" } , { "o1pgdacg0u" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "flightControlSystem" } , { "cxgwlvxv4s" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ofaogkyrt4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "alfdzl2fz1" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "gcledvfwzt" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "flsbajpzfi" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "aummrq21x4" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "dq3x4qvypw" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "phrpuocqmv" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( void * )
"MeasurementUpdate" } , { "itmfjpgv1o" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0
, - 1 , ( void * ) "flightControlSystem" } , { "dychmi5jvf" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "okzguhbnst" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "gjrgypdhn2" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "nsvs5ni5i5" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "b5nnaqep53" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "ghadbep3bb" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , 0 , ( void * ) "Geofencing error" } , { "flightControlSystem" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , 0 , ( NULL ) } , { "d0ohl2eoh0m" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "nmtwkzsqud" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "f51itwtzkqf" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT
, 0 , - 1 , ( void * ) "flightControlSystem" } , { "dqykr4eggmg" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "ksm0js2nhsy" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * )
"flightControlSystem" } , { "diqjpw4041" , MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT ,
0 , - 1 , ( void * ) "flightControlSystem" } , { "ipf5ube4r0" ,
MDL_INFO_ID_GLOBAL_RTW_CONSTRUCT , 0 , - 1 , ( void * ) "flightControlSystem"
} , { "parrot_ImageProcess1" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } ,
{ "struct_ySQ4RIodpBjWyWISwhI9L" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "struct_Ys0g6NvmxKEOD5COiDA9mC" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_OSJpyIZcrpXqReVWwh9iuG" , MDL_INFO_ID_DATA_TYPE , 0 , -
1 , ( NULL ) } , { "struct_p3FXZIgqtjF2uqDpmYjb6C" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , { "struct_OMRgDnJcZuQneKEj9vdTyD" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_q6UUpnZ4gTjFvULFx6Rxa" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) }
, { "struct_IZWOW0zYvpphl7qLgSfN7E" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_hxsmtt0xTZOLDNa2Rz7GAF" , MDL_INFO_ID_DATA_TYPE , 0 , -
1 , ( NULL ) } , { "struct_XRMsui9C07VjBvdq1msujB" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , { "struct_eAf0NJvzCY9HYTXF7bLNgB" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "SensorsBus" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_acquisition_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_vbat_SI_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_ultrasound_SI_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_list_echo_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_echo_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_pressure_SI_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_magn_mG_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_fifo_gyro_SI_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_gyro_SI_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "HAL_acc_SI_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "extraSensorData_t" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , { "CommandBus" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_AvomjewU2HlvpF63kpj0lG" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL )
} , { "struct_2mqQE0JqjEpoTe8fAZAulB" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_8SSZ93PxvPkADZcA4gG8MD" , MDL_INFO_ID_DATA_TYPE , 0 , -
1 , ( NULL ) } , { "struct_eFnp8sKFNJLN84XLbLzaFF" , MDL_INFO_ID_DATA_TYPE ,
0 , - 1 , ( NULL ) } , { "struct_FIfaVnupBjYAxo1EdNiDlF" ,
MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) } , {
"struct_eF5OUT33sX0T9pzS8027m" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , ( NULL ) }
, { "struct_X1tFsdWsY5fUn8DhZV5x2G" , MDL_INFO_ID_DATA_TYPE , 0 , - 1 , (
NULL ) } , { "struct_hE1099BMemg5OfzqcWAA6G" , MDL_INFO_ID_DATA_TYPE , 0 , -
1 , ( NULL ) } , { "mr_flightControlSystem_GetSimStateDisallowedBlocks" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_extractBitFieldFromCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheBitFieldToCellArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_restoreDataFromMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheDataToMxArrayWithOffset" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_extractBitFieldFromMxArray" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheBitFieldToMxArray" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_restoreDataFromMxArray" , MDL_INFO_ID_MODEL_FCN_NAME
, 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_cacheDataAsMxArray" , MDL_INFO_ID_MODEL_FCN_NAME , 0
, - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_RegisterSimStateChecksum" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"mr_flightControlSystem_SetDWork" , MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , (
void * ) "flightControlSystem" } , { "mr_flightControlSystem_GetDWork" ,
MDL_INFO_ID_MODEL_FCN_NAME , 0 , - 1 , ( void * ) "flightControlSystem" } , {
"flightControlSystem.h" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( NULL ) } , {
"flightControlSystem.c" , MDL_INFO_MODEL_FILENAME , 0 , - 1 , ( void * )
"flightControlSystem" } } ; ileg2v2ld1r b1hr2q0zjh = { 50.0 , 20U , 1400U ,
0.0 , 0.2 , 20.0 , { 0.0 , 0.0 } , 2.0 , { 50.0 , - 1.0 , 0.8 , 0.4 , 0.1 ,
0.0 , - 1.1 , { 0.00012F , 9.72E-5F } , { 0.006F , 0.00486F } , 0.1F , 0.0F ,
0.0F , 0.0F , 0.0F , - 0.5F , - 0.34906584F , - 0.02F , { 70.0F , 70.0F } ,
0.7F , 0.2F , 4.0F , { 0.003F , 0.00243F } , 0.5F , 0.34906584F , 0.02F ,
10.0F , 10.0F , 6.0F , 6.0F , 0.01F , 0.01F , 6.867F , 12.753F , - 0.4F ,
0.0F , 0.0F , 80.0F , 80.0F , 0.6F , 0.5F , 0.6F , 0.5F , 7.0F , 7.0F , 5.0F
, 5.0F , - 0.4F , 4294967295U , 4294967295U , 4294967295U , 1U , 800U ,
65535U , 100U , 0.0 , 0.0 , 0.0 , 0.0 , { 3.7568380197861018E-6 ,
1.1270514059358305E-5 , 1.1270514059358305E-5 , 3.7568380197861018E-6 } , {
1.0 , - 2.9371707284498907 , 2.8762997234793319 , - 0.939098940325283 } , 0.0
, 1.0E-5 , 0.0 , 1.0E-5 , 0.0 , 0.0 , 0.0 , { 2000.0 , 2000.0 } , 0.0 , 0.0 ,
1.0 , 1.0 , 0.0 , 0.5 , 600.0 , - 1.1 , 0.0 , 1.0 , 0.0 , 1.0 , { 1.0 , 0.0 ,
0.005 , 1.0 } , { 0.0 , 0.005 } , { 1.0 , 0.0 } , { 0.0026241420641871633 ,
0.0069776736071491688 , 0.0069776736071491688 , 0.037607692935055337 } , {
0.026590304322229058 , 0.06977673607149236 } , { 0.02624142064187163 ,
0.0697767360714917 } , 0.0 , { 0.0026948589925820388 , 0.0071657120718244521
, 0.0071657120718244521 , 0.03810769293505533 } , { 0.0 , 1.0 } , 0.0 , 0.0 ,
0.0005 , 0.1 , { - 0.046 , 0.0 } , { 0.0 , 0.0 , 9.81 } , {
1097.3834951572255 , - 30.388465402591859 , - 30.388465402591855 ,
7.2223686232128914 } , { 0.0011870943291829544 , - 3.2868164179443428E-5 } ,
{ 0.0011869299883620552 , - 3.2868164179443354E-5 } , { 1097.3834951572255 ,
- 30.388465402591859 , - 30.388465402591855 , 7.2223686232128914 } , {
0.0011870943291829544 , - 3.2868164179443428E-5 } , { 0.0011869299883620552 ,
- 3.2868164179443354E-5 } , 0.0 , { 0.0 , 0.0 , - 9.81 } , {
1.3281632400274306 , 0.0 , - 0.43210920795542973 , 0.0 , 0.0 ,
1.3281632400274306 , 0.0 , - 0.43210920795542984 , - 0.43210920795542979 ,
0.0 , 6.14734986237778 , 0.0 , 0.0 , - 0.43210920795542984 , 0.0 ,
6.14734986237778 } , { 0.066516189303360354 , 5.23402355848703E-19 , -
0.021605460397771867 , - 4.8628553107267881E-19 , 4.3622439914025292E-18 ,
0.066516189303360354 , - 4.5659075919712689E-17 , - 0.021605460397771864 } ,
{ 0.066408162001371535 , 0.0 , - 0.021605460397771489 , 0.0 , 0.0 ,
0.066408162001371535 , 0.0 , - 0.021605460397771493 } , 0.45F , 0.8F , 0.5F ,
{ - 1.0F , 1.0F } , 0.00228F , 0.0F , 0.0F , 0.0F , - 1.0F , 1.15F , 0.0F ,
0.0F , 0.005F , 0.0F , - 1.0F , 0.0832137167F , { 3.75683794E-6F ,
1.12705138E-5F , 1.12705138E-5F , 3.75683794E-6F } , { 1.0F , - 2.93717074F ,
2.87629962F , - 0.939098954F } , 0.0F , 0.005F , 0.0F , { 0.0F , 0.0F , 9.81F
, 0.0F , 0.0F , 0.0F } , { 0.994075298F , 0.996184587F , 1.00549F ,
1.00139189F , 0.993601203F , 1.00003F } , 0.0F , { 0.0264077242F ,
0.140531361F , 0.33306092F , 0.33306092F , 0.140531361F , 0.0264077242F } ,
0.101936802F , { 1.0F , 1.0F } , { 2.5915494F , - 0.591549456F } , 0.0F , {
1.0F , 1.0F } , { 2.5915494F , - 0.591549456F } , 0.0F , { 0.282124132F ,
1.27253926F , 2.42084408F , 2.42084408F , 1.27253926F , 0.282124132F } , {
1.0F , 2.22871494F , 2.52446198F , 1.57725322F , 0.54102242F , 0.0795623958F
} , 0.0F , - 1.0F , { 0.282124132F , 1.27253926F , 2.42084408F , 2.42084408F
, 1.27253926F , 0.282124132F } , { 1.0F , 2.22871494F , 2.52446198F ,
1.57725322F , 0.54102242F , 0.0795623958F } , 0.0F , 200.0F , 0.0F , 0.0F ,
0.005F , 0.0F , 2.0F , - 2.0F , 0.24F , - 0.61803F , 1.20204329F , -
1.20204329F , 0.005F , { 1.0F , 1.0F } , { 8.95774746F , - 6.95774698F } ,
0.0F , 0.005F , 0.005F , 0.0F , 0.52359879F , - 0.52359879F , 0.004F , 0.005F
, 0.0F , 0.0012F , 0.0F , 0.002F , - 1530.72681F , 500.0F , 10.0F , { 1.0F ,
- 1.0F , 1.0F , - 1.0F } , 1.0F , 1.0F , 0.002F , { 0.25F , 0.25F , 0.25F ,
0.25F , 103.573624F , - 103.573624F , 103.573624F , - 103.573624F , -
5.66592F , - 5.66592F , 5.66592F , 5.66592F , - 5.66592F , 5.66592F ,
5.66592F , - 5.66592F } , 0.0F , 0.0F , { 1.0F , 0.0F , - 0.005F , 1.0F } , {
0.005F , 0.0F } , { 1.0F , 0.0F } , 0.0F , { 1098.6875F , - 30.4245777F , -
30.4245777F , 7.22336864F } , { 1.0F , 0.0F , 0.0F , 1.0F } , { 0.0F , 0.0F }
, { 0.0F , 0.0F } , { 1.0F , 0.0F , 0.0F , 0.001F } , 924556.188F , { 0.0F ,
0.0F } , { 1.0F , 0.0F , - 0.005F , 1.0F } , { 0.005F , 0.0F } , { 1.0F ,
0.0F } , 0.0F , { 1098.6875F , - 30.4245777F , - 30.4245777F , 7.22336864F }
, { 1.0F , 0.0F , 0.0F , 1.0F } , { 0.0F , 0.0F } , { 0.0F , 0.0F } , { 1.0F
, 0.0F , 0.0F , 0.001F } , 924556.188F , { 0.0F , 0.0F } , 0.0F , 2.0F , {
1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 0.0F , 0.0F , - 0.005F , 0.0F ,
1.0F , 0.0F , 0.0F , - 0.005F , 0.0F , 1.0F } , { 0.005F , 0.0F , 0.0F , 0.0F
, 0.0F , 0.005F , 0.0F , 0.0F } , { 1.0F , 0.0F , 0.0F , 1.0F , 0.0F , 0.0F ,
0.0F , 0.0F } , { 0.0F , 0.0F , 0.0F , 0.0F } , { 1.42263806F , 0.0F , -
0.462845951F , 0.0F , 0.0F , 1.42263806F , 0.0F , - 0.462845951F , -
0.462845951F , 0.0F , 6.15735F , 0.0F , 0.0F , - 0.462845951F , 0.0F ,
6.15735F } , { 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 1.0F , 0.0F , 0.0F , 0.0F , 0.0F , 1.0F } , { 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.0F , 0.0F } , { 0.0F , 0.0F , 0.0F , 0.0F , 0.0F ,
0.0F , 0.0F , 0.0F } , { 0.09F , 0.0F , 0.0F , 0.0F , 0.0F , 0.09F , 0.0F ,
0.0F , 0.0F , 0.0F , 0.01F , 0.0F , 0.0F , 0.0F , 0.0F , 0.01F } , { 20.0F ,
0.0F , 0.0F , 20.0F } , { 0.0F , 0.0F , 0.0F , 0.0F } , 0U , 0U , 0U , 1U ,
0U , 1U , 0U , 1U , 0U , 0U , 1U , 0U , 1 , 1 , 1U , 1U , 0U , 0U , 0U , {
0.0F } , { 0.0F } , { 0.0F } , { 0.0F } , { 0U } , { 0U } , { 0U } , { 99U }
, { 1U } } } ; lhjbdsj2rjg lhjbdsj2rj ; ircitwx3zdm ksm0js2nhsy ; nllkaxiwhzw
dqykr4eggmg ; cspyln32yuv f51itwtzkqf ; static boolean_T e4uq03sdk2 (
bjqsgn0csy * obj ) ; static void llg2sedmqv ( uint8_T varargout_1 [ 19200 ] ,
uint8_T varargout_2 [ 19200 ] , uint8_T varargout_3 [ 19200 ] ) ; static void
bljpfp3pka ( bjqsgn0csy * obj , uint8_T varargout_1 [ 19200 ] , uint8_T
varargout_2 [ 19200 ] , uint8_T varargout_3 [ 19200 ] ) ; void ghadbep3bb (
uint8_T * hfpztkhwej , bpvdgm2xq5 * localP ) { * hfpztkhwej = localP -> P_0 ;
} void gcledvfwzt ( orji2pbk05 * localB , je33m1dqwd * localP ) { localB ->
atkm3eb3zr [ 0 ] = localP -> P_0 ; localB -> atkm3eb3zr [ 1 ] = localP -> P_0
; } void alfdzl2fz1 ( orji2pbk05 * localB , imbf3wrgri * localDW , je33m1dqwd
* localP ) { localB -> atkm3eb3zr [ 0 ] = localP -> P_0 ; localB ->
atkm3eb3zr [ 1 ] = localP -> P_0 ; localDW -> jhr0womnye = false ; } void
phrpuocqmv ( ipf5ube4r0 * const accn4cnket , boolean_T hjrswm4ob0 , const
real32_T ndqlqfbq0n [ 2 ] , real32_T pp4ryk1bnn , const real32_T crftt4mdlv [
2 ] , const real32_T pc1pu0u41d [ 2 ] , real32_T kemszrfmdj , real32_T
k3tun14l4o , orji2pbk05 * localB , imbf3wrgri * localDW , je33m1dqwd * localP
) { real32_T aohxlltyk5 ; real32_T tmp ; if ( hjrswm4ob0 ) { if ( ! localDW
-> jhr0womnye ) { if ( rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart (
accn4cnket ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket ->
_mdlRefSfcnS ) ; } localDW -> jhr0womnye = true ; } tmp = crftt4mdlv [ 0 ] ;
aohxlltyk5 = crftt4mdlv [ 1 ] ; tmp *= pc1pu0u41d [ 0 ] ; tmp += aohxlltyk5 *
pc1pu0u41d [ 1 ] ; aohxlltyk5 = pp4ryk1bnn - ( kemszrfmdj * k3tun14l4o + tmp
) ; localB -> atkm3eb3zr [ 0 ] = ndqlqfbq0n [ 0 ] * aohxlltyk5 ; localB ->
atkm3eb3zr [ 1 ] = ndqlqfbq0n [ 1 ] * aohxlltyk5 ; srUpdateBC ( localDW ->
mkkaskumzr ) ; } else { if ( localDW -> jhr0womnye ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ;
alfdzl2fz1 ( localB , localDW , localP ) ; } } } void e0j2slboh1 ( dyc32xehtl
* localB , fpqg1jdlo0 * localP ) { localB -> dd1c4ibcll [ 0 ] = localP -> P_0
; localB -> dd1c4ibcll [ 1 ] = localP -> P_0 ; } void ng2z3yysbc ( dyc32xehtl
* localB , gabr0rnvjj * localDW , fpqg1jdlo0 * localP ) { localB ->
dd1c4ibcll [ 0 ] = localP -> P_0 ; localB -> dd1c4ibcll [ 1 ] = localP -> P_0
; localDW -> njk4w5jozv = false ; } void ifzbhw4mrw ( ipf5ube4r0 * const
accn4cnket , boolean_T ny1m4yhfkt , const real32_T izmwj1ddpc [ 2 ] , const
real32_T fppyei0jac [ 2 ] , real32_T fjag4trd4p , const real32_T fn1cyjs1o0 [
2 ] , dyc32xehtl * localB , gabr0rnvjj * localDW , fpqg1jdlo0 * localP ) {
real32_T mjzsyo5ls5 ; real32_T tmp ; if ( ny1m4yhfkt ) { if ( ! localDW ->
njk4w5jozv ) { if ( rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart (
accn4cnket ) ) { ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket ->
_mdlRefSfcnS ) ; } localDW -> njk4w5jozv = true ; } tmp = fppyei0jac [ 0 ] ;
mjzsyo5ls5 = fppyei0jac [ 1 ] ; tmp *= fn1cyjs1o0 [ 0 ] ; tmp += mjzsyo5ls5 *
fn1cyjs1o0 [ 1 ] ; mjzsyo5ls5 = fjag4trd4p - tmp ; localB -> dd1c4ibcll [ 0 ]
= izmwj1ddpc [ 0 ] * mjzsyo5ls5 ; localB -> dd1c4ibcll [ 1 ] = izmwj1ddpc [ 1
] * mjzsyo5ls5 ; srUpdateBC ( localDW -> ley0an2uip ) ; } else { if ( localDW
-> njk4w5jozv ) { ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket ->
_mdlRefSfcnS ) ; ng2z3yysbc ( localB , localDW , localP ) ; } } } void
ic5jb3movn ( eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex * localP
) { int32_T i ; localDW -> b3fmbw5stg [ 0 ] = localP -> P_119 ; localDW ->
b3fmbw5stg [ 1 ] = localP -> P_119 ; localDW -> dq5lalhp1e = 2 ; localDW ->
mi4mocbazh = localP -> P_56 ; localDW -> de4yc1bkky = 1U ; localDW ->
aq2aymvaio [ 0 ] = localP -> P_124 ; localDW -> ddv3ztj2wp [ 0 ] = localP ->
P_60 ; localDW -> aq2aymvaio [ 1 ] = localP -> P_124 ; localDW -> ddv3ztj2wp
[ 1 ] = localP -> P_60 ; localDW -> aq2aymvaio [ 2 ] = localP -> P_124 ;
localDW -> ddv3ztj2wp [ 2 ] = localP -> P_60 ; localDW -> dzwopklw3c = localP
-> P_126 ; localDW -> bbkjtf4kuy = 0 ; for ( i = 0 ; i < 15 ; i ++ ) {
localDW -> d4fp3a2mpz [ i ] = localP -> P_129 ; } localDW -> jd3dqtmo2p = 1U
; localDW -> f1jy25gy04 = 1U ; localDW -> l3lcputuyl = localP -> P_216 ;
localDW -> ncgo1wegzg = localP -> P_134 ; localDW -> mirtkskmtr = localP ->
P_137 ; for ( i = 0 ; i < 5 ; i ++ ) { localDW -> jduomia1pb [ i ] = localP
-> P_140 ; } localDW -> pjgu33zeph = localP -> P_217 ; localDW -> gdn4qfzvsk
= 1U ; for ( i = 0 ; i < 10 ; i ++ ) { localDW -> dqfv1m130o [ i ] = localP
-> P_144 ; } localDW -> gaxgdudnvc = localP -> P_225 ; localDW -> bsetqjfri4
= localP -> P_149 ; localDW -> fpr1qi0oiw = 2 ; localDW -> mh4zpxvxof =
localP -> P_62 ; localDW -> mlv55q4rs4 = localP -> P_64 ; localDW ->
c4kiksmhh2 = localP -> P_167 ; localDW -> dxm3w2i52x = localP -> P_218 ;
localDW -> bw2ribqmwm = localP -> P_65 ; localDW -> h3csutamah = localP ->
P_6 ; localDW -> pvooxnzvxd = localP -> P_66 ; localDW -> js3ly0p0tr = 0.0 ;
localDW -> gxd2vu1ibf = localP -> P_68 ; localDW -> fxisjak2ua = localP ->
P_234 ; localDW -> meognsjf1t [ 0 ] = localP -> P_10 ; localDW -> gcgpru4rcb
[ 0 ] = localP -> P_146 ; localDW -> peklmaellz [ 0 ] = localP -> P_147 ;
localDW -> dsjbzv2lh4 [ 0 ] = localP -> P_12 ; localDW -> gixvkpnpus [ 0 ] =
localP -> P_159 ; localDW -> ow5xb5ovt0 [ 0 ] = localP -> P_13 ; localDW ->
krs1cvkxzk [ 0 ] = localP -> P_11 ; localB -> ga0ou2qbzf [ 0 ] = localP ->
P_55 ; localDW -> meognsjf1t [ 1 ] = localP -> P_10 ; localDW -> gcgpru4rcb [
1 ] = localP -> P_146 ; localDW -> peklmaellz [ 1 ] = localP -> P_147 ;
localDW -> dsjbzv2lh4 [ 1 ] = localP -> P_12 ; localDW -> gixvkpnpus [ 1 ] =
localP -> P_159 ; localDW -> ow5xb5ovt0 [ 1 ] = localP -> P_13 ; localDW ->
krs1cvkxzk [ 1 ] = localP -> P_11 ; localB -> ga0ou2qbzf [ 1 ] = localP ->
P_55 ; e0j2slboh1 ( & localB -> ifzbhw4mrws , & localP -> ifzbhw4mrws ) ;
e0j2slboh1 ( & localB -> ipbtas1tys , & localP -> ipbtas1tys ) ; localB ->
hjgsbndjmh = localP -> P_111 ; localB -> a3za0mi1jb [ 0 ] = localP -> P_113 ;
localB -> a3za0mi1jb [ 1 ] = localP -> P_113 ; localB -> a3za0mi1jb [ 2 ] =
localP -> P_113 ; localB -> a3za0mi1jb [ 3 ] = localP -> P_113 ; localB ->
igogmbewdc = localP -> P_232 ; localB -> gisde2u3xx [ 0 ] = localP -> P_54 ;
localB -> gisde2u3xx [ 1 ] = localP -> P_54 ; gcledvfwzt ( & localB ->
phrpuocqmvu , & localP -> phrpuocqmvu ) ; gcledvfwzt ( & localB -> bm3dpymkhz
, & localP -> bm3dpymkhz ) ; localB -> n04moqscwc [ 0 ] = localP -> P_112 ;
localB -> n04moqscwc [ 1 ] = localP -> P_112 ; localB -> n04moqscwc [ 2 ] =
localP -> P_112 ; localB -> n04moqscwc [ 3 ] = localP -> P_112 ; } void
bxsrqc204k ( dmp1xsadgu * localDW , nu4qaxumex * localP ) { int32_T i ;
localDW -> b3fmbw5stg [ 0 ] = localP -> P_119 ; localDW -> b3fmbw5stg [ 1 ] =
localP -> P_119 ; localDW -> dq5lalhp1e = 2 ; localDW -> mi4mocbazh = localP
-> P_56 ; localDW -> de4yc1bkky = 1U ; localDW -> aq2aymvaio [ 0 ] = localP
-> P_124 ; localDW -> ddv3ztj2wp [ 0 ] = localP -> P_60 ; localDW ->
aq2aymvaio [ 1 ] = localP -> P_124 ; localDW -> ddv3ztj2wp [ 1 ] = localP ->
P_60 ; localDW -> aq2aymvaio [ 2 ] = localP -> P_124 ; localDW -> ddv3ztj2wp
[ 2 ] = localP -> P_60 ; localDW -> dzwopklw3c = localP -> P_126 ; localDW ->
bbkjtf4kuy = 0 ; for ( i = 0 ; i < 15 ; i ++ ) { localDW -> d4fp3a2mpz [ i ]
= localP -> P_129 ; } localDW -> jd3dqtmo2p = 1U ; localDW -> f1jy25gy04 = 1U
; localDW -> l3lcputuyl = localP -> P_216 ; localDW -> ncgo1wegzg = localP ->
P_134 ; localDW -> mirtkskmtr = localP -> P_137 ; for ( i = 0 ; i < 5 ; i ++
) { localDW -> jduomia1pb [ i ] = localP -> P_140 ; } localDW -> pjgu33zeph =
localP -> P_217 ; localDW -> gdn4qfzvsk = 1U ; for ( i = 0 ; i < 10 ; i ++ )
{ localDW -> dqfv1m130o [ i ] = localP -> P_144 ; } localDW -> gaxgdudnvc =
localP -> P_225 ; localDW -> bsetqjfri4 = localP -> P_149 ; localDW ->
fpr1qi0oiw = 2 ; localDW -> mh4zpxvxof = localP -> P_62 ; localDW ->
mlv55q4rs4 = localP -> P_64 ; localDW -> meognsjf1t [ 0 ] = localP -> P_10 ;
localDW -> gcgpru4rcb [ 0 ] = localP -> P_146 ; localDW -> peklmaellz [ 0 ] =
localP -> P_147 ; localDW -> dsjbzv2lh4 [ 0 ] = localP -> P_12 ; localDW ->
gixvkpnpus [ 0 ] = localP -> P_159 ; localDW -> ow5xb5ovt0 [ 0 ] = localP ->
P_13 ; localDW -> krs1cvkxzk [ 0 ] = localP -> P_11 ; localDW -> meognsjf1t [
1 ] = localP -> P_10 ; localDW -> gcgpru4rcb [ 1 ] = localP -> P_146 ;
localDW -> peklmaellz [ 1 ] = localP -> P_147 ; localDW -> dsjbzv2lh4 [ 1 ] =
localP -> P_12 ; localDW -> gixvkpnpus [ 1 ] = localP -> P_159 ; localDW ->
ow5xb5ovt0 [ 1 ] = localP -> P_13 ; localDW -> krs1cvkxzk [ 1 ] = localP ->
P_11 ; localDW -> c4kiksmhh2 = localP -> P_167 ; localDW -> dxm3w2i52x =
localP -> P_218 ; localDW -> bw2ribqmwm = localP -> P_65 ; localDW ->
h3csutamah = localP -> P_6 ; localDW -> pvooxnzvxd = localP -> P_66 ; localDW
-> js3ly0p0tr = 0.0 ; localDW -> gxd2vu1ibf = localP -> P_68 ; localDW ->
fxisjak2ua = localP -> P_234 ; } void kegjp2lgms ( eo4bbte2ey * localB ,
dmp1xsadgu * localDW , nu4qaxumex * localP ) { if ( localDW -> g4zcogq4xi ) {
localB -> gisde2u3xx [ 0 ] = localP -> P_54 ; localB -> gisde2u3xx [ 1 ] =
localP -> P_54 ; localDW -> g4zcogq4xi = false ; } if ( localDW -> iftedegxuv
) { localB -> ga0ou2qbzf [ 0 ] = localP -> P_55 ; localB -> ga0ou2qbzf [ 1 ]
= localP -> P_55 ; localDW -> iftedegxuv = false ; } if ( localDW ->
kh1khihcrt ) { localB -> n04moqscwc [ 0 ] = localP -> P_112 ; localB ->
n04moqscwc [ 1 ] = localP -> P_112 ; localB -> n04moqscwc [ 2 ] = localP ->
P_112 ; localB -> n04moqscwc [ 3 ] = localP -> P_112 ; localDW -> kh1khihcrt
= false ; } if ( localDW -> cqi2pi21ow ) { localB -> a3za0mi1jb [ 0 ] =
localP -> P_113 ; localB -> a3za0mi1jb [ 1 ] = localP -> P_113 ; localB ->
a3za0mi1jb [ 2 ] = localP -> P_113 ; localB -> a3za0mi1jb [ 3 ] = localP ->
P_113 ; localDW -> cqi2pi21ow = false ; } if ( localDW -> ifzbhw4mrws .
njk4w5jozv ) { ng2z3yysbc ( & localB -> ifzbhw4mrws , & localDW ->
ifzbhw4mrws , & localP -> ifzbhw4mrws ) ; } if ( localDW -> ipbtas1tys .
njk4w5jozv ) { ng2z3yysbc ( & localB -> ipbtas1tys , & localDW -> ipbtas1tys
, & localP -> ipbtas1tys ) ; } if ( localDW -> phrpuocqmvu . jhr0womnye ) {
alfdzl2fz1 ( & localB -> phrpuocqmvu , & localDW -> phrpuocqmvu , & localP ->
phrpuocqmvu ) ; } if ( localDW -> bm3dpymkhz . jhr0womnye ) { alfdzl2fz1 ( &
localB -> bm3dpymkhz , & localDW -> bm3dpymkhz , & localP -> bm3dpymkhz ) ; }
} void otjykwnhb3 ( ipf5ube4r0 * const accn4cnket , const CommandBus *
ipxpc4eli1 , const SensorsBus * fp0u5nlpgw , const real_T ay1xsyaztb [ 2 ] ,
eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex * localP , ph1mky0ofs
* localZCE ) { __m128 tmp ; __m128 tmp_e ; __m128 tmp_i ; __m128 tmp_p ; if (
localP -> P_229 && ( localDW -> dq5lalhp1e <= 0 ) ) { localDW -> b3fmbw5stg [
0 ] = localP -> P_119 ; localDW -> b3fmbw5stg [ 1 ] = localP -> P_119 ; }
localB -> ckkfajmco2_idx_0 = localDW -> b3fmbw5stg [ 0 ] ; localB ->
ckkfajmco2_idx_1 = localDW -> b3fmbw5stg [ 1 ] ; localB -> gldligh2fw = (
real_T ) localP -> P_120 * fp0u5nlpgw -> HALSensors . HAL_ultrasound_SI .
altitude ; localB -> mxbryllu15_merlcviukg = localB -> gldligh2fw ; localB ->
kt3nbu1y5w = ( localDW -> mi4mocbazh > localP -> P_5 ) ; if ( localB ->
kt3nbu1y5w ) { localDW -> de4yc1bkky = 1U ; } if ( localDW -> de4yc1bkky != 0
) { localDW -> mtonzezz2z [ 0 ] = localB -> bkasatad0l [ 0 ] ; localDW ->
mtonzezz2z [ 1 ] = localB -> bkasatad0l [ 1 ] ; } localB -> i4wbkrxufu_idx_0
= localDW -> mtonzezz2z [ 0 ] ; localB -> i4wbkrxufu_idx_1 = localDW ->
mtonzezz2z [ 1 ] ; localDW -> orkq4iljgu = ( ( ( ( fp0u5nlpgw -> HALSensors .
HAL_pressure_SI . pressure - fp0u5nlpgw -> SensorCalibration [ 6 ] ) * localP
-> P_121 - localP -> P_123 [ 1 ] * localDW -> aq2aymvaio [ 0 ] ) - localP ->
P_123 [ 2 ] * localDW -> aq2aymvaio [ 1 ] ) - localP -> P_123 [ 3 ] * localDW
-> aq2aymvaio [ 2 ] ) / localP -> P_123 [ 0 ] ; localB ->
avehkh15jm_dapv3jlyq5 = ( ( localP -> P_122 [ 0 ] * localDW -> orkq4iljgu +
localP -> P_122 [ 1 ] * localDW -> aq2aymvaio [ 0 ] ) + localP -> P_122 [ 2 ]
* localDW -> aq2aymvaio [ 1 ] ) + localP -> P_122 [ 3 ] * localDW ->
aq2aymvaio [ 2 ] ; localDW -> f2ynnmexgv = ( ( ( localB -> gldligh2fw -
localP -> P_59 [ 1 ] * localDW -> ddv3ztj2wp [ 0 ] ) - localP -> P_59 [ 2 ] *
localDW -> ddv3ztj2wp [ 1 ] ) - localP -> P_59 [ 3 ] * localDW -> ddv3ztj2wp
[ 2 ] ) / localP -> P_59 [ 0 ] ; if ( localB -> gldligh2fw > - rtP_Sensors .
altSensorMin ) { localB -> oxqfy2xq0w_m3yhjduhi1 = - rtP_Sensors .
altSensorMin ; } else if ( localB -> gldligh2fw < localP -> P_57 ) { localB
-> oxqfy2xq0w_m3yhjduhi1 = localP -> P_57 ; } else { localB ->
oxqfy2xq0w_m3yhjduhi1 = localB -> gldligh2fw ; } localB -> k5l3xnpjlj = ( (
muDoubleScalarAbs ( localDW -> mi4mocbazh - localB -> oxqfy2xq0w_m3yhjduhi1 )
<= localP -> P_4 ) && ( localB -> gldligh2fw < - rtP_Sensors . altSensorMin )
&& ( ( ! ( muDoubleScalarAbs ( localB -> avehkh15jm_dapv3jlyq5 - localDW ->
mi4mocbazh ) >= localP -> P_2 ) ) || ( ! ( muDoubleScalarAbs ( ( ( ( localP
-> P_58 [ 0 ] * localDW -> f2ynnmexgv + localP -> P_58 [ 1 ] * localDW ->
ddv3ztj2wp [ 0 ] ) + localP -> P_58 [ 2 ] * localDW -> ddv3ztj2wp [ 1 ] ) +
localP -> P_58 [ 3 ] * localDW -> ddv3ztj2wp [ 2 ] ) - localDW -> mi4mocbazh
) >= localP -> P_3 ) ) ) ) ; localB -> cud2lkfkrd_as0qznsxlv = localB ->
k5l3xnpjlj ; localB -> ponrkj5gat_ltu3syw14q = localB -> k5l3xnpjlj ; if (
localB -> ponrkj5gat_ltu3syw14q ) { if ( ! localDW -> iftedegxuv ) { if (
rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart ( accn4cnket ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ; }
localDW -> iftedegxuv = true ; } localB -> oxqfy2xq0w_m3yhjduhi1 = localB ->
mxbryllu15_merlcviukg - ( localP -> P_82 [ 0 ] * localB -> i4wbkrxufu_idx_0 +
localP -> P_82 [ 1 ] * localB -> i4wbkrxufu_idx_1 ) ; localB -> ga0ou2qbzf [
0 ] = localB -> nuftjfb4tr [ 0 ] * localB -> oxqfy2xq0w_m3yhjduhi1 ; localB
-> ga0ou2qbzf [ 1 ] = localB -> nuftjfb4tr [ 1 ] * localB ->
oxqfy2xq0w_m3yhjduhi1 ; srUpdateBC ( localDW -> mgysgsd2g4 ) ; } else { if (
localDW -> iftedegxuv ) { ssSetBlockStateForSolverChangedAtMajorStep (
accn4cnket -> _mdlRefSfcnS ) ; localB -> ga0ou2qbzf [ 0 ] = localP -> P_55 ;
localB -> ga0ou2qbzf [ 1 ] = localP -> P_55 ; localDW -> iftedegxuv = false ;
} } localB -> ijlsdczxaw [ 0 ] = localB -> ga0ou2qbzf [ 0 ] + localB ->
i4wbkrxufu_idx_0 ; localB -> ijlsdczxaw [ 1 ] = localB -> ga0ou2qbzf [ 1 ] +
localB -> i4wbkrxufu_idx_1 ; localB -> kbaevcigdn_bsqwvugooi = ( real32_T )
localB -> ijlsdczxaw [ 0 ] ; localB -> dyzwxnm2fa_lnjdk5wtww = localDW ->
dzwopklw3c ; for ( localB -> i = 0 ; localB -> i < 6 ; localB -> i ++ ) {
localB -> ovcwn4xiv0 [ localB -> i ] = fp0u5nlpgw -> SensorCalibration [
localB -> i ] + localP -> P_127 [ localB -> i ] ; } localB ->
izlb01spri_ezqlmfzvpq = localB -> ovcwn4xiv0 [ 0 ] ; localB ->
bwlsmegbgn_idx_0 = localB -> ovcwn4xiv0 [ 1 ] ; localB ->
kldfwzrldv_bjvjhhzy4i = localB -> ovcwn4xiv0 [ 2 ] ; localB ->
gcbzmq1psk_idx_1 = localB -> ovcwn4xiv0 [ 3 ] ; localB -> mpf5fynzwe_idx_0 =
localB -> ovcwn4xiv0 [ 4 ] ; localB -> emslsylcj0_bnlywzniup = localB ->
ovcwn4xiv0 [ 5 ] ; localB -> ovcwn4xiv0 [ 0 ] = fp0u5nlpgw -> HALSensors .
HAL_acc_SI . x - localB -> izlb01spri_ezqlmfzvpq ; localB -> ovcwn4xiv0 [ 1 ]
= fp0u5nlpgw -> HALSensors . HAL_acc_SI . y - localB -> bwlsmegbgn_idx_0 ;
localB -> ovcwn4xiv0 [ 2 ] = fp0u5nlpgw -> HALSensors . HAL_acc_SI . z -
localB -> kldfwzrldv_bjvjhhzy4i ; localB -> ovcwn4xiv0 [ 3 ] = fp0u5nlpgw ->
HALSensors . HAL_gyro_SI . x - localB -> gcbzmq1psk_idx_1 ; localB ->
ovcwn4xiv0 [ 4 ] = fp0u5nlpgw -> HALSensors . HAL_gyro_SI . y - localB ->
mpf5fynzwe_idx_0 ; localB -> ovcwn4xiv0 [ 5 ] = fp0u5nlpgw -> HALSensors .
HAL_gyro_SI . z - localB -> emslsylcj0_bnlywzniup ; for ( localB -> i = 0 ;
localB -> i < 6 ; localB -> i ++ ) { localB -> ovcwn4xiv0 [ localB -> i ] *=
localP -> P_128 [ localB -> i ] ; } localB -> acc1 = localB -> ovcwn4xiv0 [ 0
] * localP -> P_130 [ 0 ] ; localB -> cff = 1 ; localB -> i = localDW ->
bbkjtf4kuy ; while ( localB -> i < 5 ) { localB -> acc1 += localDW ->
d4fp3a2mpz [ localB -> i ] * localP -> P_130 [ localB -> cff ] ; localB ->
cff ++ ; localB -> i ++ ; } localB -> i = 0 ; while ( localB -> i < localDW
-> bbkjtf4kuy ) { localB -> acc1 += localDW -> d4fp3a2mpz [ localB -> i ] *
localP -> P_130 [ localB -> cff ] ; localB -> cff ++ ; localB -> i ++ ; }
localB -> f45tnce4lx_oyypvi4boh [ 0 ] = localB -> acc1 ; localB -> acc1 =
localB -> ovcwn4xiv0 [ 1 ] * localP -> P_130 [ 0 ] ; localB -> cff = 1 ;
localB -> i = localDW -> bbkjtf4kuy ; while ( localB -> i < 5 ) { localB ->
acc1 += localDW -> d4fp3a2mpz [ localB -> i + 5 ] * localP -> P_130 [ localB
-> cff ] ; localB -> cff ++ ; localB -> i ++ ; } localB -> i = 0 ; while (
localB -> i < localDW -> bbkjtf4kuy ) { localB -> acc1 += localDW ->
d4fp3a2mpz [ localB -> i + 5 ] * localP -> P_130 [ localB -> cff ] ; localB
-> cff ++ ; localB -> i ++ ; } localB -> f45tnce4lx_oyypvi4boh [ 1 ] = localB
-> acc1 ; localB -> acc1 = localB -> ovcwn4xiv0 [ 2 ] * localP -> P_130 [ 0 ]
; localB -> cff = 1 ; localB -> i = localDW -> bbkjtf4kuy ; while ( localB ->
i < 5 ) { localB -> acc1 += localDW -> d4fp3a2mpz [ localB -> i + 10 ] *
localP -> P_130 [ localB -> cff ] ; localB -> cff ++ ; localB -> i ++ ; }
localB -> i = 0 ; while ( localB -> i < localDW -> bbkjtf4kuy ) { localB ->
acc1 += localDW -> d4fp3a2mpz [ localB -> i + 10 ] * localP -> P_130 [ localB
-> cff ] ; localB -> cff ++ ; localB -> i ++ ; } localB ->
f45tnce4lx_oyypvi4boh [ 2 ] = localB -> acc1 ; localB ->
izlb01spri_ezqlmfzvpq = localP -> P_131 * localB -> f45tnce4lx_oyypvi4boh [ 0
] ; if ( localB -> izlb01spri_ezqlmfzvpq > 1.0F ) { localB ->
izlb01spri_ezqlmfzvpq = 1.0F ; } else { if ( localB -> izlb01spri_ezqlmfzvpq
< - 1.0F ) { localB -> izlb01spri_ezqlmfzvpq = - 1.0F ; } } localB ->
dmgkungty4 = muSingleScalarAsin ( localB -> izlb01spri_ezqlmfzvpq ) ; localB
-> jyapnrweub_jzx3amusab = localB -> dmgkungty4 ; if ( localDW -> jd3dqtmo2p
!= 0 ) { localDW -> fl0vv44tbs [ 0 ] = localB -> bacemjpimt [ 0 ] ; localDW
-> fl0vv44tbs [ 1 ] = localB -> bacemjpimt [ 1 ] ; } localB ->
nuftjfb4tr_dhamdvybc1 [ 0 ] = localDW -> fl0vv44tbs [ 0 ] ; localB ->
nuftjfb4tr_dhamdvybc1 [ 1 ] = localDW -> fl0vv44tbs [ 1 ] ; localB ->
izlb01spri_ezqlmfzvpq = muSingleScalarFloor ( localP -> P_204 ) ; if ( (
localB -> f45tnce4lx_oyypvi4boh [ 0 ] < 0.0F ) && ( localP -> P_204 > localB
-> izlb01spri_ezqlmfzvpq ) ) { localB -> kldfwzrldv_bjvjhhzy4i = -
muSingleScalarPower ( - localB -> f45tnce4lx_oyypvi4boh [ 0 ] , localP ->
P_204 ) ; } else { localB -> kldfwzrldv_bjvjhhzy4i = muSingleScalarPower (
localB -> f45tnce4lx_oyypvi4boh [ 0 ] , localP -> P_204 ) ; } if ( ( localB
-> f45tnce4lx_oyypvi4boh [ 1 ] < 0.0F ) && ( localP -> P_204 > localB ->
izlb01spri_ezqlmfzvpq ) ) { localB -> gcbzmq1psk_idx_1 = -
muSingleScalarPower ( - localB -> f45tnce4lx_oyypvi4boh [ 1 ] , localP ->
P_204 ) ; } else { localB -> gcbzmq1psk_idx_1 = muSingleScalarPower ( localB
-> f45tnce4lx_oyypvi4boh [ 1 ] , localP -> P_204 ) ; } if ( ( localB -> acc1
< 0.0F ) && ( localP -> P_204 > localB -> izlb01spri_ezqlmfzvpq ) ) { localB
-> mpf5fynzwe_idx_0 = - muSingleScalarPower ( - localB -> acc1 , localP ->
P_204 ) ; } else { localB -> mpf5fynzwe_idx_0 = muSingleScalarPower ( localB
-> acc1 , localP -> P_204 ) ; } localB -> kldfwzrldv_bjvjhhzy4i =
muSingleScalarSqrt ( ( localB -> kldfwzrldv_bjvjhhzy4i + localB ->
gcbzmq1psk_idx_1 ) + localB -> mpf5fynzwe_idx_0 ) ; localB -> jfniqoioih = (
int16_T ) ( ( localB -> kldfwzrldv_bjvjhhzy4i > localP -> P_31 ) && ( localB
-> kldfwzrldv_bjvjhhzy4i < localP -> P_32 ) ) ; localB ->
lhzpbdvr4c_ax3wx1gs5w = ( localB -> jfniqoioih != 0 ) ; localB ->
pg0cp3yfpb_ojunzewo4f = ( localB -> jfniqoioih != 0 ) ; ifzbhw4mrw (
accn4cnket , localB -> pg0cp3yfpb_ojunzewo4f , localB -> gijmevwnbh , localP
-> P_183 , localB -> jyapnrweub_jzx3amusab , localB -> nuftjfb4tr_dhamdvybc1
, & localB -> ifzbhw4mrws , & localDW -> ifzbhw4mrws , & localP ->
ifzbhw4mrws ) ; localB -> bcsdzee53f_guugdwf2m3 [ 0 ] = localB -> ifzbhw4mrws
. dd1c4ibcll [ 0 ] + localB -> nuftjfb4tr_dhamdvybc1 [ 0 ] ; localB ->
bcsdzee53f_guugdwf2m3 [ 1 ] = localB -> ifzbhw4mrws . dd1c4ibcll [ 1 ] +
localB -> nuftjfb4tr_dhamdvybc1 [ 1 ] ; localB -> oktwcxigco =
muSingleScalarAtan ( localB -> f45tnce4lx_oyypvi4boh [ 1 ] / localB -> acc1 )
; localB -> bkasatad0l_fdinthrxmb = localB -> oktwcxigco ; if ( localDW ->
f1jy25gy04 != 0 ) { localDW -> as5a0ikbk1 [ 0 ] = localB -> bzzzmlodjb [ 0 ]
; localDW -> as5a0ikbk1 [ 1 ] = localB -> bzzzmlodjb [ 1 ] ; } localB ->
nsadlikv0l_dypejvacrn [ 0 ] = localDW -> as5a0ikbk1 [ 0 ] ; localB ->
nsadlikv0l_dypejvacrn [ 1 ] = localDW -> as5a0ikbk1 [ 1 ] ; localB ->
fn3vhnol1t_evg4t2fsev = ( localB -> jfniqoioih != 0 ) ; localB ->
caj2lvvanz_o2tow3gxzm = ( localB -> jfniqoioih != 0 ) ; ifzbhw4mrw (
accn4cnket , localB -> caj2lvvanz_o2tow3gxzm , localB -> ika3nfqja0 , localP
-> P_194 , localB -> bkasatad0l_fdinthrxmb , localB -> nsadlikv0l_dypejvacrn
, & localB -> ipbtas1tys , & localDW -> ipbtas1tys , & localP -> ipbtas1tys )
; localB -> gcbzmq1psk_idx_1 = localB -> bcsdzee53f_guugdwf2m3 [ 0 ] ; localB
-> kldfwzrldv_bjvjhhzy4i = localB -> ipbtas1tys . dd1c4ibcll [ 0 ] + localB
-> nsadlikv0l_dypejvacrn [ 0 ] ; localB -> i24nn1hzbd_m3ybdk4ikc = localDW ->
l3lcputuyl ; if ( localB -> i24nn1hzbd_m3ybdk4ikc < localP -> P_51 ) { localB
-> mpf5fynzwe_idx_0 = fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 0 ] ;
localB -> emslsylcj0_bnlywzniup = fp0u5nlpgw -> VisionSensors .
opticalFlow_data [ 1 ] ; } else { localB -> emslsylcj0_bnlywzniup = localP ->
P_114 * localB -> kbaevcigdn_bsqwvugooi ; localB -> mpf5fynzwe_idx_0 =
fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 0 ] * localB ->
emslsylcj0_bnlywzniup * localP -> P_115 ; localB -> emslsylcj0_bnlywzniup =
fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 1 ] * localB ->
emslsylcj0_bnlywzniup * localP -> P_115 ; } localB -> izlb01spri_ezqlmfzvpq =
muSingleScalarAbs ( localB -> kbaevcigdn_bsqwvugooi ) ; localDW -> b1nmhkw4zo
= ( localB -> ovcwn4xiv0 [ 3 ] - localP -> P_133 [ 1 ] * localDW ->
ncgo1wegzg ) / localP -> P_133 [ 0 ] ; localB -> gchaygbwpg = localP -> P_132
[ 0 ] * localDW -> b1nmhkw4zo + localP -> P_132 [ 1 ] * localDW -> ncgo1wegzg
; localDW -> n0mydijbcx = ( localB -> ovcwn4xiv0 [ 4 ] - localP -> P_136 [ 1
] * localDW -> mirtkskmtr ) / localP -> P_136 [ 0 ] ; localB -> bevd1uolnu =
localP -> P_135 [ 0 ] * localDW -> n0mydijbcx + localP -> P_135 [ 1 ] *
localDW -> mirtkskmtr ; localDW -> iwg03owvar = 0.0F ; localB ->
k5j1weseip_idx_0 = localB -> ovcwn4xiv0 [ 5 ] ; localB -> denIdx = 1 ; for (
localB -> i = 0 ; localB -> i < 5 ; localB -> i ++ ) { localB ->
k5j1weseip_idx_0 -= localP -> P_139 [ localB -> denIdx ] * localDW ->
jduomia1pb [ localB -> i ] ; localB -> denIdx ++ ; } localDW -> iwg03owvar =
localB -> k5j1weseip_idx_0 / localP -> P_139 [ 0 ] ; localB ->
k5j1weseip_idx_0 = localP -> P_138 [ 0 ] * localDW -> iwg03owvar ; localB ->
denIdx = 1 ; for ( localB -> i = 0 ; localB -> i < 5 ; localB -> i ++ ) {
localB -> k5j1weseip_idx_0 += localP -> P_138 [ localB -> denIdx ] * localDW
-> jduomia1pb [ localB -> i ] ; localB -> denIdx ++ ; } localB ->
b0xkfl5szj_jacdjrqyev = localDW -> pjgu33zeph ; localB ->
piutssyltq_ifotjnizh4 = ( localB -> b0xkfl5szj_jacdjrqyev == localP -> P_50 )
; if ( ( ( localZCE -> b1rw3rggh2 == 1 ) != ( int32_T ) localB ->
piutssyltq_ifotjnizh4 ) && ( localZCE -> b1rw3rggh2 != 3 ) ) { localB ->
hjgsbndjmh = fp0u5nlpgw -> HALSensors . HAL_gyro_SI . temperature ; localDW
-> a1oodzfxvv = 4 ; } localZCE -> b1rw3rggh2 = localB ->
piutssyltq_ifotjnizh4 ; if ( localP -> P_231 == 1 ) { localB ->
oxqfy2xq0w_m3yhjduhi1 = ( fp0u5nlpgw -> HALSensors . HAL_gyro_SI .
temperature - localB -> hjgsbndjmh ) * localP -> P_110 ; } else { localB ->
oxqfy2xq0w_m3yhjduhi1 = localP -> P_101 ; } localB -> gc1nrupvnq = localB ->
k5j1weseip_idx_0 - ( real32_T ) localB -> oxqfy2xq0w_m3yhjduhi1 ; localB ->
bwlsmegbgn_idx_0 = localB -> gchaygbwpg - ( localB -> ipbtas1tys . dd1c4ibcll
[ 1 ] + localB -> nsadlikv0l_dypejvacrn [ 1 ] ) ; localB -> bwlsmegbgn_idx_1
= localB -> bevd1uolnu - localB -> bcsdzee53f_guugdwf2m3 [ 1 ] ; localB ->
bwlsmegbgn_idx_2 = localB -> gc1nrupvnq - localP -> P_203 ; localB ->
l5nzgayjhs [ 0 ] = localB -> izlb01spri_ezqlmfzvpq * localB ->
bwlsmegbgn_idx_1 * localP -> P_141 + localB -> mpf5fynzwe_idx_0 ; localB ->
l5nzgayjhs [ 1 ] = localB -> izlb01spri_ezqlmfzvpq * localB ->
bwlsmegbgn_idx_0 + localB -> emslsylcj0_bnlywzniup ; localB ->
bcsdzee53f_guugdwf2m3 [ 0 ] = localB -> l5nzgayjhs [ 0 ] ; localB ->
bcsdzee53f_guugdwf2m3 [ 1 ] = localB -> l5nzgayjhs [ 1 ] ; if ( localDW ->
gdn4qfzvsk != 0 ) { localDW -> od5c00niot [ 0 ] = localB ->
azizynqh5l_mbvzarwird [ 0 ] ; localDW -> od5c00niot [ 1 ] = localB ->
azizynqh5l_mbvzarwird [ 1 ] ; localDW -> od5c00niot [ 2 ] = localB ->
azizynqh5l_mbvzarwird [ 2 ] ; localDW -> od5c00niot [ 3 ] = localB ->
azizynqh5l_mbvzarwird [ 3 ] ; } localB -> bacemjpimt_jz50ptvnrg [ 0 ] =
localDW -> od5c00niot [ 0 ] ; localB -> bacemjpimt_jz50ptvnrg [ 1 ] = localDW
-> od5c00niot [ 1 ] ; localB -> bacemjpimt_jz50ptvnrg [ 2 ] = localDW ->
od5c00niot [ 2 ] ; localB -> bacemjpimt_jz50ptvnrg [ 3 ] = localDW ->
od5c00niot [ 3 ] ; localB -> hmjwwvohc0_mdoasc5av4 [ 0 ] = localB ->
gchaygbwpg ; localB -> hmjwwvohc0_mdoasc5av4 [ 1 ] = localB -> bevd1uolnu ;
for ( localB -> cff = 0 ; localB -> cff < 2 ; localB -> cff ++ ) { localB ->
memOffset = localB -> cff * 5 ; localB -> k5j1weseip_idx_0 = localB ->
hmjwwvohc0_mdoasc5av4 [ localB -> cff ] ; localB -> denIdx = 1 ; for ( localB
-> i = 0 ; localB -> i < 5 ; localB -> i ++ ) { localB -> k5j1weseip_idx_0 -=
localDW -> dqfv1m130o [ localB -> memOffset + localB -> i ] * localP -> P_143
[ localB -> denIdx ] ; localB -> denIdx ++ ; } localDW -> mf2pp40f5v [ localB
-> cff ] = localB -> k5j1weseip_idx_0 / localP -> P_143 [ 0 ] ; localB ->
k5j1weseip_idx_0 = localP -> P_142 [ 0 ] * localDW -> mf2pp40f5v [ localB ->
cff ] ; localB -> denIdx = 1 ; for ( localB -> i = 0 ; localB -> i < 5 ;
localB -> i ++ ) { localB -> k5j1weseip_idx_0 += localDW -> dqfv1m130o [
localB -> memOffset + localB -> i ] * localP -> P_142 [ localB -> denIdx ] ;
localB -> denIdx ++ ; } localB -> cf0jaxjxfg [ localB -> cff ] = localB ->
k5j1weseip_idx_0 * localP -> P_145 ; } localB -> i45e32y4nf_nuebgmauvi [ 0 ]
= localDW -> meognsjf1t [ 0 ] ; localB -> i45e32y4nf_nuebgmauvi [ 1 ] =
localDW -> meognsjf1t [ 1 ] ; localB -> oldi2l0fi3_bjbgfqrolh [ 0 ] = localB
-> cf0jaxjxfg [ 0 ] - localB -> i45e32y4nf_nuebgmauvi [ 0 ] ; localB ->
oldi2l0fi3_bjbgfqrolh [ 1 ] = localB -> cf0jaxjxfg [ 1 ] - localB ->
i45e32y4nf_nuebgmauvi [ 1 ] ; localB -> izlb01spri_ezqlmfzvpq =
muSingleScalarAbs ( localB -> gchaygbwpg ) ; localB -> k5j1weseip_idx_0 =
muSingleScalarAbs ( localB -> bevd1uolnu ) ; localB -> fr3qtkcajf = ( ( ( (
muSingleScalarAbs ( localB -> gcbzmq1psk_idx_1 ) <= localP -> P_38 ) && (
muSingleScalarAbs ( localB -> kldfwzrldv_bjvjhhzy4i ) <= localP -> P_40 ) &&
( localB -> izlb01spri_ezqlmfzvpq <= localP -> P_42 ) && ( localB ->
k5j1weseip_idx_0 <= localP -> P_43 ) && ( muSingleScalarAbs ( localB ->
oldi2l0fi3_bjbgfqrolh [ 0 ] ) <= localP -> P_36 ) && ( muSingleScalarAbs (
localB -> oldi2l0fi3_bjbgfqrolh [ 1 ] ) <= localP -> P_37 ) ) || ( ( localB
-> izlb01spri_ezqlmfzvpq <= localP -> P_39 ) && ( localB -> k5j1weseip_idx_0
<= localP -> P_41 ) ) ) && ( muSingleScalarAbs ( localB -> mpf5fynzwe_idx_0 -
localDW -> gcgpru4rcb [ 0 ] ) <= localP -> P_44 ) && ( muSingleScalarAbs (
localB -> emslsylcj0_bnlywzniup - localDW -> gcgpru4rcb [ 1 ] ) <= localP ->
P_45 ) && ( localB -> kbaevcigdn_bsqwvugooi <= localP -> P_46 ) ) ; localB ->
piutssyltq_ifotjnizh4 = localB -> fr3qtkcajf ; localB ->
mnpufinffy_ipgns4eet5 = localB -> fr3qtkcajf ; if ( localB ->
mnpufinffy_ipgns4eet5 ) { if ( ! localDW -> cqi2pi21ow ) { if (
rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart ( accn4cnket ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ; }
localDW -> cqi2pi21ow = true ; } for ( localB -> i = 0 ; localB -> i < 2 ;
localB -> i ++ ) { localB -> ika3nfqja0_ldqodwenvz [ localB -> i ] = localB
-> bcsdzee53f_guugdwf2m3 [ localB -> i ] - ( ( ( localP -> P_207 [ localB ->
i + 2 ] * localB -> bacemjpimt_jz50ptvnrg [ 1 ] + localP -> P_207 [ localB ->
i ] * localB -> bacemjpimt_jz50ptvnrg [ 0 ] ) + localP -> P_207 [ localB -> i
+ 4 ] * localB -> bacemjpimt_jz50ptvnrg [ 2 ] ) + localP -> P_207 [ localB ->
i + 6 ] * localB -> bacemjpimt_jz50ptvnrg [ 3 ] ) ; } for ( localB -> i = 0 ;
localB -> i <= 0 ; localB -> i += 4 ) { _mm_storeu_ps ( & localB ->
a3za0mi1jb [ localB -> i ] , _mm_set1_ps ( 0.0F ) ) ; tmp_e = _mm_loadu_ps (
& localB -> nz3dzltoa1 [ localB -> i ] ) ; tmp_i = _mm_loadu_ps ( & localB ->
a3za0mi1jb [ localB -> i ] ) ; _mm_storeu_ps ( & localB -> a3za0mi1jb [
localB -> i ] , _mm_add_ps ( _mm_mul_ps ( tmp_e , _mm_set1_ps ( localB ->
ika3nfqja0_ldqodwenvz [ 0 ] ) ) , tmp_i ) ) ; tmp_e = _mm_loadu_ps ( & localB
-> nz3dzltoa1 [ localB -> i + 4 ] ) ; tmp_i = _mm_loadu_ps ( & localB ->
a3za0mi1jb [ localB -> i ] ) ; _mm_storeu_ps ( & localB -> a3za0mi1jb [
localB -> i ] , _mm_add_ps ( _mm_mul_ps ( tmp_e , _mm_set1_ps ( localB ->
ika3nfqja0_ldqodwenvz [ 1 ] ) ) , tmp_i ) ) ; } srUpdateBC ( localDW ->
klyrn0mwhb ) ; } else { if ( localDW -> cqi2pi21ow ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ;
localB -> a3za0mi1jb [ 0 ] = localP -> P_113 ; localB -> a3za0mi1jb [ 1 ] =
localP -> P_113 ; localB -> a3za0mi1jb [ 2 ] = localP -> P_113 ; localB ->
a3za0mi1jb [ 3 ] = localP -> P_113 ; localDW -> cqi2pi21ow = false ; } }
localB -> lbhq3ilsyd [ 0 ] = localB -> a3za0mi1jb [ 0 ] + localB ->
bacemjpimt_jz50ptvnrg [ 0 ] ; localB -> lbhq3ilsyd [ 1 ] = localB ->
a3za0mi1jb [ 1 ] + localB -> bacemjpimt_jz50ptvnrg [ 1 ] ; localB ->
lbhq3ilsyd [ 2 ] = localB -> a3za0mi1jb [ 2 ] + localB ->
bacemjpimt_jz50ptvnrg [ 2 ] ; localB -> lbhq3ilsyd [ 3 ] = localB ->
a3za0mi1jb [ 3 ] + localB -> bacemjpimt_jz50ptvnrg [ 3 ] ;
muSingleScalarSinCos ( localB -> dyzwxnm2fa_lnjdk5wtww , & localB ->
k5j1weseip_idx_0 , & localB -> izlb01spri_ezqlmfzvpq ) ; muSingleScalarSinCos
( localB -> gcbzmq1psk_idx_1 , & localB -> k5j1weseip_idx_1 , & localB ->
dhojtjqasu_idx_1 ) ; muSingleScalarSinCos ( localB -> kldfwzrldv_bjvjhhzy4i ,
& localB -> k5j1weseip_idx_2 , & localB -> dhojtjqasu_idx_2 ) ; localB ->
fncl0arrzd_bhxxfovxdy [ 0 ] = localB -> dhojtjqasu_idx_1 * localB ->
izlb01spri_ezqlmfzvpq ; localB -> knhr21r5s4_hv2ho1zopz = localB ->
k5j1weseip_idx_2 * localB -> k5j1weseip_idx_1 ; localB ->
fncl0arrzd_bhxxfovxdy [ 1 ] = localB -> knhr21r5s4_hv2ho1zopz * localB ->
izlb01spri_ezqlmfzvpq - localB -> dhojtjqasu_idx_2 * localB ->
k5j1weseip_idx_0 ; localB -> fncl0arrzd_tmp = localB -> dhojtjqasu_idx_2 *
localB -> k5j1weseip_idx_1 ; localB -> fncl0arrzd_bhxxfovxdy [ 2 ] = localB
-> fncl0arrzd_tmp * localB -> izlb01spri_ezqlmfzvpq + localB ->
k5j1weseip_idx_2 * localB -> k5j1weseip_idx_0 ; localB ->
fncl0arrzd_bhxxfovxdy [ 3 ] = localB -> dhojtjqasu_idx_1 * localB ->
k5j1weseip_idx_0 ; localB -> fncl0arrzd_bhxxfovxdy [ 4 ] = localB ->
knhr21r5s4_hv2ho1zopz * localB -> k5j1weseip_idx_0 + localB ->
dhojtjqasu_idx_2 * localB -> izlb01spri_ezqlmfzvpq ; localB ->
fncl0arrzd_bhxxfovxdy [ 5 ] = localB -> fncl0arrzd_tmp * localB ->
k5j1weseip_idx_0 - localB -> k5j1weseip_idx_2 * localB ->
izlb01spri_ezqlmfzvpq ; localB -> fncl0arrzd_bhxxfovxdy [ 6 ] = - localB ->
k5j1weseip_idx_1 ; localB -> fncl0arrzd_bhxxfovxdy [ 7 ] = localB ->
k5j1weseip_idx_2 * localB -> dhojtjqasu_idx_1 ; localB ->
fncl0arrzd_bhxxfovxdy [ 8 ] = localB -> dhojtjqasu_idx_2 * localB ->
dhojtjqasu_idx_1 ; localB -> oxqfy2xq0w_m3yhjduhi1 = localDW -> peklmaellz [
0 ] ; localB -> ohjru33l3t_idx_1 = localDW -> peklmaellz [ 1 ] ; localB ->
dpbek0wdwu_czkfpwuzm5 = localB -> ijlsdczxaw [ 1 ] ; localB -> unnamed_idx_0
= localDW -> peklmaellz [ 0 ] ; localB -> unnamed_idx_1 = localDW ->
peklmaellz [ 1 ] ; localB -> unnamed_idx_2 = localB -> ijlsdczxaw [ 1 ] ; for
( localB -> i = 0 ; localB -> i < 3 ; localB -> i ++ ) { localB ->
glswd2nkcd_tmp = localB -> fncl0arrzd_bhxxfovxdy [ localB -> i + 3 ] ; localB
-> glswd2nkcd_tmp_ppxrqq0gsf = localB -> fncl0arrzd_bhxxfovxdy [ localB -> i
+ 6 ] ; localB -> glswd2nkcd_cv5hdgrwft [ localB -> i ] = localB ->
glswd2nkcd_tmp_ppxrqq0gsf * localB -> dpbek0wdwu_czkfpwuzm5 + ( localB ->
glswd2nkcd_tmp * localB -> ohjru33l3t_idx_1 + localB -> fncl0arrzd_bhxxfovxdy
[ localB -> i ] * localB -> oxqfy2xq0w_m3yhjduhi1 ) ; localB ->
fncl0arrzd_fqdqrf4qbc [ localB -> i ] = localB -> glswd2nkcd_tmp_ppxrqq0gsf *
localB -> unnamed_idx_2 + ( localB -> glswd2nkcd_tmp * localB ->
unnamed_idx_1 + localB -> fncl0arrzd_bhxxfovxdy [ localB -> i ] * localB ->
unnamed_idx_0 ) ; } localB -> dhojtjqasu_idx_2 = ( real32_T ) localB ->
fncl0arrzd_fqdqrf4qbc [ 2 ] ; localB -> nz3dzltoa1_cxarnvbvui [ 0 ] = localB
-> ckkfajmco2_idx_0 ; localB -> nz3dzltoa1_cxarnvbvui [ 1 ] = localB ->
ckkfajmco2_idx_1 ; localB -> nz3dzltoa1_cxarnvbvui [ 2 ] = localB ->
kbaevcigdn_bsqwvugooi ; localB -> nz3dzltoa1_cxarnvbvui [ 3 ] = localB ->
dyzwxnm2fa_lnjdk5wtww ; localB -> nz3dzltoa1_cxarnvbvui [ 4 ] = localB ->
gcbzmq1psk_idx_1 ; localB -> nz3dzltoa1_cxarnvbvui [ 5 ] = localB ->
kldfwzrldv_bjvjhhzy4i ; localB -> nz3dzltoa1_cxarnvbvui [ 6 ] = localB ->
lbhq3ilsyd [ 0 ] ; localB -> nz3dzltoa1_cxarnvbvui [ 7 ] = localB ->
lbhq3ilsyd [ 1 ] ; localB -> nz3dzltoa1_cxarnvbvui [ 8 ] = ( real32_T )
localB -> glswd2nkcd_cv5hdgrwft [ 2 ] ; localB -> nz3dzltoa1_cxarnvbvui [ 9 ]
= localB -> bwlsmegbgn_idx_0 ; localB -> nz3dzltoa1_cxarnvbvui [ 10 ] =
localB -> bwlsmegbgn_idx_1 ; localB -> nz3dzltoa1_cxarnvbvui [ 11 ] = localB
-> bwlsmegbgn_idx_2 ; localB -> e1xujwyd2e_p5h3gwuwqg = localDW -> gaxgdudnvc
; localB -> pl4id4anyh = ( localB -> e1xujwyd2e_p5h3gwuwqg < localP -> P_53 )
; localB -> j4053i5eeh_afnsueciae = ( uint16_T ) ( ( uint32_T ) localB ->
e1xujwyd2e_p5h3gwuwqg + localP -> P_226 ) ; if ( localB ->
j4053i5eeh_afnsueciae > localP -> P_52 ) { localB -> es1m4kbygh = localP ->
P_227 ; } else { localB -> es1m4kbygh = localB -> j4053i5eeh_afnsueciae ; }
if ( ( ! localB -> pl4id4anyh ) && ( localDW -> fpr1qi0oiw == 1 ) ) { localDW
-> bsetqjfri4 = localP -> P_149 ; } if ( localDW -> bsetqjfri4 >= localP ->
P_150 ) { localDW -> bsetqjfri4 = localP -> P_150 ; } else { if ( localDW ->
bsetqjfri4 <= localP -> P_151 ) { localDW -> bsetqjfri4 = localP -> P_151 ; }
} localB -> oxqfy2xq0w_m3yhjduhi1 = localP -> P_61 * ay1xsyaztb [ 1 ] ;
localB -> aulvpfmy14 = localB -> oxqfy2xq0w_m3yhjduhi1 + localDW ->
mh4zpxvxof ; localB -> oxqfy2xq0w_m3yhjduhi1 = localP -> P_63 * ay1xsyaztb [
0 ] ; localB -> azizynqh5l = localB -> oxqfy2xq0w_m3yhjduhi1 + localDW ->
mlv55q4rs4 ; localB -> knhr21r5s4_hv2ho1zopz = ( real32_T ) localP -> P_75 -
localB -> kbaevcigdn_bsqwvugooi ; localB -> csuamg3cf3 = localP -> P_152 *
localB -> knhr21r5s4_hv2ho1zopz ; localB -> k5j1weseip_idx_2 =
muSingleScalarSin ( localB -> dyzwxnm2fa_lnjdk5wtww ) ; localB ->
dhojtjqasu_idx_1 = muSingleScalarCos ( localB -> dyzwxnm2fa_lnjdk5wtww ) ;
localB -> k5j1weseip_idx_0 = ( real32_T ) localB -> aulvpfmy14 - localB ->
ckkfajmco2_idx_0 ; localB -> k5j1weseip_idx_1 = ( real32_T ) localB ->
azizynqh5l - localB -> ckkfajmco2_idx_1 ; localDW -> pwlp5beuqs [ 0U ] = 0.0F
; localB -> izlb01spri_ezqlmfzvpq = ( localB -> dhojtjqasu_idx_1 * localB ->
k5j1weseip_idx_0 + localB -> k5j1weseip_idx_2 * localB -> k5j1weseip_idx_1 )
* localP -> P_18 ; if ( localB -> izlb01spri_ezqlmfzvpq > localP -> P_22 ) {
localB -> izlb01spri_ezqlmfzvpq = localP -> P_22 ; } else { if ( localB ->
izlb01spri_ezqlmfzvpq < localP -> P_14 ) { localB -> izlb01spri_ezqlmfzvpq =
localP -> P_14 ; } } localB -> fncl0arrzd_tmp = localB ->
izlb01spri_ezqlmfzvpq - localB -> lbhq3ilsyd [ 0 ] ; localB -> kfvbhjiqtg [ 0
] = localP -> P_19 * localB -> fncl0arrzd_tmp + localDW -> dsjbzv2lh4 [ 0 ] ;
if ( localB -> kfvbhjiqtg [ 0 ] > localP -> P_23 ) { localB ->
izlb01spri_ezqlmfzvpq = localP -> P_23 ; } else if ( localB -> kfvbhjiqtg [ 0
] < localP -> P_15 ) { localB -> izlb01spri_ezqlmfzvpq = localP -> P_15 ; }
else { localB -> izlb01spri_ezqlmfzvpq = localB -> kfvbhjiqtg [ 0 ] ; }
localDW -> pwlp5beuqs [ 0 ] = ( localB -> izlb01spri_ezqlmfzvpq - localP ->
P_158 [ 1 ] * localDW -> gixvkpnpus [ 0 ] ) / localP -> P_158 [ 0 ] ; localB
-> ika3nfqja0_ldqodwenvz [ 0 ] = localB -> fncl0arrzd_tmp ; localB ->
izlb01spri_ezqlmfzvpq = ( - localB -> k5j1weseip_idx_2 * localB ->
k5j1weseip_idx_0 + localB -> dhojtjqasu_idx_1 * localB -> k5j1weseip_idx_1 )
* localP -> P_18 ; if ( localB -> izlb01spri_ezqlmfzvpq > localP -> P_22 ) {
localB -> izlb01spri_ezqlmfzvpq = localP -> P_22 ; } else { if ( localB ->
izlb01spri_ezqlmfzvpq < localP -> P_14 ) { localB -> izlb01spri_ezqlmfzvpq =
localP -> P_14 ; } } localB -> fncl0arrzd_tmp = localB ->
izlb01spri_ezqlmfzvpq - localB -> lbhq3ilsyd [ 1 ] ; localB -> kfvbhjiqtg [ 1
] = localP -> P_19 * localB -> fncl0arrzd_tmp + localDW -> dsjbzv2lh4 [ 1 ] ;
if ( localB -> kfvbhjiqtg [ 1 ] > localP -> P_23 ) { localB ->
izlb01spri_ezqlmfzvpq = localP -> P_23 ; } else if ( localB -> kfvbhjiqtg [ 1
] < localP -> P_15 ) { localB -> izlb01spri_ezqlmfzvpq = localP -> P_15 ; }
else { localB -> izlb01spri_ezqlmfzvpq = localB -> kfvbhjiqtg [ 1 ] ; }
localDW -> pwlp5beuqs [ 1 ] = ( localB -> izlb01spri_ezqlmfzvpq - localP ->
P_158 [ 1 ] * localDW -> gixvkpnpus [ 1 ] ) / localP -> P_158 [ 0 ] ; if (
localP -> P_229 ) { localB -> k5j1weseip_idx_2 = ( localP -> P_157 [ 0 ] *
localDW -> pwlp5beuqs [ 0 ] + localP -> P_157 [ 1 ] * localDW -> gixvkpnpus [
0 ] ) * localP -> P_109 [ 0 ] ; localB -> izlb01spri_ezqlmfzvpq = ( localP ->
P_157 [ 0 ] * localDW -> pwlp5beuqs [ 1 ] + localP -> P_157 [ 1 ] * localDW
-> gixvkpnpus [ 1 ] ) * localP -> P_109 [ 1 ] ; } else { localB ->
k5j1weseip_idx_2 = ipxpc4eli1 -> orient_ref [ 1 ] ; localB ->
izlb01spri_ezqlmfzvpq = ipxpc4eli1 -> orient_ref [ 2 ] ; } localB ->
k5j1weseip_idx_2 = ( localB -> k5j1weseip_idx_2 - localB -> gcbzmq1psk_idx_1
) * localP -> P_20 ; localB -> hmjwwvohc0_mdoasc5av4 [ 0 ] = localB ->
k5j1weseip_idx_2 - localB -> bwlsmegbgn_idx_1 ; localB ->
hmjwwvohc0_mdoasc5av4 [ 1 ] = ( localB -> izlb01spri_ezqlmfzvpq - localB ->
kldfwzrldv_bjvjhhzy4i ) * localP -> P_20 - localB -> bwlsmegbgn_idx_0 ;
localB -> jeehrr35n3 [ 0 ] = ( localP -> P_7 [ 0 ] * localB ->
hmjwwvohc0_mdoasc5av4 [ 0 ] - localDW -> krs1cvkxzk [ 0 ] ) * localP -> P_17
[ 0 ] ; localB -> bwlsmegbgn_idx_1 = ( localP -> P_21 [ 0 ] * localB ->
hmjwwvohc0_mdoasc5av4 [ 0 ] + localDW -> ow5xb5ovt0 [ 0 ] ) + localB ->
jeehrr35n3 [ 0 ] ; if ( localB -> bwlsmegbgn_idx_1 > localP -> P_24 ) {
localB -> dwa34yqvis [ 0 ] = localB -> bwlsmegbgn_idx_1 - localP -> P_24 ; }
else if ( localB -> bwlsmegbgn_idx_1 >= localP -> P_16 ) { localB ->
dwa34yqvis [ 0 ] = 0.0F ; } else { localB -> dwa34yqvis [ 0 ] = localB ->
bwlsmegbgn_idx_1 - localP -> P_16 ; } localB -> dhojtjqasu_idx_1 = localP ->
P_8 [ 0 ] * localB -> hmjwwvohc0_mdoasc5av4 [ 0 ] ; localB ->
izlb01spri_ezqlmfzvpq = muSingleScalarSign ( localB -> dwa34yqvis [ 0 ] ) ;
if ( muSingleScalarIsNaN ( localB -> izlb01spri_ezqlmfzvpq ) ) { localB ->
izlb01spri_ezqlmfzvpq = 0.0F ; } else { localB -> izlb01spri_ezqlmfzvpq =
muSingleScalarRem ( localB -> izlb01spri_ezqlmfzvpq , 256.0F ) ; } localB ->
bwlsmegbgn_idx_0 = muSingleScalarSign ( localB -> dhojtjqasu_idx_1 ) ; if (
muSingleScalarIsNaN ( localB -> bwlsmegbgn_idx_0 ) ) { localB ->
bwlsmegbgn_idx_0 = 0.0F ; } else { localB -> bwlsmegbgn_idx_0 =
muSingleScalarRem ( localB -> bwlsmegbgn_idx_0 , 256.0F ) ; } if ( ( localP
-> P_162 * localB -> bwlsmegbgn_idx_1 != localB -> dwa34yqvis [ 0 ] ) && ( (
localB -> izlb01spri_ezqlmfzvpq < 0.0F ? ( int32_T ) ( int8_T ) - ( int8_T )
( uint8_T ) - localB -> izlb01spri_ezqlmfzvpq : ( int32_T ) ( int8_T ) (
uint8_T ) localB -> izlb01spri_ezqlmfzvpq ) == ( localB -> bwlsmegbgn_idx_0 <
0.0F ? ( int32_T ) ( int8_T ) - ( int8_T ) ( uint8_T ) - localB ->
bwlsmegbgn_idx_0 : ( int32_T ) ( int8_T ) ( uint8_T ) localB ->
bwlsmegbgn_idx_0 ) ) ) { localB -> dwa34yqvis [ 0 ] = localP -> P_116 ; }
else { localB -> dwa34yqvis [ 0 ] = localB -> dhojtjqasu_idx_1 ; } if (
localB -> bwlsmegbgn_idx_1 > localP -> P_24 ) { localB -> k5j1weseip_idx_2 =
localP -> P_24 ; } else if ( localB -> bwlsmegbgn_idx_1 < localP -> P_16 ) {
localB -> k5j1weseip_idx_2 = localP -> P_16 ; } else { localB ->
k5j1weseip_idx_2 = localB -> bwlsmegbgn_idx_1 ; } localB -> jeehrr35n3 [ 1 ]
= ( localP -> P_7 [ 1 ] * localB -> hmjwwvohc0_mdoasc5av4 [ 1 ] - localDW ->
krs1cvkxzk [ 1 ] ) * localP -> P_17 [ 1 ] ; localB -> bwlsmegbgn_idx_1 = (
localP -> P_21 [ 1 ] * localB -> hmjwwvohc0_mdoasc5av4 [ 1 ] + localDW ->
ow5xb5ovt0 [ 1 ] ) + localB -> jeehrr35n3 [ 1 ] ; if ( localB ->
bwlsmegbgn_idx_1 > localP -> P_24 ) { localB -> dwa34yqvis [ 1 ] = localB ->
bwlsmegbgn_idx_1 - localP -> P_24 ; } else if ( localB -> bwlsmegbgn_idx_1 >=
localP -> P_16 ) { localB -> dwa34yqvis [ 1 ] = 0.0F ; } else { localB ->
dwa34yqvis [ 1 ] = localB -> bwlsmegbgn_idx_1 - localP -> P_16 ; } localB ->
dhojtjqasu_idx_1 = localP -> P_8 [ 1 ] * localB -> hmjwwvohc0_mdoasc5av4 [ 1
] ; localB -> izlb01spri_ezqlmfzvpq = muSingleScalarSign ( localB ->
dwa34yqvis [ 1 ] ) ; if ( muSingleScalarIsNaN ( localB ->
izlb01spri_ezqlmfzvpq ) ) { localB -> izlb01spri_ezqlmfzvpq = 0.0F ; } else {
localB -> izlb01spri_ezqlmfzvpq = muSingleScalarRem ( localB ->
izlb01spri_ezqlmfzvpq , 256.0F ) ; } localB -> bwlsmegbgn_idx_0 =
muSingleScalarSign ( localB -> dhojtjqasu_idx_1 ) ; if ( muSingleScalarIsNaN
( localB -> bwlsmegbgn_idx_0 ) ) { localB -> bwlsmegbgn_idx_0 = 0.0F ; } else
{ localB -> bwlsmegbgn_idx_0 = muSingleScalarRem ( localB -> bwlsmegbgn_idx_0
, 256.0F ) ; } if ( ( localP -> P_162 * localB -> bwlsmegbgn_idx_1 != localB
-> dwa34yqvis [ 1 ] ) && ( ( localB -> izlb01spri_ezqlmfzvpq < 0.0F ? (
int32_T ) ( int8_T ) - ( int8_T ) ( uint8_T ) - localB ->
izlb01spri_ezqlmfzvpq : ( int32_T ) ( int8_T ) ( uint8_T ) localB ->
izlb01spri_ezqlmfzvpq ) == ( localB -> bwlsmegbgn_idx_0 < 0.0F ? ( int32_T )
( int8_T ) - ( int8_T ) ( uint8_T ) - localB -> bwlsmegbgn_idx_0 : ( int32_T
) ( int8_T ) ( uint8_T ) localB -> bwlsmegbgn_idx_0 ) ) ) { localB ->
dwa34yqvis [ 1 ] = localP -> P_116 ; } else { localB -> dwa34yqvis [ 1 ] =
localB -> dhojtjqasu_idx_1 ; } if ( localB -> bwlsmegbgn_idx_1 > localP ->
P_24 ) { localB -> bwlsmegbgn_idx_1 = localP -> P_24 ; } else { if ( localB
-> bwlsmegbgn_idx_1 < localP -> P_16 ) { localB -> bwlsmegbgn_idx_1 = localP
-> P_16 ; } } if ( ! localP -> P_228 ) { if ( localP -> P_230 == 1 ) { localB
-> izlb01spri_ezqlmfzvpq = localP -> P_177 ; } else { localB ->
izlb01spri_ezqlmfzvpq = localP -> P_179 ; } localB -> k5j1weseip_idx_2 +=
localB -> izlb01spri_ezqlmfzvpq ; } localB -> k5j1weseip_idx_1 = ipxpc4eli1
-> orient_ref [ 0 ] - localB -> dyzwxnm2fa_lnjdk5wtww ; if ( localB ->
k5j1weseip_idx_1 > localP -> P_163 ) { localB -> k5j1weseip_idx_1 = localP ->
P_163 ; } else { if ( localB -> k5j1weseip_idx_1 < localP -> P_164 ) { localB
-> k5j1weseip_idx_1 = localP -> P_164 ; } } if ( localB -> kfvbhjiqtg [ 0 ] >
localP -> P_23 ) { localB -> dhojtjqasu_idx_1 = localB -> kfvbhjiqtg [ 0 ] -
localP -> P_23 ; } else if ( localB -> kfvbhjiqtg [ 0 ] >= localP -> P_15 ) {
localB -> dhojtjqasu_idx_1 = 0.0F ; } else { localB -> dhojtjqasu_idx_1 =
localB -> kfvbhjiqtg [ 0 ] - localP -> P_15 ; } localB -> k5j1weseip_idx_0 =
localP -> P_9 * localB -> ika3nfqja0_ldqodwenvz [ 0 ] ; localB ->
izlb01spri_ezqlmfzvpq = muSingleScalarSign ( localB -> dhojtjqasu_idx_1 ) ;
if ( muSingleScalarIsNaN ( localB -> izlb01spri_ezqlmfzvpq ) ) { localB ->
izlb01spri_ezqlmfzvpq = 0.0F ; } else { localB -> izlb01spri_ezqlmfzvpq =
muSingleScalarRem ( localB -> izlb01spri_ezqlmfzvpq , 256.0F ) ; } localB ->
bwlsmegbgn_idx_0 = muSingleScalarSign ( localB -> k5j1weseip_idx_0 ) ; if (
muSingleScalarIsNaN ( localB -> bwlsmegbgn_idx_0 ) ) { localB ->
bwlsmegbgn_idx_0 = 0.0F ; } else { localB -> bwlsmegbgn_idx_0 =
muSingleScalarRem ( localB -> bwlsmegbgn_idx_0 , 256.0F ) ; } if ( ( localP
-> P_169 * localB -> kfvbhjiqtg [ 0 ] != localB -> dhojtjqasu_idx_1 ) && ( (
localB -> izlb01spri_ezqlmfzvpq < 0.0F ? ( int32_T ) ( int8_T ) - ( int8_T )
( uint8_T ) - localB -> izlb01spri_ezqlmfzvpq : ( int32_T ) ( int8_T ) (
uint8_T ) localB -> izlb01spri_ezqlmfzvpq ) == ( localB -> bwlsmegbgn_idx_0 <
0.0F ? ( int32_T ) ( int8_T ) - ( int8_T ) ( uint8_T ) - localB ->
bwlsmegbgn_idx_0 : ( int32_T ) ( int8_T ) ( uint8_T ) localB ->
bwlsmegbgn_idx_0 ) ) ) { localB -> kfvbhjiqtg [ 0 ] = localP -> P_117 ; }
else { localB -> kfvbhjiqtg [ 0 ] = localB -> k5j1weseip_idx_0 ; } if (
localB -> kfvbhjiqtg [ 1 ] > localP -> P_23 ) { localB -> dhojtjqasu_idx_1 =
localB -> kfvbhjiqtg [ 1 ] - localP -> P_23 ; } else if ( localB ->
kfvbhjiqtg [ 1 ] >= localP -> P_15 ) { localB -> dhojtjqasu_idx_1 = 0.0F ; }
else { localB -> dhojtjqasu_idx_1 = localB -> kfvbhjiqtg [ 1 ] - localP ->
P_15 ; } localB -> k5j1weseip_idx_0 = localP -> P_9 * localB ->
fncl0arrzd_tmp ; localB -> izlb01spri_ezqlmfzvpq = muSingleScalarSign (
localB -> dhojtjqasu_idx_1 ) ; if ( muSingleScalarIsNaN ( localB ->
izlb01spri_ezqlmfzvpq ) ) { localB -> izlb01spri_ezqlmfzvpq = 0.0F ; } else {
localB -> izlb01spri_ezqlmfzvpq = muSingleScalarRem ( localB ->
izlb01spri_ezqlmfzvpq , 256.0F ) ; } localB -> bwlsmegbgn_idx_0 =
muSingleScalarSign ( localB -> k5j1weseip_idx_0 ) ; if ( muSingleScalarIsNaN
( localB -> bwlsmegbgn_idx_0 ) ) { localB -> bwlsmegbgn_idx_0 = 0.0F ; } else
{ localB -> bwlsmegbgn_idx_0 = muSingleScalarRem ( localB -> bwlsmegbgn_idx_0
, 256.0F ) ; } if ( ( localP -> P_169 * localB -> kfvbhjiqtg [ 1 ] != localB
-> dhojtjqasu_idx_1 ) && ( ( localB -> izlb01spri_ezqlmfzvpq < 0.0F ? (
int32_T ) ( int8_T ) - ( int8_T ) ( uint8_T ) - localB ->
izlb01spri_ezqlmfzvpq : ( int32_T ) ( int8_T ) ( uint8_T ) localB ->
izlb01spri_ezqlmfzvpq ) == ( localB -> bwlsmegbgn_idx_0 < 0.0F ? ( int32_T )
( int8_T ) - ( int8_T ) ( uint8_T ) - localB -> bwlsmegbgn_idx_0 : ( int32_T
) ( int8_T ) ( uint8_T ) localB -> bwlsmegbgn_idx_0 ) ) ) { localB ->
kfvbhjiqtg [ 1 ] = localP -> P_117 ; } else { localB -> kfvbhjiqtg [ 1 ] =
localB -> k5j1weseip_idx_0 ; } localB -> kyotspzhxf = localP -> P_170 *
localB -> k5j1weseip_idx_1 ; if ( localB -> pl4id4anyh ) { localB ->
izlb01spri_ezqlmfzvpq = localP -> P_106 * localP -> P_153 ; } else { localB
-> izlb01spri_ezqlmfzvpq = ( localP -> P_107 * localB ->
knhr21r5s4_hv2ho1zopz + localDW -> bsetqjfri4 ) - localP -> P_108 * (
real32_T ) localB -> glswd2nkcd_cv5hdgrwft [ 2 ] ; } localB ->
izlb01spri_ezqlmfzvpq += localP -> P_153 ; if ( localB ->
izlb01spri_ezqlmfzvpq > localP -> P_154 ) { localB -> izlb01spri_ezqlmfzvpq =
localP -> P_154 ; } else { if ( localB -> izlb01spri_ezqlmfzvpq < localP ->
P_155 ) { localB -> izlb01spri_ezqlmfzvpq = localP -> P_155 ; } } localB ->
bwlsmegbgn_idx_2 = ( localP -> P_165 * localB -> k5j1weseip_idx_1 + localDW
-> c4kiksmhh2 ) - localP -> P_168 * localB -> bwlsmegbgn_idx_2 ; for ( localB
-> i = 0 ; localB -> i <= 0 ; localB -> i += 4 ) { tmp_e = _mm_loadu_ps ( &
localB -> av0imjbvtg [ localB -> i ] ) ; tmp_i = _mm_loadu_ps ( & localB ->
av0imjbvtg [ localB -> i + 4 ] ) ; tmp = _mm_loadu_ps ( & localB ->
av0imjbvtg [ localB -> i + 8 ] ) ; tmp_p = _mm_loadu_ps ( & localB ->
av0imjbvtg [ localB -> i + 12 ] ) ; _mm_storeu_ps ( & localB ->
lrvnnrrvgx_o4f35lbcvx [ localB -> i ] , _mm_add_ps ( _mm_mul_ps ( tmp_p ,
_mm_set1_ps ( localB -> bwlsmegbgn_idx_1 ) ) , _mm_add_ps ( _mm_mul_ps ( tmp
, _mm_set1_ps ( localB -> k5j1weseip_idx_2 ) ) , _mm_add_ps ( _mm_mul_ps (
tmp_i , _mm_set1_ps ( localB -> bwlsmegbgn_idx_2 ) ) , _mm_add_ps (
_mm_mul_ps ( tmp_e , _mm_set1_ps ( localB -> izlb01spri_ezqlmfzvpq ) ) ,
_mm_set1_ps ( 0.0F ) ) ) ) ) ) ; } localB -> izlb01spri_ezqlmfzvpq = localP
-> P_171 * localB -> lrvnnrrvgx_o4f35lbcvx [ 0 ] ; if ( localB ->
izlb01spri_ezqlmfzvpq > localP -> P_172 ) { localB -> izlb01spri_ezqlmfzvpq =
localP -> P_172 ; } else { if ( localB -> izlb01spri_ezqlmfzvpq < localP ->
P_173 ) { localB -> izlb01spri_ezqlmfzvpq = localP -> P_173 ; } } localB ->
p4vhxsp0g0 [ 0 ] = localP -> P_174 [ 0 ] * localB -> izlb01spri_ezqlmfzvpq ;
localB -> izlb01spri_ezqlmfzvpq = localP -> P_171 * localB ->
lrvnnrrvgx_o4f35lbcvx [ 1 ] ; if ( localB -> izlb01spri_ezqlmfzvpq > localP
-> P_172 ) { localB -> izlb01spri_ezqlmfzvpq = localP -> P_172 ; } else { if
( localB -> izlb01spri_ezqlmfzvpq < localP -> P_173 ) { localB ->
izlb01spri_ezqlmfzvpq = localP -> P_173 ; } } localB -> p4vhxsp0g0 [ 1 ] =
localP -> P_174 [ 1 ] * localB -> izlb01spri_ezqlmfzvpq ; localB ->
izlb01spri_ezqlmfzvpq = localP -> P_171 * localB -> lrvnnrrvgx_o4f35lbcvx [ 2
] ; if ( localB -> izlb01spri_ezqlmfzvpq > localP -> P_172 ) { localB ->
izlb01spri_ezqlmfzvpq = localP -> P_172 ; } else { if ( localB ->
izlb01spri_ezqlmfzvpq < localP -> P_173 ) { localB -> izlb01spri_ezqlmfzvpq =
localP -> P_173 ; } } localB -> p4vhxsp0g0 [ 2 ] = localP -> P_174 [ 2 ] *
localB -> izlb01spri_ezqlmfzvpq ; localB -> izlb01spri_ezqlmfzvpq = localP ->
P_171 * localB -> lrvnnrrvgx_o4f35lbcvx [ 3 ] ; if ( localB ->
izlb01spri_ezqlmfzvpq > localP -> P_172 ) { localB -> izlb01spri_ezqlmfzvpq =
localP -> P_172 ; } else { if ( localB -> izlb01spri_ezqlmfzvpq < localP ->
P_173 ) { localB -> izlb01spri_ezqlmfzvpq = localP -> P_173 ; } } localB ->
p4vhxsp0g0 [ 3 ] = localP -> P_174 [ 3 ] * localB -> izlb01spri_ezqlmfzvpq ;
localB -> l1woxyguei_h522xzlxvt = localDW -> dxm3w2i52x ; if ( localB ->
l1woxyguei_h522xzlxvt > localP -> P_74 ) { localB -> avehkh15jm_dapv3jlyq5 =
localB -> kbaevcigdn_bsqwvugooi - localB -> avehkh15jm_dapv3jlyq5 ; localB ->
oxqfy2xq0w_m3yhjduhi1 = fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 2 ]
; localB -> ohjru33l3t_idx_1 = fp0u5nlpgw -> VisionSensors . opticalFlow_data
[ 2 ] ; } else { localB -> avehkh15jm_dapv3jlyq5 = localP -> P_180 ; localB
-> oxqfy2xq0w_m3yhjduhi1 = localP -> P_72 ; localB -> ohjru33l3t_idx_1 =
localP -> P_72 ; } localB -> ptnoncmuih = ( real_T ) ( localB ->
ohjru33l3t_idx_1 == localP -> P_1 ) * localDW -> bw2ribqmwm + ( real_T ) (
localB -> oxqfy2xq0w_m3yhjduhi1 == localP -> P_1 ) ; localB ->
n13vzx5vsl_c0dok3111h = localB -> l1woxyguei_h522xzlxvt + localP -> P_219 ;
if ( localB -> n13vzx5vsl_c0dok3111h > localP -> P_47 ) { localB ->
ae0r0hxav0 = localP -> P_220 ; } else { localB -> ae0r0hxav0 = localB ->
n13vzx5vsl_c0dok3111h ; } if ( ( muSingleScalarAbs ( localB ->
ckkfajmco2_idx_0 ) > localP -> P_25 ) || ( muSingleScalarAbs ( localB ->
ckkfajmco2_idx_1 ) > localP -> P_26 ) ) { ghadbep3bb ( & localB -> igogmbewdc
, & localP -> ghadbep3bbv ) ; } else if ( ( ( muSingleScalarAbs ( fp0u5nlpgw
-> VisionSensors . opticalFlow_data [ 0 ] ) > localP -> P_29 ) && (
muSingleScalarAbs ( localP -> P_175 * fp0u5nlpgw -> VisionSensors .
opticalFlow_data [ 0 ] - localB -> lbhq3ilsyd [ 0 ] ) > localP -> P_27 ) ) ||
( ( muSingleScalarAbs ( localP -> P_176 * fp0u5nlpgw -> VisionSensors .
opticalFlow_data [ 1 ] - localB -> lbhq3ilsyd [ 1 ] ) > localP -> P_28 ) && (
muSingleScalarAbs ( fp0u5nlpgw -> VisionSensors . opticalFlow_data [ 1 ] ) >
localP -> P_30 ) ) ) { ghadbep3bb ( & localB -> igogmbewdc , & localP ->
acfz1zxm4t ) ; } else if ( localB -> ptnoncmuih > localP -> P_0 ) {
ghadbep3bb ( & localB -> igogmbewdc , & localP -> clwiujjdqo ) ; } else if (
muSingleScalarAbs ( localB -> avehkh15jm_dapv3jlyq5 ) > localP -> P_73 ) {
ghadbep3bb ( & localB -> igogmbewdc , & localP -> jvbbqhrajh ) ; } else {
ghadbep3bb ( & localB -> igogmbewdc , & localP -> ciy1c2o0rv ) ; } localB ->
gdm0zsnjnp_nz4o0shxby = ay1xsyaztb [ 1 ] + ay1xsyaztb [ 0 ] ; localB ->
j2224scyrs_llw0u2ae0v = localDW -> h3csutamah ; localB ->
nk5blfa0ar_dhmrxtyqop = muDoubleScalarMax ( localB -> gdm0zsnjnp_nz4o0shxby ,
localB -> j2224scyrs_llw0u2ae0v ) ; localB -> audxpwawnl = localB ->
nk5blfa0ar_dhmrxtyqop ; localDW -> pvooxnzvxd = localB ->
gdm0zsnjnp_nz4o0shxby ; localB -> aysnllomng_jwzvbuczlb = localDW ->
js3ly0p0tr ; if ( 0.0 > localP -> P_69 ) { localB -> cqyqgilres = localP ->
P_79 ; } else { localB -> cqyqgilres = localDW -> gxd2vu1ibf ; } localB ->
l0nu5qcuyl = ( uint8_T ) ( ( uint32_T ) ( ! ( localB -> cqyqgilres != 0.0 ) ?
( int32_T ) localP -> P_233 : 0 ) + localDW -> fxisjak2ua ) ; localB ->
ljlimj0sfs_icdfyazkhu [ 0 ] = localB -> i4wbkrxufu_idx_0 ; localB ->
ljlimj0sfs_icdfyazkhu [ 1 ] = localB -> i4wbkrxufu_idx_1 ; localB ->
i4wbkrxufu_idx_0 = localP -> P_80 [ 0 ] * localB -> ljlimj0sfs_icdfyazkhu [ 0
] + localP -> P_80 [ 2 ] * localB -> ljlimj0sfs_icdfyazkhu [ 1 ] ; localB ->
i4wbkrxufu_idx_1 = localP -> P_80 [ 1 ] * localB -> ljlimj0sfs_icdfyazkhu [ 0
] + localP -> P_80 [ 3 ] * localB -> ljlimj0sfs_icdfyazkhu [ 1 ] ; for (
localB -> i = 0 ; localB -> i < 3 ; localB -> i ++ ) { localB -> lfda2u1mt3 [
localB -> i ] = ( ( localB -> fncl0arrzd_bhxxfovxdy [ 3 * localB -> i + 1 ] *
localB -> f45tnce4lx_oyypvi4boh [ 1 ] + localB -> fncl0arrzd_bhxxfovxdy [ 3 *
localB -> i ] * localB -> f45tnce4lx_oyypvi4boh [ 0 ] ) + localB ->
fncl0arrzd_bhxxfovxdy [ 3 * localB -> i + 2 ] * localB -> acc1 ) + localP ->
P_94 [ localB -> i ] ; } localB -> dpbek0wdwu_czkfpwuzm5 = localB ->
lfda2u1mt3 [ 2 ] ; localB -> oxqfy2xq0w_m3yhjduhi1 = localP -> P_81 [ 0 ] *
localB -> lfda2u1mt3 [ 2 ] ; localB -> ohjru33l3t_idx_1 = localP -> P_81 [ 1
] * localB -> lfda2u1mt3 [ 2 ] ; localB -> fin0tlxq2w_fkr0r45bcn = localB ->
cud2lkfkrd_as0qznsxlv ; if ( localB -> fin0tlxq2w_fkr0r45bcn ) { if ( !
localDW -> g4zcogq4xi ) { if ( rtmGetTaskTime ( accn4cnket , 0 ) !=
rtmGetTStart ( accn4cnket ) ) { ssSetBlockStateForSolverChangedAtMajorStep (
accn4cnket -> _mdlRefSfcnS ) ; } localDW -> g4zcogq4xi = true ; } localB ->
mxbryllu15_merlcviukg -= ( localP -> P_82 [ 0 ] * localB ->
ljlimj0sfs_icdfyazkhu [ 0 ] + localP -> P_82 [ 1 ] * localB ->
ljlimj0sfs_icdfyazkhu [ 1 ] ) + localP -> P_86 * localB ->
dpbek0wdwu_czkfpwuzm5 ; localB -> gisde2u3xx [ 0 ] = localB -> csnxbqta3d [ 0
] * localB -> mxbryllu15_merlcviukg ; localB -> gisde2u3xx [ 1 ] = localB ->
csnxbqta3d [ 1 ] * localB -> mxbryllu15_merlcviukg ; srUpdateBC ( localDW ->
idn2v5d33m ) ; } else { if ( localDW -> g4zcogq4xi ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ;
localB -> gisde2u3xx [ 0 ] = localP -> P_54 ; localB -> gisde2u3xx [ 1 ] =
localP -> P_54 ; localDW -> g4zcogq4xi = false ; } } localB -> kcknzyt2kw [ 0
] = ( localB -> oxqfy2xq0w_m3yhjduhi1 + localB -> i4wbkrxufu_idx_0 ) + localB
-> gisde2u3xx [ 0 ] ; localB -> kcknzyt2kw [ 1 ] = ( localB ->
ohjru33l3t_idx_1 + localB -> i4wbkrxufu_idx_1 ) + localB -> gisde2u3xx [ 1 ]
; localB -> j4lqej5yyk_nvsvtgkap4 [ 0 ] = localB -> gchaygbwpg ; localB ->
j4lqej5yyk_nvsvtgkap4 [ 1 ] = localB -> bevd1uolnu ; localB ->
j4lqej5yyk_nvsvtgkap4 [ 2 ] = localB -> gc1nrupvnq ; localB ->
mgtffanxwu_lxo5edjg3c [ 0 ] = localB -> nuftjfb4tr_dhamdvybc1 [ 0 ] ; localB
-> mgtffanxwu_lxo5edjg3c [ 1 ] = localB -> nuftjfb4tr_dhamdvybc1 [ 1 ] ;
localB -> ckkfajmco2_idx_0 = localP -> P_181 [ 0 ] * localB ->
mgtffanxwu_lxo5edjg3c [ 0 ] + localP -> P_181 [ 2 ] * localB ->
mgtffanxwu_lxo5edjg3c [ 1 ] ; localB -> ckkfajmco2_idx_1 = localP -> P_181 [
1 ] * localB -> mgtffanxwu_lxo5edjg3c [ 0 ] + localP -> P_181 [ 3 ] * localB
-> mgtffanxwu_lxo5edjg3c [ 1 ] ; localB -> n4mliatza1_al00mdgrv4 = localB ->
bevd1uolnu ; localB -> k5j1weseip_idx_2 = localP -> P_182 [ 0 ] * localB ->
n4mliatza1_al00mdgrv4 ; localB -> izlb01spri_ezqlmfzvpq = localP -> P_182 [ 1
] * localB -> n4mliatza1_al00mdgrv4 ; localB -> ejwic3uv1f_izlwqhinl5 =
localB -> lhzpbdvr4c_ax3wx1gs5w ; phrpuocqmv ( accn4cnket , localB ->
ejwic3uv1f_izlwqhinl5 , localB -> a2gs1s4oet , localB ->
jyapnrweub_jzx3amusab , localP -> P_183 , localB -> mgtffanxwu_lxo5edjg3c ,
localP -> P_184 , localB -> n4mliatza1_al00mdgrv4 , & localB -> phrpuocqmvu ,
& localDW -> phrpuocqmvu , & localP -> phrpuocqmvu ) ; localB -> pt1nmquqmi [
0 ] = ( localB -> k5j1weseip_idx_2 + localB -> ckkfajmco2_idx_0 ) + localB ->
phrpuocqmvu . atkm3eb3zr [ 0 ] ; localB -> pt1nmquqmi [ 1 ] = ( localB ->
izlb01spri_ezqlmfzvpq + localB -> ckkfajmco2_idx_1 ) + localB -> phrpuocqmvu
. atkm3eb3zr [ 1 ] ; localB -> gmrn2rijvh_owjr1h1vqy [ 0 ] = localB ->
nsadlikv0l_dypejvacrn [ 0 ] ; localB -> gmrn2rijvh_owjr1h1vqy [ 1 ] = localB
-> nsadlikv0l_dypejvacrn [ 1 ] ; localB -> ckkfajmco2_idx_0 = localP -> P_192
[ 0 ] * localB -> gmrn2rijvh_owjr1h1vqy [ 0 ] + localP -> P_192 [ 2 ] *
localB -> gmrn2rijvh_owjr1h1vqy [ 1 ] ; localB -> ckkfajmco2_idx_1 = localP
-> P_192 [ 1 ] * localB -> gmrn2rijvh_owjr1h1vqy [ 0 ] + localP -> P_192 [ 3
] * localB -> gmrn2rijvh_owjr1h1vqy [ 1 ] ; localB -> cngwszwr0t_ju13rw2h0m =
localB -> gchaygbwpg ; localB -> k5j1weseip_idx_2 = localP -> P_193 [ 0 ] *
localB -> cngwszwr0t_ju13rw2h0m ; localB -> izlb01spri_ezqlmfzvpq = localP ->
P_193 [ 1 ] * localB -> cngwszwr0t_ju13rw2h0m ; localB ->
bauafbz0yu_fft32lqtda = localB -> fn3vhnol1t_evg4t2fsev ; phrpuocqmv (
accn4cnket , localB -> bauafbz0yu_fft32lqtda , localB -> fpz0siyp52 , localB
-> bkasatad0l_fdinthrxmb , localP -> P_194 , localB -> gmrn2rijvh_owjr1h1vqy
, localP -> P_195 , localB -> cngwszwr0t_ju13rw2h0m , & localB -> bm3dpymkhz
, & localDW -> bm3dpymkhz , & localP -> bm3dpymkhz ) ; localB -> kcihrwcew5 [
0 ] = ( localB -> k5j1weseip_idx_2 + localB -> ckkfajmco2_idx_0 ) + localB ->
bm3dpymkhz . atkm3eb3zr [ 0 ] ; localB -> kcihrwcew5 [ 1 ] = ( localB ->
izlb01spri_ezqlmfzvpq + localB -> ckkfajmco2_idx_1 ) + localB -> bm3dpymkhz .
atkm3eb3zr [ 1 ] ; localB -> prxhukvqog_ctvw0tpkon = localB ->
b0xkfl5szj_jacdjrqyev + localP -> P_221 ; if ( localB ->
prxhukvqog_ctvw0tpkon > localP -> P_48 ) { localB -> aajdjdyozd = localP ->
P_222 ; } else { localB -> aajdjdyozd = localB -> prxhukvqog_ctvw0tpkon ; }
muSingleScalarSinCos ( localB -> dyzwxnm2fa_lnjdk5wtww , & localB ->
ckkfajmco2_idx_0 , & localB -> ckkfajmco2_idx_1 ) ; muSingleScalarSinCos (
localB -> gcbzmq1psk_idx_1 , & localB -> mcvxfa5ajb_idx_1 , & localB ->
fhly3g0mod_idx_1 ) ; muSingleScalarSinCos ( localB -> kldfwzrldv_bjvjhhzy4i ,
& localB -> mcvxfa5ajb_idx_2 , & localB -> fhly3g0mod_idx_2 ) ; localB ->
fncl0arrzd_bhxxfovxdy [ 0 ] = localB -> fhly3g0mod_idx_1 * localB ->
ckkfajmco2_idx_1 ; localB -> knhr21r5s4_hv2ho1zopz = localB ->
mcvxfa5ajb_idx_2 * localB -> mcvxfa5ajb_idx_1 ; localB ->
fncl0arrzd_bhxxfovxdy [ 1 ] = localB -> knhr21r5s4_hv2ho1zopz * localB ->
ckkfajmco2_idx_1 - localB -> fhly3g0mod_idx_2 * localB -> ckkfajmco2_idx_0 ;
localB -> fncl0arrzd_tmp = localB -> fhly3g0mod_idx_2 * localB ->
mcvxfa5ajb_idx_1 ; localB -> fncl0arrzd_bhxxfovxdy [ 2 ] = localB ->
fncl0arrzd_tmp * localB -> ckkfajmco2_idx_1 + localB -> mcvxfa5ajb_idx_2 *
localB -> ckkfajmco2_idx_0 ; localB -> fncl0arrzd_bhxxfovxdy [ 3 ] = localB
-> fhly3g0mod_idx_1 * localB -> ckkfajmco2_idx_0 ; localB ->
fncl0arrzd_bhxxfovxdy [ 4 ] = localB -> knhr21r5s4_hv2ho1zopz * localB ->
ckkfajmco2_idx_0 + localB -> fhly3g0mod_idx_2 * localB -> ckkfajmco2_idx_1 ;
localB -> fncl0arrzd_bhxxfovxdy [ 5 ] = localB -> fncl0arrzd_tmp * localB ->
ckkfajmco2_idx_0 - localB -> mcvxfa5ajb_idx_2 * localB -> ckkfajmco2_idx_1 ;
localB -> fncl0arrzd_bhxxfovxdy [ 6 ] = - localB -> mcvxfa5ajb_idx_1 ; localB
-> fncl0arrzd_bhxxfovxdy [ 7 ] = localB -> mcvxfa5ajb_idx_2 * localB ->
fhly3g0mod_idx_1 ; localB -> fncl0arrzd_bhxxfovxdy [ 8 ] = localB ->
fhly3g0mod_idx_2 * localB -> fhly3g0mod_idx_1 ; localB ->
cud2lkfkrd_as0qznsxlv = ( localB -> kbaevcigdn_bsqwvugooi <= localP -> P_33 )
; localB -> lhzpbdvr4c_ax3wx1gs5w = ( ( localB -> mpf5fynzwe_idx_0 != localP
-> P_34 ) || ( localB -> emslsylcj0_bnlywzniup != localP -> P_35 ) ) ; for (
localB -> i = 0 ; localB -> i < 3 ; localB -> i ++ ) { localB ->
glswd2nkcd_cv5hdgrwft [ localB -> i ] = localB -> f45tnce4lx_oyypvi4boh [
localB -> i ] - ( ( localB -> fncl0arrzd_bhxxfovxdy [ localB -> i + 3 ] *
localP -> P_102 [ 1 ] + localB -> fncl0arrzd_bhxxfovxdy [ localB -> i ] *
localP -> P_102 [ 0 ] ) + localB -> fncl0arrzd_bhxxfovxdy [ localB -> i + 6 ]
* localP -> P_102 [ 2 ] ) ; } localB -> aqes0fqnpu [ 0 ] = ( real32_T ) (
localP -> P_70 * localB -> glswd2nkcd_cv5hdgrwft [ 0 ] ) * ( real32_T )
localB -> lhzpbdvr4c_ax3wx1gs5w * ( real32_T ) localB ->
cud2lkfkrd_as0qznsxlv ; localB -> aqes0fqnpu [ 1 ] = ( real32_T ) ( localP ->
P_70 * localB -> glswd2nkcd_cv5hdgrwft [ 1 ] ) * ( real32_T ) localB ->
lhzpbdvr4c_ax3wx1gs5w * ( real32_T ) localB -> cud2lkfkrd_as0qznsxlv ; localB
-> fggdftcdgi_nyxm0bsxsn [ 0 ] = localB -> bacemjpimt_jz50ptvnrg [ 0 ] ;
localB -> fggdftcdgi_nyxm0bsxsn [ 1 ] = localB -> bacemjpimt_jz50ptvnrg [ 1 ]
; localB -> fggdftcdgi_nyxm0bsxsn [ 2 ] = localB -> bacemjpimt_jz50ptvnrg [ 2
] ; localB -> fggdftcdgi_nyxm0bsxsn [ 3 ] = localB -> bacemjpimt_jz50ptvnrg [
3 ] ; for ( localB -> i = 0 ; localB -> i <= 0 ; localB -> i += 4 ) { tmp_e =
_mm_add_ps ( _mm_mul_ps ( _mm_loadu_ps ( & localP -> P_205 [ localB -> i ] )
, _mm_set1_ps ( localB -> fggdftcdgi_nyxm0bsxsn [ 0 ] ) ) , _mm_set1_ps (
0.0F ) ) ; tmp_i = _mm_mul_ps ( _mm_loadu_ps ( & localP -> P_205 [ localB ->
i + 4 ] ) , _mm_set1_ps ( localB -> fggdftcdgi_nyxm0bsxsn [ 1 ] ) ) ; tmp =
_mm_loadu_ps ( & localP -> P_205 [ localB -> i + 8 ] ) ; _mm_storeu_ps ( &
localB -> bacemjpimt_jz50ptvnrg [ localB -> i ] , _mm_add_ps ( _mm_mul_ps (
_mm_loadu_ps ( & localP -> P_205 [ localB -> i + 12 ] ) , _mm_set1_ps (
localB -> fggdftcdgi_nyxm0bsxsn [ 3 ] ) ) , _mm_add_ps ( _mm_mul_ps ( tmp ,
_mm_set1_ps ( localB -> fggdftcdgi_nyxm0bsxsn [ 2 ] ) ) , _mm_add_ps ( tmp_i
, tmp_e ) ) ) ) ; } localB -> ckkfajmco2_idx_0 = localB -> aqes0fqnpu [ 0 ] ;
localB -> ckkfajmco2_idx_1 = localB -> aqes0fqnpu [ 1 ] ; for ( localB -> i =
0 ; localB -> i <= 0 ; localB -> i += 4 ) { tmp_e = _mm_loadu_ps ( & localP
-> P_206 [ localB -> i ] ) ; _mm_storeu_ps ( & localB ->
lrvnnrrvgx_o4f35lbcvx [ localB -> i ] , _mm_add_ps ( _mm_mul_ps (
_mm_loadu_ps ( & localP -> P_206 [ localB -> i + 4 ] ) , _mm_set1_ps ( localB
-> aqes0fqnpu [ 1 ] ) ) , _mm_add_ps ( _mm_mul_ps ( tmp_e , _mm_set1_ps (
localB -> aqes0fqnpu [ 0 ] ) ) , _mm_set1_ps ( 0.0F ) ) ) ) ; } localB ->
amz4nxdwn1_gxhmnjv5xa = localB -> piutssyltq_ifotjnizh4 ; if ( localB ->
amz4nxdwn1_gxhmnjv5xa ) { if ( ! localDW -> kh1khihcrt ) { if (
rtmGetTaskTime ( accn4cnket , 0 ) != rtmGetTStart ( accn4cnket ) ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ; }
localDW -> kh1khihcrt = true ; } for ( localB -> i = 0 ; localB -> i < 2 ;
localB -> i ++ ) { localB -> izlb01spri_ezqlmfzvpq = localP -> P_207 [ localB
-> i + 6 ] * localB -> fggdftcdgi_nyxm0bsxsn [ 3 ] + ( localP -> P_207 [
localB -> i + 4 ] * localB -> fggdftcdgi_nyxm0bsxsn [ 2 ] + ( localP -> P_207
[ localB -> i + 2 ] * localB -> fggdftcdgi_nyxm0bsxsn [ 1 ] + localP -> P_207
[ localB -> i ] * localB -> fggdftcdgi_nyxm0bsxsn [ 0 ] ) ) ; localB ->
hmjwwvohc0_mdoasc5av4 [ localB -> i ] = localB -> izlb01spri_ezqlmfzvpq ; }
localB -> kbaevcigdn_bsqwvugooi = localB -> bcsdzee53f_guugdwf2m3 [ 0 ] - ( (
localP -> P_208 [ 0 ] * localB -> ckkfajmco2_idx_0 + localP -> P_208 [ 2 ] *
localB -> ckkfajmco2_idx_1 ) + localB -> hmjwwvohc0_mdoasc5av4 [ 0 ] ) ;
localB -> ipkrnilgqg_idx_0 = localB -> bcsdzee53f_guugdwf2m3 [ 1 ] - ( (
localP -> P_208 [ 1 ] * localB -> ckkfajmco2_idx_0 + localP -> P_208 [ 3 ] *
localB -> ckkfajmco2_idx_1 ) + localB -> hmjwwvohc0_mdoasc5av4 [ 1 ] ) ; for
( localB -> i = 0 ; localB -> i <= 0 ; localB -> i += 4 ) { _mm_storeu_ps ( &
localB -> n04moqscwc [ localB -> i ] , _mm_set1_ps ( 0.0F ) ) ; tmp_e =
_mm_loadu_ps ( & localB -> jlzqvyfs0r [ localB -> i ] ) ; tmp_i =
_mm_loadu_ps ( & localB -> n04moqscwc [ localB -> i ] ) ; _mm_storeu_ps ( &
localB -> n04moqscwc [ localB -> i ] , _mm_add_ps ( _mm_mul_ps ( tmp_e ,
_mm_set1_ps ( localB -> kbaevcigdn_bsqwvugooi ) ) , tmp_i ) ) ; tmp_e =
_mm_loadu_ps ( & localB -> jlzqvyfs0r [ localB -> i + 4 ] ) ; tmp_i =
_mm_loadu_ps ( & localB -> n04moqscwc [ localB -> i ] ) ; _mm_storeu_ps ( &
localB -> n04moqscwc [ localB -> i ] , _mm_add_ps ( _mm_mul_ps ( tmp_e ,
_mm_set1_ps ( localB -> ipkrnilgqg_idx_0 ) ) , tmp_i ) ) ; } srUpdateBC (
localDW -> mfifybuxty ) ; } else { if ( localDW -> kh1khihcrt ) {
ssSetBlockStateForSolverChangedAtMajorStep ( accn4cnket -> _mdlRefSfcnS ) ;
localB -> n04moqscwc [ 0 ] = localP -> P_112 ; localB -> n04moqscwc [ 1 ] =
localP -> P_112 ; localB -> n04moqscwc [ 2 ] = localP -> P_112 ; localB ->
n04moqscwc [ 3 ] = localP -> P_112 ; localDW -> kh1khihcrt = false ; } }
localB -> bhcndqqae3 [ 0 ] = ( localB -> lrvnnrrvgx_o4f35lbcvx [ 0 ] + localB
-> bacemjpimt_jz50ptvnrg [ 0 ] ) + localB -> n04moqscwc [ 0 ] ; localB ->
bhcndqqae3 [ 1 ] = ( localB -> lrvnnrrvgx_o4f35lbcvx [ 1 ] + localB ->
bacemjpimt_jz50ptvnrg [ 1 ] ) + localB -> n04moqscwc [ 1 ] ; localB ->
bhcndqqae3 [ 2 ] = ( localB -> lrvnnrrvgx_o4f35lbcvx [ 2 ] + localB ->
bacemjpimt_jz50ptvnrg [ 2 ] ) + localB -> n04moqscwc [ 2 ] ; localB ->
bhcndqqae3 [ 3 ] = ( localB -> lrvnnrrvgx_o4f35lbcvx [ 3 ] + localB ->
bacemjpimt_jz50ptvnrg [ 3 ] ) + localB -> n04moqscwc [ 3 ] ; localB ->
lcb41la0m0_pxqvlbal2i = localB -> i24nn1hzbd_m3ybdk4ikc + localP -> P_223 ;
if ( localB -> lcb41la0m0_pxqvlbal2i > localP -> P_49 ) { localB ->
d3gcj32uev = localP -> P_224 ; } else { localB -> d3gcj32uev = localB ->
lcb41la0m0_pxqvlbal2i ; } muSingleScalarSinCos ( localB ->
dyzwxnm2fa_lnjdk5wtww , & localB -> kbaevcigdn_bsqwvugooi , & localB ->
ipkrnilgqg_idx_0 ) ; muSingleScalarSinCos ( localB -> gcbzmq1psk_idx_1 , &
localB -> dyzwxnm2fa_lnjdk5wtww , & localB -> ipkrnilgqg_idx_1 ) ;
muSingleScalarSinCos ( localB -> kldfwzrldv_bjvjhhzy4i , & localB ->
l0rbs1obzf_idx_2 , & localB -> ipkrnilgqg_idx_2 ) ; localB ->
fncl0arrzd_bhxxfovxdy [ 0 ] = localB -> ipkrnilgqg_idx_1 * localB ->
ipkrnilgqg_idx_0 ; localB -> knhr21r5s4_hv2ho1zopz = localB ->
l0rbs1obzf_idx_2 * localB -> dyzwxnm2fa_lnjdk5wtww ; localB ->
fncl0arrzd_bhxxfovxdy [ 1 ] = localB -> knhr21r5s4_hv2ho1zopz * localB ->
ipkrnilgqg_idx_0 - localB -> ipkrnilgqg_idx_2 * localB ->
kbaevcigdn_bsqwvugooi ; localB -> fncl0arrzd_tmp = localB -> ipkrnilgqg_idx_2
* localB -> dyzwxnm2fa_lnjdk5wtww ; localB -> fncl0arrzd_bhxxfovxdy [ 2 ] =
localB -> fncl0arrzd_tmp * localB -> ipkrnilgqg_idx_0 + localB ->
l0rbs1obzf_idx_2 * localB -> kbaevcigdn_bsqwvugooi ; localB ->
fncl0arrzd_bhxxfovxdy [ 3 ] = localB -> ipkrnilgqg_idx_1 * localB ->
kbaevcigdn_bsqwvugooi ; localB -> fncl0arrzd_bhxxfovxdy [ 4 ] = localB ->
knhr21r5s4_hv2ho1zopz * localB -> kbaevcigdn_bsqwvugooi + localB ->
ipkrnilgqg_idx_2 * localB -> ipkrnilgqg_idx_0 ; localB ->
fncl0arrzd_bhxxfovxdy [ 5 ] = localB -> fncl0arrzd_tmp * localB ->
kbaevcigdn_bsqwvugooi - localB -> l0rbs1obzf_idx_2 * localB ->
ipkrnilgqg_idx_0 ; localB -> fncl0arrzd_bhxxfovxdy [ 6 ] = - localB ->
dyzwxnm2fa_lnjdk5wtww ; localB -> fncl0arrzd_bhxxfovxdy [ 7 ] = localB ->
l0rbs1obzf_idx_2 * localB -> ipkrnilgqg_idx_1 ; localB ->
fncl0arrzd_bhxxfovxdy [ 8 ] = localB -> ipkrnilgqg_idx_2 * localB ->
ipkrnilgqg_idx_1 ; localB -> ckkfajmco2_idx_0 = localB -> lbhq3ilsyd [ 0 ] ;
localB -> bwlsmegbgn_idx_2 = localB -> lbhq3ilsyd [ 1 ] ; for ( localB -> i =
0 ; localB -> i < 3 ; localB -> i ++ ) { localB -> bb5sk31d0y [ localB -> i ]
= 0.0F ; localB -> bb5sk31d0y [ localB -> i ] += localB ->
fncl0arrzd_bhxxfovxdy [ 3 * localB -> i ] * localB -> ckkfajmco2_idx_0 ;
localB -> bb5sk31d0y [ localB -> i ] += localB -> fncl0arrzd_bhxxfovxdy [ 3 *
localB -> i + 1 ] * localB -> bwlsmegbgn_idx_2 ; localB -> bb5sk31d0y [
localB -> i ] += localB -> fncl0arrzd_bhxxfovxdy [ 3 * localB -> i + 2 ] *
localB -> dhojtjqasu_idx_2 ; } } void otjykwnhb3TID1 ( eo4bbte2ey * localB ,
nu4qaxumex * localP ) { real_T oqvazmunem ; real_T jkwkwv3phn ; real_T
lq2pmqd2ef ; real_T gcbzmq1psk ; real32_T biy5wepxp0 ; real32_T i45e32y4nf ;
real32_T fyfe1ira4y [ 4 ] ; real32_T obwiausg33 ; int32_T i ; memcpy ( &
localB -> av0imjbvtg [ 0 ] , & localP -> P_178 [ 0 ] , sizeof ( real32_T ) <<
4U ) ; oqvazmunem = localP -> P_71 ; jkwkwv3phn = localP -> P_76 ; if ( 0.0 >
localP -> P_77 ) { lq2pmqd2ef = localP -> P_77 ; } else if ( 0.0 < localP ->
P_78 ) { lq2pmqd2ef = localP -> P_78 ; } else { lq2pmqd2ef = 0.0 ; } localB
-> csnxbqta3d [ 0 ] = localP -> P_84 [ 0 ] ; localB -> csnxbqta3d [ 1 ] =
localP -> P_84 [ 1 ] ; localB -> nuftjfb4tr [ 0 ] = localP -> P_85 [ 0 ] ;
localB -> nuftjfb4tr [ 1 ] = localP -> P_85 [ 1 ] ; gcbzmq1psk = 0.0 ; localB
-> kldfwzrldv_pbm3vprmfu [ 0 ] = localP -> P_83 [ 0 ] ; localB ->
kldfwzrldv_pbm3vprmfu [ 1 ] = localP -> P_83 [ 1 ] ; localB ->
kldfwzrldv_pbm3vprmfu [ 2 ] = localP -> P_83 [ 2 ] ; localB ->
kldfwzrldv_pbm3vprmfu [ 3 ] = localP -> P_83 [ 3 ] ; localB ->
lhzpbdvr4c_g2mlkqadfk [ 0 ] = ( real32_T ) localP -> P_87 [ 0 ] ; localB ->
lhzpbdvr4c_g2mlkqadfk [ 1 ] = ( real32_T ) localP -> P_87 [ 1 ] ; localB ->
lhzpbdvr4c_g2mlkqadfk [ 2 ] = ( real32_T ) localP -> P_87 [ 2 ] ; localB ->
lhzpbdvr4c_g2mlkqadfk [ 3 ] = ( real32_T ) localP -> P_87 [ 3 ] ; localB ->
bkasatad0l [ 0 ] = localP -> P_93 [ 0 ] ; localB -> bkasatad0l [ 1 ] = localP
-> P_93 [ 1 ] ; localB -> a2gs1s4oet [ 0 ] = ( real32_T ) localP -> P_96 [ 0
] ; localB -> a2gs1s4oet [ 1 ] = ( real32_T ) localP -> P_96 [ 1 ] ; localB
-> gijmevwnbh [ 0 ] = ( real32_T ) localP -> P_97 [ 0 ] ; localB ->
gijmevwnbh [ 1 ] = ( real32_T ) localP -> P_97 [ 1 ] ; biy5wepxp0 = 0.0F ;
localB -> iaoljni53q_g1smspu5ke [ 0 ] = ( real32_T ) localP -> P_95 [ 0 ] ;
localB -> iaoljni53q_g1smspu5ke [ 1 ] = ( real32_T ) localP -> P_95 [ 1 ] ;
localB -> iaoljni53q_g1smspu5ke [ 2 ] = ( real32_T ) localP -> P_95 [ 2 ] ;
localB -> iaoljni53q_g1smspu5ke [ 3 ] = ( real32_T ) localP -> P_95 [ 3 ] ;
localB -> bacemjpimt [ 0 ] = localP -> P_191 [ 0 ] ; localB -> bacemjpimt [ 1
] = localP -> P_191 [ 1 ] ; localB -> fpz0siyp52 [ 0 ] = ( real32_T ) localP
-> P_99 [ 0 ] ; localB -> fpz0siyp52 [ 1 ] = ( real32_T ) localP -> P_99 [ 1
] ; localB -> ika3nfqja0 [ 0 ] = ( real32_T ) localP -> P_100 [ 0 ] ; localB
-> ika3nfqja0 [ 1 ] = ( real32_T ) localP -> P_100 [ 1 ] ; i45e32y4nf = 0.0F
; fyfe1ira4y [ 0 ] = ( real32_T ) localP -> P_98 [ 0 ] ; fyfe1ira4y [ 1 ] = (
real32_T ) localP -> P_98 [ 1 ] ; fyfe1ira4y [ 2 ] = ( real32_T ) localP ->
P_98 [ 2 ] ; fyfe1ira4y [ 3 ] = ( real32_T ) localP -> P_98 [ 3 ] ; localB ->
bzzzmlodjb [ 0 ] = localP -> P_202 [ 0 ] ; localB -> bzzzmlodjb [ 1 ] =
localP -> P_202 [ 1 ] ; for ( i = 0 ; i < 8 ; i ++ ) { localB -> jlzqvyfs0r [
i ] = ( real32_T ) localP -> P_104 [ i ] ; } for ( i = 0 ; i < 8 ; i ++ ) {
localB -> nz3dzltoa1 [ i ] = ( real32_T ) localP -> P_105 [ i ] ; }
obwiausg33 = 0.0F ; for ( i = 0 ; i < 16 ; i ++ ) { localB ->
pl4id4anyh_cl54gopm0x [ i ] = ( real32_T ) localP -> P_103 [ i ] ; } memcpy (
& localB -> fswkwq0s4m_kkiq3xxxve [ 0 ] , & localP -> P_209 [ 0 ] , sizeof (
real32_T ) << 4U ) ; localB -> azizynqh5l_mbvzarwird [ 0 ] = localP -> P_215
[ 0 ] ; localB -> azizynqh5l_mbvzarwird [ 1 ] = localP -> P_215 [ 1 ] ;
localB -> azizynqh5l_mbvzarwird [ 2 ] = localP -> P_215 [ 2 ] ; localB ->
azizynqh5l_mbvzarwird [ 3 ] = localP -> P_215 [ 3 ] ; } void lsjhvu4egy (
eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex * localP ) { int32_T
k ; int32_T memOffset ; localDW -> dq5lalhp1e = ( int8_T ) localP -> P_229 ;
localDW -> mi4mocbazh = localB -> ijlsdczxaw [ 0 ] ; localDW -> de4yc1bkky =
0U ; localDW -> b3fmbw5stg [ 0 ] += localP -> P_118 * localB -> bb5sk31d0y [
0 ] ; localDW -> mtonzezz2z [ 0 ] = localB -> kcknzyt2kw [ 0 ] ; localDW ->
aq2aymvaio [ 2 ] = localDW -> aq2aymvaio [ 1 ] ; localDW -> ddv3ztj2wp [ 2 ]
= localDW -> ddv3ztj2wp [ 1 ] ; localDW -> b3fmbw5stg [ 1 ] += localP ->
P_118 * localB -> bb5sk31d0y [ 1 ] ; localDW -> mtonzezz2z [ 1 ] = localB ->
kcknzyt2kw [ 1 ] ; localDW -> aq2aymvaio [ 1 ] = localDW -> aq2aymvaio [ 0 ]
; localDW -> ddv3ztj2wp [ 1 ] = localDW -> ddv3ztj2wp [ 0 ] ; localDW ->
aq2aymvaio [ 0 ] = localDW -> orkq4iljgu ; localDW -> ddv3ztj2wp [ 0 ] =
localDW -> f2ynnmexgv ; localDW -> dzwopklw3c += localP -> P_125 * localB ->
gc1nrupvnq ; localDW -> bbkjtf4kuy -- ; if ( localDW -> bbkjtf4kuy < 0 ) {
localDW -> bbkjtf4kuy = 4 ; } localDW -> d4fp3a2mpz [ localDW -> bbkjtf4kuy ]
= localB -> ovcwn4xiv0 [ 0 ] ; localDW -> d4fp3a2mpz [ localDW -> bbkjtf4kuy
+ 5 ] = localB -> ovcwn4xiv0 [ 1 ] ; localDW -> d4fp3a2mpz [ localDW ->
bbkjtf4kuy + 10 ] = localB -> ovcwn4xiv0 [ 2 ] ; localDW -> jd3dqtmo2p = 0U ;
localDW -> f1jy25gy04 = 0U ; localDW -> fl0vv44tbs [ 0 ] = localB ->
pt1nmquqmi [ 0 ] ; localDW -> as5a0ikbk1 [ 0 ] = localB -> kcihrwcew5 [ 0 ] ;
localDW -> fl0vv44tbs [ 1 ] = localB -> pt1nmquqmi [ 1 ] ; localDW ->
as5a0ikbk1 [ 1 ] = localB -> kcihrwcew5 [ 1 ] ; localDW -> l3lcputuyl =
localB -> d3gcj32uev ; localDW -> ncgo1wegzg = localDW -> b1nmhkw4zo ;
localDW -> mirtkskmtr = localDW -> n0mydijbcx ; localDW -> pjgu33zeph =
localB -> aajdjdyozd ; localDW -> gdn4qfzvsk = 0U ; localDW -> jduomia1pb [ 4
] = localDW -> jduomia1pb [ 3 ] ; localDW -> od5c00niot [ 0 ] = localB ->
bhcndqqae3 [ 0 ] ; localDW -> jduomia1pb [ 3 ] = localDW -> jduomia1pb [ 2 ]
; localDW -> od5c00niot [ 1 ] = localB -> bhcndqqae3 [ 1 ] ; localDW ->
jduomia1pb [ 2 ] = localDW -> jduomia1pb [ 1 ] ; localDW -> od5c00niot [ 2 ]
= localB -> bhcndqqae3 [ 2 ] ; localDW -> jduomia1pb [ 1 ] = localDW ->
jduomia1pb [ 0 ] ; localDW -> od5c00niot [ 3 ] = localB -> bhcndqqae3 [ 3 ] ;
localDW -> jduomia1pb [ 0 ] = localDW -> iwg03owvar ; for ( k = 0 ; k < 2 ; k
++ ) { memOffset = k * 5 ; localDW -> dqfv1m130o [ memOffset + 4 ] = localDW
-> dqfv1m130o [ memOffset + 3 ] ; localDW -> dqfv1m130o [ memOffset + 3 ] =
localDW -> dqfv1m130o [ memOffset + 2 ] ; localDW -> dqfv1m130o [ memOffset +
2 ] = localDW -> dqfv1m130o [ memOffset + 1 ] ; localDW -> dqfv1m130o [
memOffset + 1 ] = localDW -> dqfv1m130o [ memOffset ] ; localDW -> dqfv1m130o
[ memOffset ] = localDW -> mf2pp40f5v [ k ] ; localDW -> meognsjf1t [ k ] =
localB -> cf0jaxjxfg [ k ] ; localDW -> gcgpru4rcb [ k ] = localB ->
lbhq3ilsyd [ k ] ; localDW -> peklmaellz [ k ] = localB -> lbhq3ilsyd [ k ] ;
} localDW -> gaxgdudnvc = localB -> es1m4kbygh ; localDW -> bsetqjfri4 +=
localP -> P_148 * localB -> csuamg3cf3 ; if ( localDW -> bsetqjfri4 >= localP
-> P_150 ) { localDW -> bsetqjfri4 = localP -> P_150 ; } else { if ( localDW
-> bsetqjfri4 <= localP -> P_151 ) { localDW -> bsetqjfri4 = localP -> P_151
; } } localDW -> fpr1qi0oiw = ( int8_T ) localB -> pl4id4anyh ; localDW ->
mh4zpxvxof = localB -> aulvpfmy14 ; localDW -> mlv55q4rs4 = localB ->
azizynqh5l ; localDW -> dsjbzv2lh4 [ 0 ] += localP -> P_156 * localB ->
kfvbhjiqtg [ 0 ] ; localDW -> gixvkpnpus [ 0 ] = localDW -> pwlp5beuqs [ 0 ]
; localDW -> ow5xb5ovt0 [ 0 ] += localP -> P_160 * localB -> dwa34yqvis [ 0 ]
; localDW -> krs1cvkxzk [ 0 ] += localP -> P_161 * localB -> jeehrr35n3 [ 0 ]
; localDW -> dsjbzv2lh4 [ 1 ] += localP -> P_156 * localB -> kfvbhjiqtg [ 1 ]
; localDW -> gixvkpnpus [ 1 ] = localDW -> pwlp5beuqs [ 1 ] ; localDW ->
ow5xb5ovt0 [ 1 ] += localP -> P_160 * localB -> dwa34yqvis [ 1 ] ; localDW ->
krs1cvkxzk [ 1 ] += localP -> P_161 * localB -> jeehrr35n3 [ 1 ] ; localDW ->
c4kiksmhh2 += localP -> P_166 * localB -> kyotspzhxf ; localDW -> dxm3w2i52x
= localB -> ae0r0hxav0 ; localDW -> bw2ribqmwm = localB -> ptnoncmuih ;
localDW -> h3csutamah = localB -> audxpwawnl ; localDW -> gxd2vu1ibf = localB
-> cqyqgilres ; localDW -> fxisjak2ua = localB -> l0nu5qcuyl ; } static
boolean_T e4uq03sdk2 ( bjqsgn0csy * obj ) { boolean_T anyInputSizeChanged ;
boolean_T exitg1 ; anyInputSizeChanged = false ; ksm0js2nhsy . inSize [ 0 ] =
4 ; ksm0js2nhsy . inSize [ 1 ] = 9600 ; for ( ksm0js2nhsy . b_k = 0 ;
ksm0js2nhsy . b_k < 6 ; ksm0js2nhsy . b_k ++ ) { ksm0js2nhsy . inSize [
ksm0js2nhsy . b_k + 2 ] = 1 ; } ksm0js2nhsy . b_k = 0 ; exitg1 = false ;
while ( ( ! exitg1 ) && ( ksm0js2nhsy . b_k < 8 ) ) { if ( obj ->
inputVarSize . f1 [ ksm0js2nhsy . b_k ] != ( uint32_T ) ksm0js2nhsy . inSize
[ ksm0js2nhsy . b_k ] ) { anyInputSizeChanged = true ; for ( ksm0js2nhsy .
b_k = 0 ; ksm0js2nhsy . b_k < 8 ; ksm0js2nhsy . b_k ++ ) { obj ->
inputVarSize . f1 [ ksm0js2nhsy . b_k ] = ( uint32_T ) ksm0js2nhsy . inSize [
ksm0js2nhsy . b_k ] ; } exitg1 = true ; } else { ksm0js2nhsy . b_k ++ ; } }
return anyInputSizeChanged ; } static void llg2sedmqv ( uint8_T varargout_1 [
19200 ] , uint8_T varargout_2 [ 19200 ] , uint8_T varargout_3 [ 19200 ] ) {
memset ( & varargout_1 [ 0 ] , 0 , 19200U * sizeof ( uint8_T ) ) ; memset ( &
varargout_2 [ 0 ] , 0 , 19200U * sizeof ( uint8_T ) ) ; memset ( &
varargout_3 [ 0 ] , 0 , 19200U * sizeof ( uint8_T ) ) ; } static void
bljpfp3pka ( bjqsgn0csy * obj , uint8_T varargout_1 [ 19200 ] , uint8_T
varargout_2 [ 19200 ] , uint8_T varargout_3 [ 19200 ] ) { e4uq03sdk2 ( obj )
; llg2sedmqv ( varargout_1 , varargout_2 , varargout_3 ) ; } void ha1ipjbq54
( uint8_T * o3vpgniqky ) { dqykr4eggmg . a34qjyehg2 = b1hr2q0zjh . P_4 ;
ic5jb3movn ( & ksm0js2nhsy . otjykwnhb3s , & dqykr4eggmg . otjykwnhb3s , &
b1hr2q0zjh . otjykwnhb3s ) ; * o3vpgniqky = ksm0js2nhsy . otjykwnhb3s .
igogmbewdc ; } void gwlyno50ln ( void ) { bxsrqc204k ( & dqykr4eggmg .
otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s ) ; dqykr4eggmg . a34qjyehg2 =
b1hr2q0zjh . P_4 ; } void bog0frvixl ( void ) { kegjp2lgms ( & ksm0js2nhsy .
otjykwnhb3s , & dqykr4eggmg . otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s ) ; }
void k3yxem35zg ( void ) { int32_T i ; dqykr4eggmg . jjrfotind4 = true ;
dqykr4eggmg . l152eirbdu . isInitialized = 1 ; dqykr4eggmg . l152eirbdu .
inputVarSize . f1 [ 0 ] = 4U ; dqykr4eggmg . l152eirbdu . inputVarSize . f1 [
1 ] = 9600U ; for ( i = 0 ; i < 6 ; i ++ ) { dqykr4eggmg . l152eirbdu .
inputVarSize . f1 [ i + 2 ] = 1U ; } } void flightControlSystem ( const
CommandBus * iarztl0jur , const SensorsBus * pxdb2gu5va , real32_T pikqq4svts
[ 4 ] , uint8_T * o3vpgniqky ) { ipf5ube4r0 * const accn4cnket = & (
lhjbdsj2rj . rtm ) ; bljpfp3pka ( & dqykr4eggmg . l152eirbdu , ksm0js2nhsy .
b_varargout_1 , ksm0js2nhsy . b_varargout_2 , ksm0js2nhsy . b_varargout_3 ) ;
ksm0js2nhsy . iy = - 1 ; for ( ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < 19200
; ksm0js2nhsy . i ++ ) { ksm0js2nhsy . iy ++ ; ksm0js2nhsy . imgRGB [
ksm0js2nhsy . iy ] = ksm0js2nhsy . b_varargout_1 [ ksm0js2nhsy . i ] ; } for
( ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < 19200 ; ksm0js2nhsy . i ++ ) {
ksm0js2nhsy . iy ++ ; ksm0js2nhsy . imgRGB [ ksm0js2nhsy . iy ] = ksm0js2nhsy
. b_varargout_2 [ ksm0js2nhsy . i ] ; } for ( ksm0js2nhsy . i = 0 ;
ksm0js2nhsy . i < 19200 ; ksm0js2nhsy . i ++ ) { ksm0js2nhsy . iy ++ ;
ksm0js2nhsy . imgRGB [ ksm0js2nhsy . iy ] = ksm0js2nhsy . b_varargout_3 [
ksm0js2nhsy . i ] ; } rgb2hsv_tbb_uint8 ( & ksm0js2nhsy . imgRGB [ 0 ] ,
19200.0 , & ksm0js2nhsy . hsv [ 0 ] , true ) ; for ( ksm0js2nhsy . i = 0 ;
ksm0js2nhsy . i < 160 ; ksm0js2nhsy . i ++ ) { memcpy ( & ksm0js2nhsy .
o2lyn0kysk [ ksm0js2nhsy . i * 120 ] , & ksm0js2nhsy . hsv [ ksm0js2nhsy . i
* 120 ] , 120U * sizeof ( real_T ) ) ; } for ( ksm0js2nhsy . i = 0 ;
ksm0js2nhsy . i < 19200 ; ksm0js2nhsy . i ++ ) { if ( ksm0js2nhsy . hsv [
ksm0js2nhsy . i / 120 * 120 + ksm0js2nhsy . i % 120 ] <= b1hr2q0zjh . P_5 ) {
ksm0js2nhsy . o2lyn0kysk [ ksm0js2nhsy . i ] = 1.0 ; } if ( ksm0js2nhsy .
o2lyn0kysk [ ksm0js2nhsy . i ] <= 0.99 ) { ksm0js2nhsy . o2lyn0kysk [
ksm0js2nhsy . i ] = 0.0 ; } } if ( b1hr2q0zjh . P_6 > 120.0 - b1hr2q0zjh .
P_6 ) { ksm0js2nhsy . iy = 0 ; ksm0js2nhsy . n = 0 ; } else { ksm0js2nhsy .
iy = ( int32_T ) b1hr2q0zjh . P_6 - 1 ; ksm0js2nhsy . n = ( int32_T ) ( 120.0
- b1hr2q0zjh . P_6 ) ; } if ( b1hr2q0zjh . P_6 > 160.0 - b1hr2q0zjh . P_6 ) {
ksm0js2nhsy . idx = 0 ; ksm0js2nhsy . i = 0 ; } else { ksm0js2nhsy . idx = (
int32_T ) b1hr2q0zjh . P_6 - 1 ; ksm0js2nhsy . i = ( int32_T ) ( 160.0 -
b1hr2q0zjh . P_6 ) ; } ksm0js2nhsy . pixListNinc = ksm0js2nhsy . n -
ksm0js2nhsy . iy ; ksm0js2nhsy . ns = ksm0js2nhsy . i - ksm0js2nhsy . idx ;
for ( ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < ksm0js2nhsy . ns ; ksm0js2nhsy
. i ++ ) { for ( ksm0js2nhsy . n = 0 ; ksm0js2nhsy . n < ksm0js2nhsy .
pixListNinc ; ksm0js2nhsy . n ++ ) { ksm0js2nhsy . o2lyn0kysk [ ( ksm0js2nhsy
. iy + ksm0js2nhsy . n ) + 120 * ( ksm0js2nhsy . idx + ksm0js2nhsy . i ) ] =
0.0 ; } } if ( dqykr4eggmg . a34qjyehg2 == 1.0 ) { ksm0js2nhsy .
centroid_idx_0 = b1hr2q0zjh . P_6 * 2.5 ; if ( ksm0js2nhsy . centroid_idx_0 >
120.0 ) { ksm0js2nhsy . iy = - 1 ; ksm0js2nhsy . i = - 1 ; } else {
ksm0js2nhsy . iy = ( int32_T ) ksm0js2nhsy . centroid_idx_0 - 2 ; ksm0js2nhsy
. i = 119 ; } ksm0js2nhsy . idx = ksm0js2nhsy . i - ksm0js2nhsy . iy ; for (
ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < 160 ; ksm0js2nhsy . i ++ ) { for (
ksm0js2nhsy . n = 0 ; ksm0js2nhsy . n < ksm0js2nhsy . idx ; ksm0js2nhsy . n
++ ) { ksm0js2nhsy . o2lyn0kysk [ ( ( ksm0js2nhsy . iy + ksm0js2nhsy . n ) +
120 * ksm0js2nhsy . i ) + 1 ] = 0.0 ; } } } else if ( dqykr4eggmg .
a34qjyehg2 == 2.0 ) { ksm0js2nhsy . centroid_idx_0 = 120.0 - b1hr2q0zjh . P_6
* 2.5 ; if ( 1.0 > ksm0js2nhsy . centroid_idx_0 ) { ksm0js2nhsy . iy = 0 ; }
else { ksm0js2nhsy . iy = ( int32_T ) ksm0js2nhsy . centroid_idx_0 ; } for (
ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < 160 ; ksm0js2nhsy . i ++ ) { for (
ksm0js2nhsy . n = 0 ; ksm0js2nhsy . n < ksm0js2nhsy . iy ; ksm0js2nhsy . n ++
) { ksm0js2nhsy . o2lyn0kysk [ ksm0js2nhsy . n + 120 * ksm0js2nhsy . i ] =
0.0 ; } } } else if ( dqykr4eggmg . a34qjyehg2 == 3.0 ) { ksm0js2nhsy .
centroid_idx_0 = b1hr2q0zjh . P_6 * 2.5 ; if ( ksm0js2nhsy . centroid_idx_0 >
160.0 ) { ksm0js2nhsy . iy = - 1 ; ksm0js2nhsy . i = - 1 ; } else {
ksm0js2nhsy . iy = ( int32_T ) ksm0js2nhsy . centroid_idx_0 - 2 ; ksm0js2nhsy
. i = 159 ; } ksm0js2nhsy . idx = ksm0js2nhsy . i - ksm0js2nhsy . iy ; for (
ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < ksm0js2nhsy . idx ; ksm0js2nhsy . i
++ ) { for ( ksm0js2nhsy . n = 0 ; ksm0js2nhsy . n < 120 ; ksm0js2nhsy . n ++
) { ksm0js2nhsy . o2lyn0kysk [ ksm0js2nhsy . n + 120 * ( ( ksm0js2nhsy . iy +
ksm0js2nhsy . i ) + 1 ) ] = 0.0 ; } } } else { if ( dqykr4eggmg . a34qjyehg2
== 4.0 ) { ksm0js2nhsy . centroid_idx_0 = 160.0 - b1hr2q0zjh . P_6 * 2.5 ; if
( 1.0 > ksm0js2nhsy . centroid_idx_0 ) { ksm0js2nhsy . iy = 0 ; } else {
ksm0js2nhsy . iy = ( int32_T ) ksm0js2nhsy . centroid_idx_0 ; } for (
ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < ksm0js2nhsy . iy ; ksm0js2nhsy . i ++
) { for ( ksm0js2nhsy . n = 0 ; ksm0js2nhsy . n < 120 ; ksm0js2nhsy . n ++ )
{ ksm0js2nhsy . o2lyn0kysk [ ksm0js2nhsy . n + 120 * ksm0js2nhsy . i ] = 0.0
; } } } } for ( ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < 19200 ; ksm0js2nhsy .
i ++ ) { ksm0js2nhsy . jyj4vjw1db [ ksm0js2nhsy . i ] = ! ( ksm0js2nhsy .
o2lyn0kysk [ ksm0js2nhsy . i ] == 0.0 ) ; } ksm0js2nhsy . maxNumBlobsReached
= false ; memset ( & dqykr4eggmg . ldp1hu5bce [ 0 ] , 0 , 123U * sizeof (
uint8_T ) ) ; ksm0js2nhsy . currentLabel = 1U ; ksm0js2nhsy . i = 0 ;
ksm0js2nhsy . idx = 123 ; for ( ksm0js2nhsy . n = 0 ; ksm0js2nhsy . n < 160 ;
ksm0js2nhsy . n ++ ) { for ( ksm0js2nhsy . iy = 0 ; ksm0js2nhsy . iy < 120 ;
ksm0js2nhsy . iy ++ ) { dqykr4eggmg . ldp1hu5bce [ ksm0js2nhsy . idx ] = (
uint8_T ) ( ksm0js2nhsy . jyj4vjw1db [ ksm0js2nhsy . i ] ? 255 : 0 ) ;
ksm0js2nhsy . i ++ ; ksm0js2nhsy . idx ++ ; } dqykr4eggmg . ldp1hu5bce [
ksm0js2nhsy . idx ] = 0U ; dqykr4eggmg . ldp1hu5bce [ ksm0js2nhsy . idx + 1 ]
= 0U ; ksm0js2nhsy . idx += 2 ; } memset ( & dqykr4eggmg . ldp1hu5bce [
ksm0js2nhsy . idx ] , 0 , 121U * sizeof ( uint8_T ) ) ; ksm0js2nhsy . idx = 0
; ksm0js2nhsy . pixIdx = 0U ; ksm0js2nhsy . n = 0 ; while ( ksm0js2nhsy . n <
160 ) { ksm0js2nhsy . pixListNinc = 0 ; ksm0js2nhsy . ns = ( ksm0js2nhsy .
idx + 1 ) * 122 ; ksm0js2nhsy . iy = 0 ; while ( ksm0js2nhsy . iy < 120 ) {
ksm0js2nhsy . padIdx = ( uint32_T ) ( ( ksm0js2nhsy . ns + ksm0js2nhsy .
pixListNinc ) + 1 ) ; ksm0js2nhsy . start_pixIdx = ksm0js2nhsy . pixIdx ; if
( dqykr4eggmg . ldp1hu5bce [ ksm0js2nhsy . padIdx ] == 255 ) { dqykr4eggmg .
ldp1hu5bce [ ksm0js2nhsy . padIdx ] = ksm0js2nhsy . currentLabel ;
dqykr4eggmg . ioh3emfun0 [ ksm0js2nhsy . pixIdx ] = ( int16_T ) ksm0js2nhsy .
idx ; dqykr4eggmg . b3ftvzsipr [ ksm0js2nhsy . pixIdx ] = ( int16_T )
ksm0js2nhsy . pixListNinc ; ksm0js2nhsy . pixIdx ++ ; dqykr4eggmg .
kog3g2sgtz = 1U ; dqykr4eggmg . cj12lkyakd [ 0U ] = ksm0js2nhsy . padIdx ;
ksm0js2nhsy . padIdx = 1U ; while ( ksm0js2nhsy . padIdx != 0U ) {
ksm0js2nhsy . padIdx -- ; ksm0js2nhsy . centerIdx = dqykr4eggmg . cj12lkyakd
[ ksm0js2nhsy . padIdx ] ; for ( ksm0js2nhsy . i = 0 ; ksm0js2nhsy . i < 8 ;
ksm0js2nhsy . i ++ ) { ksm0js2nhsy . walkerIdx = ksm0js2nhsy . centerIdx +
mu24dhzibl1 . logze4k52t [ ksm0js2nhsy . i ] ; if ( dqykr4eggmg . ldp1hu5bce
[ ksm0js2nhsy . walkerIdx ] == 255 ) { dqykr4eggmg . ldp1hu5bce [ ksm0js2nhsy
. walkerIdx ] = ksm0js2nhsy . currentLabel ; dqykr4eggmg . ioh3emfun0 [
ksm0js2nhsy . pixIdx ] = ( int16_T ) ( ( int16_T ) ( ksm0js2nhsy . walkerIdx
/ 122U ) - 1 ) ; dqykr4eggmg . b3ftvzsipr [ ksm0js2nhsy . pixIdx ] = (
int16_T ) ( ksm0js2nhsy . walkerIdx % 122U - 1U ) ; ksm0js2nhsy . pixIdx ++ ;
dqykr4eggmg . kog3g2sgtz ++ ; dqykr4eggmg . cj12lkyakd [ ksm0js2nhsy . padIdx
] = ksm0js2nhsy . walkerIdx ; ksm0js2nhsy . padIdx ++ ; } } } if (
dqykr4eggmg . kog3g2sgtz < b1hr2q0zjh . P_2 ) { ksm0js2nhsy . currentLabel --
; ksm0js2nhsy . pixIdx = ksm0js2nhsy . start_pixIdx ; } if ( ksm0js2nhsy .
currentLabel == 1 ) { ksm0js2nhsy . maxNumBlobsReached = true ; ksm0js2nhsy .
n = 160 ; ksm0js2nhsy . iy = 120 ; } else { ksm0js2nhsy . currentLabel ++ ; }
} ksm0js2nhsy . pixListNinc ++ ; ksm0js2nhsy . iy ++ ; } ksm0js2nhsy . idx ++
; ksm0js2nhsy . n ++ ; } ksm0js2nhsy . n = ksm0js2nhsy . maxNumBlobsReached ?
( int32_T ) ksm0js2nhsy . currentLabel : ( int32_T ) ( uint8_T ) (
ksm0js2nhsy . currentLabel - 1U ) ; ksm0js2nhsy . idx = 0 ; ksm0js2nhsy .
pixListNinc = 0 ; ksm0js2nhsy . i = 0 ; while ( ksm0js2nhsy . i < ksm0js2nhsy
. n ) { ksm0js2nhsy . ns = 0 ; ksm0js2nhsy . ms = 0 ; if ( dqykr4eggmg .
kog3g2sgtz <= 260000U ) { ksm0js2nhsy . iy = 0 ; while ( ksm0js2nhsy . iy < (
int32_T ) dqykr4eggmg . kog3g2sgtz ) { ksm0js2nhsy . ns += dqykr4eggmg .
ioh3emfun0 [ ksm0js2nhsy . iy + ksm0js2nhsy . pixListNinc ] ; ksm0js2nhsy .
ms += dqykr4eggmg . b3ftvzsipr [ ksm0js2nhsy . iy + ksm0js2nhsy . idx ] ;
ksm0js2nhsy . iy ++ ; } ksm0js2nhsy . centroid_idx_0 = ( real_T ) ksm0js2nhsy
. ms / ( real_T ) dqykr4eggmg . kog3g2sgtz ; ksm0js2nhsy . centroid_idx_1 = (
real_T ) ksm0js2nhsy . ns / ( real_T ) dqykr4eggmg . kog3g2sgtz ; } else {
ksm0js2nhsy . numLoops = ( int32_T ) ( ( real_T ) dqykr4eggmg . kog3g2sgtz /
260000.0 ) ; ksm0js2nhsy . centroid_idx_0 = 0.0 ; ksm0js2nhsy .
centroid_idx_1 = 0.0 ; ksm0js2nhsy . p = 0 ; while ( ksm0js2nhsy . p <
ksm0js2nhsy . numLoops ) { ksm0js2nhsy . ns = 0 ; ksm0js2nhsy . ms = 0 ; for
( ksm0js2nhsy . iy = 0 ; ksm0js2nhsy . iy < 260000 ; ksm0js2nhsy . iy ++ ) {
ksm0js2nhsy . ns += dqykr4eggmg . ioh3emfun0 [ ( ksm0js2nhsy . pixListNinc +
ksm0js2nhsy . iy ) + ksm0js2nhsy . p * 260000 ] ; ksm0js2nhsy . ms +=
dqykr4eggmg . b3ftvzsipr [ ( ksm0js2nhsy . idx + ksm0js2nhsy . iy ) +
ksm0js2nhsy . p * 260000 ] ; } ksm0js2nhsy . centroid_idx_0 += ( real_T )
ksm0js2nhsy . ms / ( real_T ) dqykr4eggmg . kog3g2sgtz ; ksm0js2nhsy .
centroid_idx_1 += ( real_T ) ksm0js2nhsy . ns / ( real_T ) dqykr4eggmg .
kog3g2sgtz ; ksm0js2nhsy . p ++ ; } ksm0js2nhsy . ns = 0 ; ksm0js2nhsy . ms =
0 ; ksm0js2nhsy . numLoops *= 260000 ; ksm0js2nhsy . p = ( int32_T ) (
dqykr4eggmg . kog3g2sgtz - ksm0js2nhsy . numLoops ) ; ksm0js2nhsy . iy = 0 ;
while ( ksm0js2nhsy . iy < ksm0js2nhsy . p ) { ksm0js2nhsy . ns +=
dqykr4eggmg . ioh3emfun0 [ ( ksm0js2nhsy . iy + ksm0js2nhsy . pixListNinc ) +
ksm0js2nhsy . numLoops ] ; ksm0js2nhsy . ms += dqykr4eggmg . b3ftvzsipr [ (
ksm0js2nhsy . iy + ksm0js2nhsy . idx ) + ksm0js2nhsy . numLoops ] ;
ksm0js2nhsy . iy ++ ; } ksm0js2nhsy . centroid_idx_0 += ( real_T )
ksm0js2nhsy . ms / ( real_T ) dqykr4eggmg . kog3g2sgtz ; ksm0js2nhsy .
centroid_idx_1 += ( real_T ) ksm0js2nhsy . ns / ( real_T ) dqykr4eggmg .
kog3g2sgtz ; } ksm0js2nhsy . eavemda1lk_mbvzarwird [ ksm0js2nhsy . i ] =
ksm0js2nhsy . centroid_idx_1 + 1.0 ; ksm0js2nhsy . eavemda1lk_mbvzarwird [
ksm0js2nhsy . i + 1U ] = ksm0js2nhsy . centroid_idx_0 + 1.0 ; ksm0js2nhsy .
idx += ( int32_T ) dqykr4eggmg . kog3g2sgtz ; ksm0js2nhsy . pixListNinc += (
int32_T ) dqykr4eggmg . kog3g2sgtz ; ksm0js2nhsy . i ++ ; } ksm0js2nhsy .
eavemda1lk_mbvzarwird [ 0 ] += b1hr2q0zjh . P_7 [ 0 ] ; ksm0js2nhsy .
centroid_idx_0 = b1hr2q0zjh . P_7 [ 1 ] + ksm0js2nhsy . eavemda1lk_mbvzarwird
[ 1 ] ; if ( 60.0 - ksm0js2nhsy . centroid_idx_0 > 40.0 ) { ksm0js2nhsy .
py4lbfe4av = 1.0 ; } else if ( 60.0 - ksm0js2nhsy . centroid_idx_0 < - 40.0 )
{ ksm0js2nhsy . py4lbfe4av = 2.0 ; } else if ( ksm0js2nhsy .
eavemda1lk_mbvzarwird [ 0 ] - 80.0 > 60.0 ) { ksm0js2nhsy . py4lbfe4av = 4.0
; } else if ( ksm0js2nhsy . eavemda1lk_mbvzarwird [ 0 ] - 80.0 < - 60.0 ) {
ksm0js2nhsy . py4lbfe4av = 3.0 ; } else { ksm0js2nhsy . py4lbfe4av = 0.0 ; }
ksm0js2nhsy . nrf0fqeiex_cl54gopm0x [ 0 ] = ( ksm0js2nhsy .
eavemda1lk_mbvzarwird [ 0 ] - 80.0 ) * ( real_T ) ksm0js2nhsy . n ;
ksm0js2nhsy . nrf0fqeiex_cl54gopm0x [ 1 ] = ( 60.0 - ksm0js2nhsy .
centroid_idx_0 ) * ( real_T ) ksm0js2nhsy . n ; otjykwnhb3 ( accn4cnket ,
iarztl0jur , pxdb2gu5va , ksm0js2nhsy . nrf0fqeiex_cl54gopm0x , & ksm0js2nhsy
. otjykwnhb3s , & dqykr4eggmg . otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s , &
f51itwtzkqf . otjykwnhb3s ) ; pikqq4svts [ 0 ] = ksm0js2nhsy . otjykwnhb3s .
p4vhxsp0g0 [ 0 ] ; pikqq4svts [ 1 ] = ksm0js2nhsy . otjykwnhb3s . p4vhxsp0g0
[ 1 ] ; pikqq4svts [ 2 ] = ksm0js2nhsy . otjykwnhb3s . p4vhxsp0g0 [ 2 ] ;
pikqq4svts [ 3 ] = ksm0js2nhsy . otjykwnhb3s . p4vhxsp0g0 [ 3 ] ; *
o3vpgniqky = ksm0js2nhsy . otjykwnhb3s . igogmbewdc ; } void
flightControlSystemTID1 ( void ) { boolean_T c34bonbmeq ; otjykwnhb3TID1 ( &
ksm0js2nhsy . otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s ) ; c34bonbmeq = ( ( (
0.0 - 0.0 / b1hr2q0zjh . P_8 ) - 1.0 / b1hr2q0zjh . P_8 * 0.0 > b1hr2q0zjh .
P_1 ) > b1hr2q0zjh . P_3 ) ; } void pyvd4pdf3i ( void ) { dqykr4eggmg .
a34qjyehg2 = ksm0js2nhsy . py4lbfe4av ; lsjhvu4egy ( & ksm0js2nhsy .
otjykwnhb3s , & dqykr4eggmg . otjykwnhb3s , & b1hr2q0zjh . otjykwnhb3s ) ; }
void pyvd4pdf3iTID1 ( void ) { } void o2f5l50guo ( void ) { ipf5ube4r0 *
const accn4cnket = & ( lhjbdsj2rj . rtm ) ; if ( !
slIsRapidAcceleratorSimulating ( ) ) { slmrRunPluginEvent ( accn4cnket ->
_mdlRefSfcnS , "flightControlSystem" ,
"SIMSTATUS_TERMINATING_MODELREF_ACCEL_EVENT" ) ; } } void f4qzdbbxmw (
SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T mdlref_TID1 , void *
sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo * rt_ParentMMI , const
char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T rt_CSTATEIdx ) {
ipf5ube4r0 * const accn4cnket = & ( lhjbdsj2rj . rtm ) ; rt_InitInfAndNaN (
sizeof ( real_T ) ) ; b1hr2q0zjh . otjykwnhb3s . P_57 = rtMinusInf ; ( void )
memset ( ( void * ) accn4cnket , 0 , sizeof ( ipf5ube4r0 ) ) ; nmtwkzsqud [ 0
] = mdlref_TID0 ; nmtwkzsqud [ 1 ] = mdlref_TID1 ; accn4cnket -> _mdlRefSfcnS
= ( _mdlRefSfcnS ) ; if ( ! slIsRapidAcceleratorSimulating ( ) ) {
slmrRunPluginEvent ( accn4cnket -> _mdlRefSfcnS , "flightControlSystem" ,
"START_OF_SIM_MODEL_MODELREF_ACCEL_EVENT" ) ; } ( void ) memset ( ( ( void *
) & ksm0js2nhsy ) , 0 , sizeof ( ircitwx3zdm ) ) ; { int32_T i ; for ( i = 0
; i < 19200 ; i ++ ) { ksm0js2nhsy . o2lyn0kysk [ i ] = 0.0 ; } for ( i = 0 ;
i < 6 ; i ++ ) { ksm0js2nhsy . otjykwnhb3s . ovcwn4xiv0 [ i ] = 0.0F ; } for
( i = 0 ; i < 16 ; i ++ ) { ksm0js2nhsy . otjykwnhb3s . av0imjbvtg [ i ] =
0.0F ; } for ( i = 0 ; i < 8 ; i ++ ) { ksm0js2nhsy . otjykwnhb3s .
jlzqvyfs0r [ i ] = 0.0F ; } for ( i = 0 ; i < 8 ; i ++ ) { ksm0js2nhsy .
otjykwnhb3s . nz3dzltoa1 [ i ] = 0.0F ; } ksm0js2nhsy . py4lbfe4av = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . gldligh2fw = 0.0 ; ksm0js2nhsy . otjykwnhb3s .
ijlsdczxaw [ 0 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . ijlsdczxaw [ 1 ] = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . aulvpfmy14 = 0.0 ; ksm0js2nhsy . otjykwnhb3s .
azizynqh5l = 0.0 ; ksm0js2nhsy . otjykwnhb3s . ptnoncmuih = 0.0 ; ksm0js2nhsy
. otjykwnhb3s . audxpwawnl = 0.0 ; ksm0js2nhsy . otjykwnhb3s . cqyqgilres =
0.0 ; ksm0js2nhsy . otjykwnhb3s . lfda2u1mt3 [ 0 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . lfda2u1mt3 [ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . lfda2u1mt3
[ 2 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . kcknzyt2kw [ 0 ] = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . kcknzyt2kw [ 1 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . csnxbqta3d [ 0 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . csnxbqta3d
[ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . nuftjfb4tr [ 0 ] = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . nuftjfb4tr [ 1 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . bkasatad0l [ 0 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . bkasatad0l
[ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . ga0ou2qbzf [ 0 ] = 0.0 ;
ksm0js2nhsy . otjykwnhb3s . ga0ou2qbzf [ 1 ] = 0.0 ; ksm0js2nhsy .
otjykwnhb3s . gisde2u3xx [ 0 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . gisde2u3xx
[ 1 ] = 0.0 ; ksm0js2nhsy . otjykwnhb3s . dmgkungty4 = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . oktwcxigco = 0.0F ; ksm0js2nhsy . otjykwnhb3s . gchaygbwpg =
0.0F ; ksm0js2nhsy . otjykwnhb3s . bevd1uolnu = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . gc1nrupvnq = 0.0F ; ksm0js2nhsy . otjykwnhb3s . l5nzgayjhs [ 0
] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . l5nzgayjhs [ 1 ] = 0.0F ; ksm0js2nhsy
. otjykwnhb3s . cf0jaxjxfg [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
cf0jaxjxfg [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . lbhq3ilsyd [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . lbhq3ilsyd [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . lbhq3ilsyd [ 2 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
lbhq3ilsyd [ 3 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . csuamg3cf3 = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . jeehrr35n3 [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . jeehrr35n3 [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
dwa34yqvis [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . dwa34yqvis [ 1 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . kfvbhjiqtg [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . kfvbhjiqtg [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
kyotspzhxf = 0.0F ; ksm0js2nhsy . otjykwnhb3s . p4vhxsp0g0 [ 0 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . p4vhxsp0g0 [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . p4vhxsp0g0 [ 2 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
p4vhxsp0g0 [ 3 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . pt1nmquqmi [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . pt1nmquqmi [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . kcihrwcew5 [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
kcihrwcew5 [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . aqes0fqnpu [ 0 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . aqes0fqnpu [ 1 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . bhcndqqae3 [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
bhcndqqae3 [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . bhcndqqae3 [ 2 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . bhcndqqae3 [ 3 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . bb5sk31d0y [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
bb5sk31d0y [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . bb5sk31d0y [ 2 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . a2gs1s4oet [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . a2gs1s4oet [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
gijmevwnbh [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . gijmevwnbh [ 1 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . bacemjpimt [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . bacemjpimt [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
fpz0siyp52 [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . fpz0siyp52 [ 1 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . ika3nfqja0 [ 0 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . ika3nfqja0 [ 1 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
bzzzmlodjb [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . bzzzmlodjb [ 1 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . azizynqh5l_mbvzarwird [ 0 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . azizynqh5l_mbvzarwird [ 1 ] = 0.0F ; ksm0js2nhsy
. otjykwnhb3s . azizynqh5l_mbvzarwird [ 2 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . azizynqh5l_mbvzarwird [ 3 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s
. a3za0mi1jb [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . a3za0mi1jb [ 1 ] =
0.0F ; ksm0js2nhsy . otjykwnhb3s . a3za0mi1jb [ 2 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . a3za0mi1jb [ 3 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
n04moqscwc [ 0 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s . n04moqscwc [ 1 ] = 0.0F
; ksm0js2nhsy . otjykwnhb3s . n04moqscwc [ 2 ] = 0.0F ; ksm0js2nhsy .
otjykwnhb3s . n04moqscwc [ 3 ] = 0.0F ; ksm0js2nhsy . otjykwnhb3s .
hjgsbndjmh = 0.0F ; ksm0js2nhsy . otjykwnhb3s . ipbtas1tys . dd1c4ibcll [ 0 ]
= 0.0F ; ksm0js2nhsy . otjykwnhb3s . ipbtas1tys . dd1c4ibcll [ 1 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . bm3dpymkhz . atkm3eb3zr [ 0 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . bm3dpymkhz . atkm3eb3zr [ 1 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . ifzbhw4mrws . dd1c4ibcll [ 0 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . ifzbhw4mrws . dd1c4ibcll [ 1 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . phrpuocqmvu . atkm3eb3zr [ 0 ] = 0.0F ;
ksm0js2nhsy . otjykwnhb3s . phrpuocqmvu . atkm3eb3zr [ 1 ] = 0.0F ; } ( void
) memset ( ( void * ) & dqykr4eggmg , 0 , sizeof ( nllkaxiwhzw ) ) ;
dqykr4eggmg . a34qjyehg2 = 0.0 ; dqykr4eggmg . otjykwnhb3s . mi4mocbazh = 0.0
; dqykr4eggmg . otjykwnhb3s . mtonzezz2z [ 0 ] = 0.0 ; dqykr4eggmg .
otjykwnhb3s . mtonzezz2z [ 1 ] = 0.0 ; dqykr4eggmg . otjykwnhb3s . ddv3ztj2wp
[ 0 ] = 0.0 ; dqykr4eggmg . otjykwnhb3s . ddv3ztj2wp [ 1 ] = 0.0 ;
dqykr4eggmg . otjykwnhb3s . ddv3ztj2wp [ 2 ] = 0.0 ; dqykr4eggmg .
otjykwnhb3s . mh4zpxvxof = 0.0 ; dqykr4eggmg . otjykwnhb3s . mlv55q4rs4 = 0.0
; dqykr4eggmg . otjykwnhb3s . bw2ribqmwm = 0.0 ; dqykr4eggmg . otjykwnhb3s .
pvooxnzvxd = 0.0 ; dqykr4eggmg . otjykwnhb3s . gxd2vu1ibf = 0.0 ; dqykr4eggmg
. otjykwnhb3s . f2ynnmexgv = 0.0 ; dqykr4eggmg . otjykwnhb3s . h3csutamah =
0.0 ; dqykr4eggmg . otjykwnhb3s . js3ly0p0tr = 0.0 ; dqykr4eggmg .
otjykwnhb3s . b3fmbw5stg [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
b3fmbw5stg [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . aq2aymvaio [ 0 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . aq2aymvaio [ 1 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . aq2aymvaio [ 2 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
dzwopklw3c = 0.0F ; { int32_T i ; for ( i = 0 ; i < 15 ; i ++ ) { dqykr4eggmg
. otjykwnhb3s . d4fp3a2mpz [ i ] = 0.0F ; } } dqykr4eggmg . otjykwnhb3s .
fl0vv44tbs [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . fl0vv44tbs [ 1 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . as5a0ikbk1 [ 0 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . as5a0ikbk1 [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
ncgo1wegzg = 0.0F ; dqykr4eggmg . otjykwnhb3s . mirtkskmtr = 0.0F ; { int32_T
i ; for ( i = 0 ; i < 5 ; i ++ ) { dqykr4eggmg . otjykwnhb3s . jduomia1pb [ i
] = 0.0F ; } } dqykr4eggmg . otjykwnhb3s . od5c00niot [ 0 ] = 0.0F ;
dqykr4eggmg . otjykwnhb3s . od5c00niot [ 1 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . od5c00niot [ 2 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
od5c00niot [ 3 ] = 0.0F ; { int32_T i ; for ( i = 0 ; i < 10 ; i ++ ) {
dqykr4eggmg . otjykwnhb3s . dqfv1m130o [ i ] = 0.0F ; } } dqykr4eggmg .
otjykwnhb3s . meognsjf1t [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
meognsjf1t [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . gcgpru4rcb [ 0 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . gcgpru4rcb [ 1 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . peklmaellz [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
peklmaellz [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . bsetqjfri4 = 0.0F ;
dqykr4eggmg . otjykwnhb3s . dsjbzv2lh4 [ 0 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . dsjbzv2lh4 [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
gixvkpnpus [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . gixvkpnpus [ 1 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . ow5xb5ovt0 [ 0 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . ow5xb5ovt0 [ 1 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
krs1cvkxzk [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s . krs1cvkxzk [ 1 ] = 0.0F
; dqykr4eggmg . otjykwnhb3s . c4kiksmhh2 = 0.0F ; dqykr4eggmg . otjykwnhb3s .
orkq4iljgu = 0.0F ; dqykr4eggmg . otjykwnhb3s . b1nmhkw4zo = 0.0F ;
dqykr4eggmg . otjykwnhb3s . n0mydijbcx = 0.0F ; dqykr4eggmg . otjykwnhb3s .
iwg03owvar = 0.0F ; dqykr4eggmg . otjykwnhb3s . mf2pp40f5v [ 0 ] = 0.0F ;
dqykr4eggmg . otjykwnhb3s . mf2pp40f5v [ 1 ] = 0.0F ; dqykr4eggmg .
otjykwnhb3s . pwlp5beuqs [ 0 ] = 0.0F ; dqykr4eggmg . otjykwnhb3s .
pwlp5beuqs [ 1 ] = 0.0F ; flightControlSystem_InitializeDataMapInfo (
accn4cnket , sysRanPtr , contextTid ) ; if ( ( rt_ParentMMI != ( NULL ) ) &&
( rt_ChildPath != ( NULL ) ) ) { rtwCAPI_SetChildMMI ( * rt_ParentMMI ,
rt_ChildMMIIdx , & ( accn4cnket -> DataMapInfo . mmi ) ) ; rtwCAPI_SetPath (
accn4cnket -> DataMapInfo . mmi , rt_ChildPath ) ;
rtwCAPI_MMISetContStateStartIndex ( accn4cnket -> DataMapInfo . mmi ,
rt_CSTATEIdx ) ; } f51itwtzkqf . otjykwnhb3s . b1rw3rggh2 =
UNINITIALIZED_ZCSIG ; } void mr_flightControlSystem_MdlInfoRegFcn ( SimStruct
* mdlRefSfcnS , char_T * modelName , int_T * retVal ) { * retVal = 0 ; {
boolean_T regSubmodelsMdlinfo = false ; ssGetRegSubmodelsMdlinfo (
mdlRefSfcnS , & regSubmodelsMdlinfo ) ; if ( regSubmodelsMdlinfo ) { } } *
retVal = 0 ; ssRegModelRefMdlInfo ( mdlRefSfcnS , modelName ,
rtMdlInfo_flightControlSystem , 181 ) ; * retVal = 1 ; } static void
mr_flightControlSystem_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) ; static void
mr_flightControlSystem_cacheDataAsMxArray ( mxArray * destArray , mwIndex i ,
int j , const void * srcData , size_t numBytes ) { mxArray * newArray =
mxCreateUninitNumericMatrix ( ( size_t ) 1 , numBytes , mxUINT8_CLASS ,
mxREAL ) ; memcpy ( ( uint8_T * ) mxGetData ( newArray ) , ( const uint8_T *
) srcData , numBytes ) ; mxSetFieldByNumber ( destArray , i , j , newArray )
; } static void mr_flightControlSystem_restoreDataFromMxArray ( void *
destData , const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) ;
static void mr_flightControlSystem_restoreDataFromMxArray ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , size_t numBytes ) { memcpy ( (
uint8_T * ) destData , ( const uint8_T * ) mxGetData ( mxGetFieldByNumber (
srcArray , i , j ) ) , numBytes ) ; } static void
mr_flightControlSystem_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) ; static void
mr_flightControlSystem_cacheBitFieldToMxArray ( mxArray * destArray , mwIndex
i , int j , uint_T bitVal ) { mxSetFieldByNumber ( destArray , i , j ,
mxCreateDoubleScalar ( ( double ) bitVal ) ) ; } static uint_T
mr_flightControlSystem_extractBitFieldFromMxArray ( const mxArray * srcArray
, mwIndex i , int j , uint_T numBits ) ; static uint_T
mr_flightControlSystem_extractBitFieldFromMxArray ( const mxArray * srcArray
, mwIndex i , int j , uint_T numBits ) { const uint_T varVal = ( uint_T )
mxGetScalar ( mxGetFieldByNumber ( srcArray , i , j ) ) ; return varVal & ( (
1u << numBits ) - 1u ) ; } static void
mr_flightControlSystem_cacheDataToMxArrayWithOffset ( mxArray * destArray ,
mwIndex i , int j , mwIndex offset , const void * srcData , size_t numBytes )
; static void mr_flightControlSystem_cacheDataToMxArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , const void * srcData ,
size_t numBytes ) { uint8_T * varData = ( uint8_T * ) mxGetData (
mxGetFieldByNumber ( destArray , i , j ) ) ; memcpy ( ( uint8_T * ) & varData
[ offset * numBytes ] , ( const uint8_T * ) srcData , numBytes ) ; } static
void mr_flightControlSystem_restoreDataFromMxArrayWithOffset ( void *
destData , const mxArray * srcArray , mwIndex i , int j , mwIndex offset ,
size_t numBytes ) ; static void
mr_flightControlSystem_restoreDataFromMxArrayWithOffset ( void * destData ,
const mxArray * srcArray , mwIndex i , int j , mwIndex offset , size_t
numBytes ) { const uint8_T * varData = ( const uint8_T * ) mxGetData (
mxGetFieldByNumber ( srcArray , i , j ) ) ; memcpy ( ( uint8_T * ) destData ,
( const uint8_T * ) & varData [ offset * numBytes ] , numBytes ) ; } static
void mr_flightControlSystem_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) ; static
void mr_flightControlSystem_cacheBitFieldToCellArrayWithOffset ( mxArray *
destArray , mwIndex i , int j , mwIndex offset , uint_T fieldVal ) {
mxSetCell ( mxGetFieldByNumber ( destArray , i , j ) , offset ,
mxCreateDoubleScalar ( ( double ) fieldVal ) ) ; } static uint_T
mr_flightControlSystem_extractBitFieldFromCellArrayWithOffset ( const mxArray
* srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) ; static
uint_T mr_flightControlSystem_extractBitFieldFromCellArrayWithOffset ( const
mxArray * srcArray , mwIndex i , int j , mwIndex offset , uint_T numBits ) {
const uint_T fieldVal = ( uint_T ) mxGetScalar ( mxGetCell (
mxGetFieldByNumber ( srcArray , i , j ) , offset ) ) ; return fieldVal & ( (
1u << numBits ) - 1u ) ; } mxArray * mr_flightControlSystem_GetDWork ( ) {
static const char * ssDWFieldNames [ 3 ] = { "ksm0js2nhsy" , "dqykr4eggmg" ,
"f51itwtzkqf" , } ; mxArray * ssDW = mxCreateStructMatrix ( 1 , 1 , 3 ,
ssDWFieldNames ) ; mr_flightControlSystem_cacheDataAsMxArray ( ssDW , 0 , 0 ,
& ( ksm0js2nhsy ) , sizeof ( ksm0js2nhsy ) ) ; { static const char *
rtdwDataFieldNames [ 79 ] = { "dqykr4eggmg.cj12lkyakd" ,
"dqykr4eggmg.b3ftvzsipr" , "dqykr4eggmg.ioh3emfun0" ,
"dqykr4eggmg.ldp1hu5bce" , "dqykr4eggmg.l152eirbdu" ,
"dqykr4eggmg.a34qjyehg2" , "dqykr4eggmg.kog3g2sgtz" ,
"dqykr4eggmg.jjrfotind4" , "dqykr4eggmg.otjykwnhb3s.mi4mocbazh" ,
"dqykr4eggmg.otjykwnhb3s.mtonzezz2z" , "dqykr4eggmg.otjykwnhb3s.ddv3ztj2wp" ,
"dqykr4eggmg.otjykwnhb3s.mh4zpxvxof" , "dqykr4eggmg.otjykwnhb3s.mlv55q4rs4" ,
"dqykr4eggmg.otjykwnhb3s.bw2ribqmwm" , "dqykr4eggmg.otjykwnhb3s.pvooxnzvxd" ,
"dqykr4eggmg.otjykwnhb3s.gxd2vu1ibf" , "dqykr4eggmg.otjykwnhb3s.f2ynnmexgv" ,
"dqykr4eggmg.otjykwnhb3s.h3csutamah" , "dqykr4eggmg.otjykwnhb3s.js3ly0p0tr" ,
"dqykr4eggmg.otjykwnhb3s.b3fmbw5stg" , "dqykr4eggmg.otjykwnhb3s.aq2aymvaio" ,
"dqykr4eggmg.otjykwnhb3s.dzwopklw3c" , "dqykr4eggmg.otjykwnhb3s.d4fp3a2mpz" ,
"dqykr4eggmg.otjykwnhb3s.fl0vv44tbs" , "dqykr4eggmg.otjykwnhb3s.as5a0ikbk1" ,
"dqykr4eggmg.otjykwnhb3s.ncgo1wegzg" , "dqykr4eggmg.otjykwnhb3s.mirtkskmtr" ,
"dqykr4eggmg.otjykwnhb3s.jduomia1pb" , "dqykr4eggmg.otjykwnhb3s.od5c00niot" ,
"dqykr4eggmg.otjykwnhb3s.dqfv1m130o" , "dqykr4eggmg.otjykwnhb3s.meognsjf1t" ,
"dqykr4eggmg.otjykwnhb3s.gcgpru4rcb" , "dqykr4eggmg.otjykwnhb3s.peklmaellz" ,
"dqykr4eggmg.otjykwnhb3s.bsetqjfri4" , "dqykr4eggmg.otjykwnhb3s.dsjbzv2lh4" ,
"dqykr4eggmg.otjykwnhb3s.gixvkpnpus" , "dqykr4eggmg.otjykwnhb3s.ow5xb5ovt0" ,
"dqykr4eggmg.otjykwnhb3s.krs1cvkxzk" , "dqykr4eggmg.otjykwnhb3s.c4kiksmhh2" ,
"dqykr4eggmg.otjykwnhb3s.bbkjtf4kuy" , "dqykr4eggmg.otjykwnhb3s.l3lcputuyl" ,
"dqykr4eggmg.otjykwnhb3s.pjgu33zeph" , "dqykr4eggmg.otjykwnhb3s.dxm3w2i52x" ,
"dqykr4eggmg.otjykwnhb3s.orkq4iljgu" , "dqykr4eggmg.otjykwnhb3s.b1nmhkw4zo" ,
"dqykr4eggmg.otjykwnhb3s.n0mydijbcx" , "dqykr4eggmg.otjykwnhb3s.iwg03owvar" ,
"dqykr4eggmg.otjykwnhb3s.mf2pp40f5v" , "dqykr4eggmg.otjykwnhb3s.pwlp5beuqs" ,
"dqykr4eggmg.otjykwnhb3s.gaxgdudnvc" , "dqykr4eggmg.otjykwnhb3s.fxisjak2ua" ,
"dqykr4eggmg.otjykwnhb3s.dq5lalhp1e" , "dqykr4eggmg.otjykwnhb3s.fpr1qi0oiw" ,
"dqykr4eggmg.otjykwnhb3s.klyrn0mwhb" , "dqykr4eggmg.otjykwnhb3s.mfifybuxty" ,
"dqykr4eggmg.otjykwnhb3s.a1oodzfxvv" , "dqykr4eggmg.otjykwnhb3s.mgysgsd2g4" ,
"dqykr4eggmg.otjykwnhb3s.idn2v5d33m" , "dqykr4eggmg.otjykwnhb3s.de4yc1bkky" ,
"dqykr4eggmg.otjykwnhb3s.jd3dqtmo2p" , "dqykr4eggmg.otjykwnhb3s.f1jy25gy04" ,
"dqykr4eggmg.otjykwnhb3s.gdn4qfzvsk" , "dqykr4eggmg.otjykwnhb3s.cqi2pi21ow" ,
"dqykr4eggmg.otjykwnhb3s.kh1khihcrt" , "dqykr4eggmg.otjykwnhb3s.iftedegxuv" ,
"dqykr4eggmg.otjykwnhb3s.g4zcogq4xi" ,
"dqykr4eggmg.otjykwnhb3s.ipbtas1tys.ley0an2uip" ,
"dqykr4eggmg.otjykwnhb3s.ipbtas1tys.njk4w5jozv" ,
"dqykr4eggmg.otjykwnhb3s.bm3dpymkhz.mkkaskumzr" ,
"dqykr4eggmg.otjykwnhb3s.bm3dpymkhz.jhr0womnye" ,
"dqykr4eggmg.otjykwnhb3s.ifzbhw4mrws.ley0an2uip" ,
"dqykr4eggmg.otjykwnhb3s.ifzbhw4mrws.njk4w5jozv" ,
"dqykr4eggmg.otjykwnhb3s.phrpuocqmvu.mkkaskumzr" ,
"dqykr4eggmg.otjykwnhb3s.phrpuocqmvu.jhr0womnye" ,
"dqykr4eggmg.otjykwnhb3s.ciy1c2o0rv.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.jvbbqhrajh.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.clwiujjdqo.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.acfz1zxm4t.fau3qf03xm" ,
"dqykr4eggmg.otjykwnhb3s.ghadbep3bbv.fau3qf03xm" , } ; mxArray * rtdwData =
mxCreateStructMatrix ( 1 , 1 , 79 , rtdwDataFieldNames ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 0 , & (
dqykr4eggmg . cj12lkyakd ) , sizeof ( dqykr4eggmg . cj12lkyakd ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 1 , & (
dqykr4eggmg . b3ftvzsipr ) , sizeof ( dqykr4eggmg . b3ftvzsipr ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 2 , & (
dqykr4eggmg . ioh3emfun0 ) , sizeof ( dqykr4eggmg . ioh3emfun0 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 3 , & (
dqykr4eggmg . ldp1hu5bce ) , sizeof ( dqykr4eggmg . ldp1hu5bce ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 4 , & (
dqykr4eggmg . l152eirbdu ) , sizeof ( dqykr4eggmg . l152eirbdu ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 5 , & (
dqykr4eggmg . a34qjyehg2 ) , sizeof ( dqykr4eggmg . a34qjyehg2 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 6 , & (
dqykr4eggmg . kog3g2sgtz ) , sizeof ( dqykr4eggmg . kog3g2sgtz ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 7 , & (
dqykr4eggmg . jjrfotind4 ) , sizeof ( dqykr4eggmg . jjrfotind4 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 8 , & (
dqykr4eggmg . otjykwnhb3s . mi4mocbazh ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. mi4mocbazh ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
9 , & ( dqykr4eggmg . otjykwnhb3s . mtonzezz2z ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . mtonzezz2z ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 10 , & ( dqykr4eggmg . otjykwnhb3s . ddv3ztj2wp ) , sizeof (
dqykr4eggmg . otjykwnhb3s . ddv3ztj2wp ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 11 , & (
dqykr4eggmg . otjykwnhb3s . mh4zpxvxof ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. mh4zpxvxof ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
12 , & ( dqykr4eggmg . otjykwnhb3s . mlv55q4rs4 ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . mlv55q4rs4 ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 13 , & ( dqykr4eggmg . otjykwnhb3s . bw2ribqmwm ) , sizeof (
dqykr4eggmg . otjykwnhb3s . bw2ribqmwm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 14 , & (
dqykr4eggmg . otjykwnhb3s . pvooxnzvxd ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. pvooxnzvxd ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
15 , & ( dqykr4eggmg . otjykwnhb3s . gxd2vu1ibf ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . gxd2vu1ibf ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 16 , & ( dqykr4eggmg . otjykwnhb3s . f2ynnmexgv ) , sizeof (
dqykr4eggmg . otjykwnhb3s . f2ynnmexgv ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 17 , & (
dqykr4eggmg . otjykwnhb3s . h3csutamah ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. h3csutamah ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
18 , & ( dqykr4eggmg . otjykwnhb3s . js3ly0p0tr ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . js3ly0p0tr ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 19 , & ( dqykr4eggmg . otjykwnhb3s . b3fmbw5stg ) , sizeof (
dqykr4eggmg . otjykwnhb3s . b3fmbw5stg ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 20 , & (
dqykr4eggmg . otjykwnhb3s . aq2aymvaio ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. aq2aymvaio ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
21 , & ( dqykr4eggmg . otjykwnhb3s . dzwopklw3c ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . dzwopklw3c ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 22 , & ( dqykr4eggmg . otjykwnhb3s . d4fp3a2mpz ) , sizeof (
dqykr4eggmg . otjykwnhb3s . d4fp3a2mpz ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 23 , & (
dqykr4eggmg . otjykwnhb3s . fl0vv44tbs ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. fl0vv44tbs ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
24 , & ( dqykr4eggmg . otjykwnhb3s . as5a0ikbk1 ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . as5a0ikbk1 ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 25 , & ( dqykr4eggmg . otjykwnhb3s . ncgo1wegzg ) , sizeof (
dqykr4eggmg . otjykwnhb3s . ncgo1wegzg ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 26 , & (
dqykr4eggmg . otjykwnhb3s . mirtkskmtr ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. mirtkskmtr ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
27 , & ( dqykr4eggmg . otjykwnhb3s . jduomia1pb ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . jduomia1pb ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 28 , & ( dqykr4eggmg . otjykwnhb3s . od5c00niot ) , sizeof (
dqykr4eggmg . otjykwnhb3s . od5c00niot ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 29 , & (
dqykr4eggmg . otjykwnhb3s . dqfv1m130o ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. dqfv1m130o ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
30 , & ( dqykr4eggmg . otjykwnhb3s . meognsjf1t ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . meognsjf1t ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 31 , & ( dqykr4eggmg . otjykwnhb3s . gcgpru4rcb ) , sizeof (
dqykr4eggmg . otjykwnhb3s . gcgpru4rcb ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 32 , & (
dqykr4eggmg . otjykwnhb3s . peklmaellz ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. peklmaellz ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
33 , & ( dqykr4eggmg . otjykwnhb3s . bsetqjfri4 ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . bsetqjfri4 ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 34 , & ( dqykr4eggmg . otjykwnhb3s . dsjbzv2lh4 ) , sizeof (
dqykr4eggmg . otjykwnhb3s . dsjbzv2lh4 ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 35 , & (
dqykr4eggmg . otjykwnhb3s . gixvkpnpus ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. gixvkpnpus ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
36 , & ( dqykr4eggmg . otjykwnhb3s . ow5xb5ovt0 ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . ow5xb5ovt0 ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 37 , & ( dqykr4eggmg . otjykwnhb3s . krs1cvkxzk ) , sizeof (
dqykr4eggmg . otjykwnhb3s . krs1cvkxzk ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 38 , & (
dqykr4eggmg . otjykwnhb3s . c4kiksmhh2 ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. c4kiksmhh2 ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
39 , & ( dqykr4eggmg . otjykwnhb3s . bbkjtf4kuy ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . bbkjtf4kuy ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 40 , & ( dqykr4eggmg . otjykwnhb3s . l3lcputuyl ) , sizeof (
dqykr4eggmg . otjykwnhb3s . l3lcputuyl ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 41 , & (
dqykr4eggmg . otjykwnhb3s . pjgu33zeph ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. pjgu33zeph ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
42 , & ( dqykr4eggmg . otjykwnhb3s . dxm3w2i52x ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . dxm3w2i52x ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 43 , & ( dqykr4eggmg . otjykwnhb3s . orkq4iljgu ) , sizeof (
dqykr4eggmg . otjykwnhb3s . orkq4iljgu ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 44 , & (
dqykr4eggmg . otjykwnhb3s . b1nmhkw4zo ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. b1nmhkw4zo ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
45 , & ( dqykr4eggmg . otjykwnhb3s . n0mydijbcx ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . n0mydijbcx ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 46 , & ( dqykr4eggmg . otjykwnhb3s . iwg03owvar ) , sizeof (
dqykr4eggmg . otjykwnhb3s . iwg03owvar ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 47 , & (
dqykr4eggmg . otjykwnhb3s . mf2pp40f5v ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. mf2pp40f5v ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
48 , & ( dqykr4eggmg . otjykwnhb3s . pwlp5beuqs ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . pwlp5beuqs ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 49 , & ( dqykr4eggmg . otjykwnhb3s . gaxgdudnvc ) , sizeof (
dqykr4eggmg . otjykwnhb3s . gaxgdudnvc ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 50 , & (
dqykr4eggmg . otjykwnhb3s . fxisjak2ua ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. fxisjak2ua ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
51 , & ( dqykr4eggmg . otjykwnhb3s . dq5lalhp1e ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . dq5lalhp1e ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 52 , & ( dqykr4eggmg . otjykwnhb3s . fpr1qi0oiw ) , sizeof (
dqykr4eggmg . otjykwnhb3s . fpr1qi0oiw ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 53 , & (
dqykr4eggmg . otjykwnhb3s . klyrn0mwhb ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. klyrn0mwhb ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
54 , & ( dqykr4eggmg . otjykwnhb3s . mfifybuxty ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . mfifybuxty ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 55 , & ( dqykr4eggmg . otjykwnhb3s . a1oodzfxvv ) , sizeof (
dqykr4eggmg . otjykwnhb3s . a1oodzfxvv ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 56 , & (
dqykr4eggmg . otjykwnhb3s . mgysgsd2g4 ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. mgysgsd2g4 ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
57 , & ( dqykr4eggmg . otjykwnhb3s . idn2v5d33m ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . idn2v5d33m ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 58 , & ( dqykr4eggmg . otjykwnhb3s . de4yc1bkky ) , sizeof (
dqykr4eggmg . otjykwnhb3s . de4yc1bkky ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 59 , & (
dqykr4eggmg . otjykwnhb3s . jd3dqtmo2p ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. jd3dqtmo2p ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
60 , & ( dqykr4eggmg . otjykwnhb3s . f1jy25gy04 ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . f1jy25gy04 ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 61 , & ( dqykr4eggmg . otjykwnhb3s . gdn4qfzvsk ) , sizeof (
dqykr4eggmg . otjykwnhb3s . gdn4qfzvsk ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 62 , & (
dqykr4eggmg . otjykwnhb3s . cqi2pi21ow ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. cqi2pi21ow ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
63 , & ( dqykr4eggmg . otjykwnhb3s . kh1khihcrt ) , sizeof ( dqykr4eggmg .
otjykwnhb3s . kh1khihcrt ) ) ; mr_flightControlSystem_cacheDataAsMxArray (
rtdwData , 0 , 64 , & ( dqykr4eggmg . otjykwnhb3s . iftedegxuv ) , sizeof (
dqykr4eggmg . otjykwnhb3s . iftedegxuv ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 65 , & (
dqykr4eggmg . otjykwnhb3s . g4zcogq4xi ) , sizeof ( dqykr4eggmg . otjykwnhb3s
. g4zcogq4xi ) ) ; mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 ,
66 , & ( dqykr4eggmg . otjykwnhb3s . ipbtas1tys . ley0an2uip ) , sizeof (
dqykr4eggmg . otjykwnhb3s . ipbtas1tys . ley0an2uip ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 67 , & (
dqykr4eggmg . otjykwnhb3s . ipbtas1tys . njk4w5jozv ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . ipbtas1tys . njk4w5jozv ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 68 , & (
dqykr4eggmg . otjykwnhb3s . bm3dpymkhz . mkkaskumzr ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . bm3dpymkhz . mkkaskumzr ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 69 , & (
dqykr4eggmg . otjykwnhb3s . bm3dpymkhz . jhr0womnye ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . bm3dpymkhz . jhr0womnye ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 70 , & (
dqykr4eggmg . otjykwnhb3s . ifzbhw4mrws . ley0an2uip ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . ifzbhw4mrws . ley0an2uip ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 71 , & (
dqykr4eggmg . otjykwnhb3s . ifzbhw4mrws . njk4w5jozv ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . ifzbhw4mrws . njk4w5jozv ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 72 , & (
dqykr4eggmg . otjykwnhb3s . phrpuocqmvu . mkkaskumzr ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . phrpuocqmvu . mkkaskumzr ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 73 , & (
dqykr4eggmg . otjykwnhb3s . phrpuocqmvu . jhr0womnye ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . phrpuocqmvu . jhr0womnye ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 74 , & (
dqykr4eggmg . otjykwnhb3s . ciy1c2o0rv . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . ciy1c2o0rv . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 75 , & (
dqykr4eggmg . otjykwnhb3s . jvbbqhrajh . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . jvbbqhrajh . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 76 , & (
dqykr4eggmg . otjykwnhb3s . clwiujjdqo . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . clwiujjdqo . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 77 , & (
dqykr4eggmg . otjykwnhb3s . acfz1zxm4t . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . acfz1zxm4t . fau3qf03xm ) ) ;
mr_flightControlSystem_cacheDataAsMxArray ( rtdwData , 0 , 78 , & (
dqykr4eggmg . otjykwnhb3s . ghadbep3bbv . fau3qf03xm ) , sizeof ( dqykr4eggmg
. otjykwnhb3s . ghadbep3bbv . fau3qf03xm ) ) ; mxSetFieldByNumber ( ssDW , 0
, 1 , rtdwData ) ; } mr_flightControlSystem_cacheDataAsMxArray ( ssDW , 0 , 2
, & ( f51itwtzkqf ) , sizeof ( f51itwtzkqf ) ) ; return ssDW ; } void
mr_flightControlSystem_SetDWork ( const mxArray * ssDW ) { ( void ) ssDW ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( ksm0js2nhsy ) , ssDW , 0
, 0 , sizeof ( ksm0js2nhsy ) ) ; { const mxArray * rtdwData =
mxGetFieldByNumber ( ssDW , 0 , 1 ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . cj12lkyakd
) , rtdwData , 0 , 0 , sizeof ( dqykr4eggmg . cj12lkyakd ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . b3ftvzsipr
) , rtdwData , 0 , 1 , sizeof ( dqykr4eggmg . b3ftvzsipr ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . ioh3emfun0
) , rtdwData , 0 , 2 , sizeof ( dqykr4eggmg . ioh3emfun0 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . ldp1hu5bce
) , rtdwData , 0 , 3 , sizeof ( dqykr4eggmg . ldp1hu5bce ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . l152eirbdu
) , rtdwData , 0 , 4 , sizeof ( dqykr4eggmg . l152eirbdu ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . a34qjyehg2
) , rtdwData , 0 , 5 , sizeof ( dqykr4eggmg . a34qjyehg2 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . kog3g2sgtz
) , rtdwData , 0 , 6 , sizeof ( dqykr4eggmg . kog3g2sgtz ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . jjrfotind4
) , rtdwData , 0 , 7 , sizeof ( dqykr4eggmg . jjrfotind4 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. mi4mocbazh ) , rtdwData , 0 , 8 , sizeof ( dqykr4eggmg . otjykwnhb3s .
mi4mocbazh ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . mtonzezz2z ) , rtdwData , 0 , 9 , sizeof (
dqykr4eggmg . otjykwnhb3s . mtonzezz2z ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ddv3ztj2wp ) , rtdwData , 0 , 10 , sizeof ( dqykr4eggmg . otjykwnhb3s .
ddv3ztj2wp ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . mh4zpxvxof ) , rtdwData , 0 , 11 , sizeof (
dqykr4eggmg . otjykwnhb3s . mh4zpxvxof ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. mlv55q4rs4 ) , rtdwData , 0 , 12 , sizeof ( dqykr4eggmg . otjykwnhb3s .
mlv55q4rs4 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . bw2ribqmwm ) , rtdwData , 0 , 13 , sizeof (
dqykr4eggmg . otjykwnhb3s . bw2ribqmwm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. pvooxnzvxd ) , rtdwData , 0 , 14 , sizeof ( dqykr4eggmg . otjykwnhb3s .
pvooxnzvxd ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . gxd2vu1ibf ) , rtdwData , 0 , 15 , sizeof (
dqykr4eggmg . otjykwnhb3s . gxd2vu1ibf ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. f2ynnmexgv ) , rtdwData , 0 , 16 , sizeof ( dqykr4eggmg . otjykwnhb3s .
f2ynnmexgv ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . h3csutamah ) , rtdwData , 0 , 17 , sizeof (
dqykr4eggmg . otjykwnhb3s . h3csutamah ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. js3ly0p0tr ) , rtdwData , 0 , 18 , sizeof ( dqykr4eggmg . otjykwnhb3s .
js3ly0p0tr ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . b3fmbw5stg ) , rtdwData , 0 , 19 , sizeof (
dqykr4eggmg . otjykwnhb3s . b3fmbw5stg ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. aq2aymvaio ) , rtdwData , 0 , 20 , sizeof ( dqykr4eggmg . otjykwnhb3s .
aq2aymvaio ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . dzwopklw3c ) , rtdwData , 0 , 21 , sizeof (
dqykr4eggmg . otjykwnhb3s . dzwopklw3c ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. d4fp3a2mpz ) , rtdwData , 0 , 22 , sizeof ( dqykr4eggmg . otjykwnhb3s .
d4fp3a2mpz ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . fl0vv44tbs ) , rtdwData , 0 , 23 , sizeof (
dqykr4eggmg . otjykwnhb3s . fl0vv44tbs ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. as5a0ikbk1 ) , rtdwData , 0 , 24 , sizeof ( dqykr4eggmg . otjykwnhb3s .
as5a0ikbk1 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . ncgo1wegzg ) , rtdwData , 0 , 25 , sizeof (
dqykr4eggmg . otjykwnhb3s . ncgo1wegzg ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. mirtkskmtr ) , rtdwData , 0 , 26 , sizeof ( dqykr4eggmg . otjykwnhb3s .
mirtkskmtr ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . jduomia1pb ) , rtdwData , 0 , 27 , sizeof (
dqykr4eggmg . otjykwnhb3s . jduomia1pb ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. od5c00niot ) , rtdwData , 0 , 28 , sizeof ( dqykr4eggmg . otjykwnhb3s .
od5c00niot ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . dqfv1m130o ) , rtdwData , 0 , 29 , sizeof (
dqykr4eggmg . otjykwnhb3s . dqfv1m130o ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. meognsjf1t ) , rtdwData , 0 , 30 , sizeof ( dqykr4eggmg . otjykwnhb3s .
meognsjf1t ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . gcgpru4rcb ) , rtdwData , 0 , 31 , sizeof (
dqykr4eggmg . otjykwnhb3s . gcgpru4rcb ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. peklmaellz ) , rtdwData , 0 , 32 , sizeof ( dqykr4eggmg . otjykwnhb3s .
peklmaellz ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . bsetqjfri4 ) , rtdwData , 0 , 33 , sizeof (
dqykr4eggmg . otjykwnhb3s . bsetqjfri4 ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. dsjbzv2lh4 ) , rtdwData , 0 , 34 , sizeof ( dqykr4eggmg . otjykwnhb3s .
dsjbzv2lh4 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . gixvkpnpus ) , rtdwData , 0 , 35 , sizeof (
dqykr4eggmg . otjykwnhb3s . gixvkpnpus ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ow5xb5ovt0 ) , rtdwData , 0 , 36 , sizeof ( dqykr4eggmg . otjykwnhb3s .
ow5xb5ovt0 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . krs1cvkxzk ) , rtdwData , 0 , 37 , sizeof (
dqykr4eggmg . otjykwnhb3s . krs1cvkxzk ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. c4kiksmhh2 ) , rtdwData , 0 , 38 , sizeof ( dqykr4eggmg . otjykwnhb3s .
c4kiksmhh2 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . bbkjtf4kuy ) , rtdwData , 0 , 39 , sizeof (
dqykr4eggmg . otjykwnhb3s . bbkjtf4kuy ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. l3lcputuyl ) , rtdwData , 0 , 40 , sizeof ( dqykr4eggmg . otjykwnhb3s .
l3lcputuyl ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . pjgu33zeph ) , rtdwData , 0 , 41 , sizeof (
dqykr4eggmg . otjykwnhb3s . pjgu33zeph ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. dxm3w2i52x ) , rtdwData , 0 , 42 , sizeof ( dqykr4eggmg . otjykwnhb3s .
dxm3w2i52x ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . orkq4iljgu ) , rtdwData , 0 , 43 , sizeof (
dqykr4eggmg . otjykwnhb3s . orkq4iljgu ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. b1nmhkw4zo ) , rtdwData , 0 , 44 , sizeof ( dqykr4eggmg . otjykwnhb3s .
b1nmhkw4zo ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . n0mydijbcx ) , rtdwData , 0 , 45 , sizeof (
dqykr4eggmg . otjykwnhb3s . n0mydijbcx ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. iwg03owvar ) , rtdwData , 0 , 46 , sizeof ( dqykr4eggmg . otjykwnhb3s .
iwg03owvar ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . mf2pp40f5v ) , rtdwData , 0 , 47 , sizeof (
dqykr4eggmg . otjykwnhb3s . mf2pp40f5v ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. pwlp5beuqs ) , rtdwData , 0 , 48 , sizeof ( dqykr4eggmg . otjykwnhb3s .
pwlp5beuqs ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . gaxgdudnvc ) , rtdwData , 0 , 49 , sizeof (
dqykr4eggmg . otjykwnhb3s . gaxgdudnvc ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. fxisjak2ua ) , rtdwData , 0 , 50 , sizeof ( dqykr4eggmg . otjykwnhb3s .
fxisjak2ua ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . dq5lalhp1e ) , rtdwData , 0 , 51 , sizeof (
dqykr4eggmg . otjykwnhb3s . dq5lalhp1e ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. fpr1qi0oiw ) , rtdwData , 0 , 52 , sizeof ( dqykr4eggmg . otjykwnhb3s .
fpr1qi0oiw ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . klyrn0mwhb ) , rtdwData , 0 , 53 , sizeof (
dqykr4eggmg . otjykwnhb3s . klyrn0mwhb ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. mfifybuxty ) , rtdwData , 0 , 54 , sizeof ( dqykr4eggmg . otjykwnhb3s .
mfifybuxty ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . a1oodzfxvv ) , rtdwData , 0 , 55 , sizeof (
dqykr4eggmg . otjykwnhb3s . a1oodzfxvv ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. mgysgsd2g4 ) , rtdwData , 0 , 56 , sizeof ( dqykr4eggmg . otjykwnhb3s .
mgysgsd2g4 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . idn2v5d33m ) , rtdwData , 0 , 57 , sizeof (
dqykr4eggmg . otjykwnhb3s . idn2v5d33m ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. de4yc1bkky ) , rtdwData , 0 , 58 , sizeof ( dqykr4eggmg . otjykwnhb3s .
de4yc1bkky ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . jd3dqtmo2p ) , rtdwData , 0 , 59 , sizeof (
dqykr4eggmg . otjykwnhb3s . jd3dqtmo2p ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. f1jy25gy04 ) , rtdwData , 0 , 60 , sizeof ( dqykr4eggmg . otjykwnhb3s .
f1jy25gy04 ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . gdn4qfzvsk ) , rtdwData , 0 , 61 , sizeof (
dqykr4eggmg . otjykwnhb3s . gdn4qfzvsk ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. cqi2pi21ow ) , rtdwData , 0 , 62 , sizeof ( dqykr4eggmg . otjykwnhb3s .
cqi2pi21ow ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . kh1khihcrt ) , rtdwData , 0 , 63 , sizeof (
dqykr4eggmg . otjykwnhb3s . kh1khihcrt ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. iftedegxuv ) , rtdwData , 0 , 64 , sizeof ( dqykr4eggmg . otjykwnhb3s .
iftedegxuv ) ) ; mr_flightControlSystem_restoreDataFromMxArray ( & (
dqykr4eggmg . otjykwnhb3s . g4zcogq4xi ) , rtdwData , 0 , 65 , sizeof (
dqykr4eggmg . otjykwnhb3s . g4zcogq4xi ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ipbtas1tys . ley0an2uip ) , rtdwData , 0 , 66 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ipbtas1tys . ley0an2uip ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ipbtas1tys . njk4w5jozv ) , rtdwData , 0 , 67 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ipbtas1tys . njk4w5jozv ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. bm3dpymkhz . mkkaskumzr ) , rtdwData , 0 , 68 , sizeof ( dqykr4eggmg .
otjykwnhb3s . bm3dpymkhz . mkkaskumzr ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. bm3dpymkhz . jhr0womnye ) , rtdwData , 0 , 69 , sizeof ( dqykr4eggmg .
otjykwnhb3s . bm3dpymkhz . jhr0womnye ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ifzbhw4mrws . ley0an2uip ) , rtdwData , 0 , 70 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ifzbhw4mrws . ley0an2uip ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ifzbhw4mrws . njk4w5jozv ) , rtdwData , 0 , 71 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ifzbhw4mrws . njk4w5jozv ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. phrpuocqmvu . mkkaskumzr ) , rtdwData , 0 , 72 , sizeof ( dqykr4eggmg .
otjykwnhb3s . phrpuocqmvu . mkkaskumzr ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. phrpuocqmvu . jhr0womnye ) , rtdwData , 0 , 73 , sizeof ( dqykr4eggmg .
otjykwnhb3s . phrpuocqmvu . jhr0womnye ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ciy1c2o0rv . fau3qf03xm ) , rtdwData , 0 , 74 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ciy1c2o0rv . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. jvbbqhrajh . fau3qf03xm ) , rtdwData , 0 , 75 , sizeof ( dqykr4eggmg .
otjykwnhb3s . jvbbqhrajh . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. clwiujjdqo . fau3qf03xm ) , rtdwData , 0 , 76 , sizeof ( dqykr4eggmg .
otjykwnhb3s . clwiujjdqo . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. acfz1zxm4t . fau3qf03xm ) , rtdwData , 0 , 77 , sizeof ( dqykr4eggmg .
otjykwnhb3s . acfz1zxm4t . fau3qf03xm ) ) ;
mr_flightControlSystem_restoreDataFromMxArray ( & ( dqykr4eggmg . otjykwnhb3s
. ghadbep3bbv . fau3qf03xm ) , rtdwData , 0 , 78 , sizeof ( dqykr4eggmg .
otjykwnhb3s . ghadbep3bbv . fau3qf03xm ) ) ; }
mr_flightControlSystem_restoreDataFromMxArray ( & ( f51itwtzkqf ) , ssDW , 0
, 2 , sizeof ( f51itwtzkqf ) ) ; } void
mr_flightControlSystem_RegisterSimStateChecksum ( SimStruct * S ) { const
uint32_T chksum [ 4 ] = { 4207692909U , 2996788235U , 453548226U ,
2253142415U , } ; slmrModelRefRegisterSimStateChecksum ( S ,
"flightControlSystem" , & chksum [ 0 ] ) ; } mxArray *
mr_flightControlSystem_GetSimStateDisallowedBlocks ( ) { mxArray * data =
mxCreateCellMatrix ( 1 , 3 ) ; mwIndex subs [ 2 ] , offset ; { static const
char * blockType [ 1 ] = { "MATLABSystem" , } ; static const char * blockPath
[ 1 ] = {
"flightControlSystem/Image Processing System/PARROT Image Conversion" , } ;
static const int reason [ 1 ] = { 3 , } ; for ( subs [ 0 ] = 0 ; subs [ 0 ] <
1 ; ++ ( subs [ 0 ] ) ) { subs [ 1 ] = 0 ; offset = mxCalcSingleSubscript (
data , 2 , subs ) ; mxSetCell ( data , offset , mxCreateString ( blockType [
subs [ 0 ] ] ) ) ; subs [ 1 ] = 1 ; offset = mxCalcSingleSubscript ( data , 2
, subs ) ; mxSetCell ( data , offset , mxCreateString ( blockPath [ subs [ 0
] ] ) ) ; subs [ 1 ] = 2 ; offset = mxCalcSingleSubscript ( data , 2 , subs )
; mxSetCell ( data , offset , mxCreateDoubleScalar ( ( double ) reason [ subs
[ 0 ] ] ) ) ; } } return data ; } static void *
flightControlSystem_InitRestoreDataPtr = NULL ; void
mr_flightControlSystem_CreateInitRestoreData ( ) {
flightControlSystem_InitRestoreDataPtr = utMalloc ( sizeof ( dqykr4eggmg ) )
; memcpy ( flightControlSystem_InitRestoreDataPtr , ( void * ) & (
dqykr4eggmg ) , sizeof ( dqykr4eggmg ) ) ; } void
mr_flightControlSystem_CopyFromInitRestoreData ( ) { memcpy ( ( void * ) & (
dqykr4eggmg ) , flightControlSystem_InitRestoreDataPtr , sizeof ( dqykr4eggmg
) ) ; } void mr_flightControlSystem_DestroyInitRestoreData ( ) { utFree (
flightControlSystem_InitRestoreDataPtr ) ; }
