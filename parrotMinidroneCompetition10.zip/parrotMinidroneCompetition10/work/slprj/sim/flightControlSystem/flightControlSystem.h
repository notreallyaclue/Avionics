#ifndef RTW_HEADER_flightControlSystem_h_
#define RTW_HEADER_flightControlSystem_h_
#include <string.h>
#include <xmmintrin.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef flightControlSystem_COMMON_INCLUDES_
#define flightControlSystem_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "slsv_diagnostic_codegen_c_api.h"
#include "sl_AsyncioQueue/AsyncioQueueCAPI.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "libmwrgb2hsv_tbb.h"
#include "sf_runtime/sfc_sdi.h"
#endif
#include "flightControlSystem_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { int8_T fau3qf03xm ; } hrtts4l5bc ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real32_T atkm3eb3zr [ 2 ] ; } orji2pbk05 ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { int8_T mkkaskumzr ; boolean_T jhr0womnye ; } imbf3wrgri ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real32_T dd1c4ibcll [ 2 ] ; } dyc32xehtl ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { int8_T ley0an2uip ; boolean_T njk4w5jozv ; } gabr0rnvjj ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real32_T pl4id4anyh_cl54gopm0x [ 16 ] ; real32_T
fswkwq0s4m_kkiq3xxxve [ 16 ] ; real32_T nz3dzltoa1_cxarnvbvui [ 12 ] ;
real32_T fncl0arrzd_bhxxfovxdy [ 9 ] ; real_T kldfwzrldv_pbm3vprmfu [ 4 ] ;
real_T glswd2nkcd_cv5hdgrwft [ 3 ] ; real_T fncl0arrzd_fqdqrf4qbc [ 3 ] ;
real_T aulvpfmy14 ; real_T azizynqh5l ; real_T ptnoncmuih ; real_T audxpwawnl
; real_T cqyqgilres ; real_T lfda2u1mt3 [ 3 ] ; real_T kcknzyt2kw [ 2 ] ;
real_T csnxbqta3d [ 2 ] ; real_T nuftjfb4tr [ 2 ] ; real_T bkasatad0l [ 2 ] ;
real_T ga0ou2qbzf [ 2 ] ; real_T gisde2u3xx [ 2 ] ; real32_T gchaygbwpg ;
real32_T bevd1uolnu ; real32_T gc1nrupvnq ; real32_T l5nzgayjhs [ 2 ] ;
real32_T cf0jaxjxfg [ 2 ] ; real32_T lbhq3ilsyd [ 4 ] ; real32_T csuamg3cf3 ;
real32_T jeehrr35n3 [ 2 ] ; real32_T dwa34yqvis [ 2 ] ; real32_T kfvbhjiqtg [
2 ] ; real32_T kyotspzhxf ; real32_T p4vhxsp0g0 [ 4 ] ; real32_T pt1nmquqmi [
2 ] ; real32_T kcihrwcew5 [ 2 ] ; real32_T aqes0fqnpu [ 2 ] ; real32_T
bhcndqqae3 [ 4 ] ; real32_T bb5sk31d0y [ 3 ] ; real32_T av0imjbvtg [ 16 ] ;
real32_T a2gs1s4oet [ 2 ] ; real32_T gijmevwnbh [ 2 ] ; real32_T bacemjpimt [
2 ] ; real32_T fpz0siyp52 [ 2 ] ; real32_T ika3nfqja0 [ 2 ] ; real32_T
bzzzmlodjb [ 2 ] ; real32_T jlzqvyfs0r [ 8 ] ; real32_T nz3dzltoa1 [ 8 ] ;
real32_T azizynqh5l_mbvzarwird [ 4 ] ; real32_T a3za0mi1jb [ 4 ] ; real32_T
n04moqscwc [ 4 ] ; real32_T bacemjpimt_jz50ptvnrg [ 4 ] ; real32_T
lrvnnrrvgx_o4f35lbcvx [ 4 ] ; real32_T fggdftcdgi_nyxm0bsxsn [ 4 ] ; real32_T
lhzpbdvr4c_g2mlkqadfk [ 4 ] ; real32_T iaoljni53q_g1smspu5ke [ 4 ] ; real_T
ljlimj0sfs_icdfyazkhu [ 2 ] ; real32_T f45tnce4lx_oyypvi4boh [ 3 ] ; real32_T
j4lqej5yyk_nvsvtgkap4 [ 3 ] ; real_T gldligh2fw ; real_T ijlsdczxaw [ 2 ] ;
real_T oxqfy2xq0w_m3yhjduhi1 ; real_T dpbek0wdwu_czkfpwuzm5 ; real_T
mxbryllu15_merlcviukg ; real_T gdm0zsnjnp_nz4o0shxby ; real_T unnamed_idx_2 ;
real_T i4wbkrxufu_idx_0 ; real_T i4wbkrxufu_idx_1 ; real_T unnamed_idx_0 ;
real_T unnamed_idx_1 ; real_T ohjru33l3t_idx_1 ; real_T glswd2nkcd_tmp ;
real_T glswd2nkcd_tmp_ppxrqq0gsf ; real_T j2224scyrs_llw0u2ae0v ; real_T
aysnllomng_jwzvbuczlb ; real_T nk5blfa0ar_dhmrxtyqop ; real32_T
hmjwwvohc0_mdoasc5av4 [ 2 ] ; real32_T bcsdzee53f_guugdwf2m3 [ 2 ] ; real32_T
ika3nfqja0_ldqodwenvz [ 2 ] ; real32_T nuftjfb4tr_dhamdvybc1 [ 2 ] ; real32_T
nsadlikv0l_dypejvacrn [ 2 ] ; real32_T mgtffanxwu_lxo5edjg3c [ 2 ] ; real32_T
gmrn2rijvh_owjr1h1vqy [ 2 ] ; real32_T oldi2l0fi3_bjbgfqrolh [ 2 ] ; real32_T
i45e32y4nf_nuebgmauvi [ 2 ] ; real32_T hjgsbndjmh ; real32_T acc1 ; real32_T
kbaevcigdn_bsqwvugooi ; real32_T dyzwxnm2fa_lnjdk5wtww ; real32_T
knhr21r5s4_hv2ho1zopz ; real32_T emslsylcj0_bnlywzniup ; real32_T
avehkh15jm_dapv3jlyq5 ; real32_T izlb01spri_ezqlmfzvpq ; real32_T
kldfwzrldv_bjvjhhzy4i ; real32_T bwlsmegbgn_idx_2 ; real32_T k5j1weseip_idx_0
; real32_T k5j1weseip_idx_1 ; real32_T k5j1weseip_idx_2 ; real32_T
gcbzmq1psk_idx_1 ; real32_T bwlsmegbgn_idx_0 ; real32_T bwlsmegbgn_idx_1 ;
real32_T mpf5fynzwe_idx_0 ; real32_T dhojtjqasu_idx_1 ; real32_T
dhojtjqasu_idx_2 ; real32_T ckkfajmco2_idx_0 ; real32_T ckkfajmco2_idx_1 ;
real32_T fhly3g0mod_idx_1 ; real32_T mcvxfa5ajb_idx_2 ; real32_T
mcvxfa5ajb_idx_1 ; real32_T fhly3g0mod_idx_2 ; real32_T ipkrnilgqg_idx_1 ;
real32_T ipkrnilgqg_idx_0 ; real32_T l0rbs1obzf_idx_2 ; real32_T
ipkrnilgqg_idx_2 ; real32_T fncl0arrzd_tmp ; real32_T jyapnrweub_jzx3amusab ;
real32_T bkasatad0l_fdinthrxmb ; real32_T n4mliatza1_al00mdgrv4 ; real32_T
cngwszwr0t_ju13rw2h0m ; int32_T cff ; int32_T denIdx ; int32_T memOffset ;
int32_T i ; uint32_T ae0r0hxav0 ; uint32_T aajdjdyozd ; uint32_T d3gcj32uev ;
real32_T ovcwn4xiv0 [ 6 ] ; real32_T dmgkungty4 ; real32_T oktwcxigco ;
uint32_T i24nn1hzbd_m3ybdk4ikc ; uint32_T b0xkfl5szj_jacdjrqyev ; uint32_T
l1woxyguei_h522xzlxvt ; uint32_T n13vzx5vsl_c0dok3111h ; uint32_T
prxhukvqog_ctvw0tpkon ; uint32_T lcb41la0m0_pxqvlbal2i ; uint16_T es1m4kbygh
; int16_T jfniqoioih ; uint16_T e1xujwyd2e_p5h3gwuwqg ; uint16_T
j4053i5eeh_afnsueciae ; uint8_T igogmbewdc ; uint8_T l0nu5qcuyl ; boolean_T
kt3nbu1y5w ; boolean_T k5l3xnpjlj ; boolean_T fr3qtkcajf ; boolean_T
pl4id4anyh ; boolean_T fn3vhnol1t_evg4t2fsev ; boolean_T
lhzpbdvr4c_ax3wx1gs5w ; boolean_T cud2lkfkrd_as0qznsxlv ; boolean_T
piutssyltq_ifotjnizh4 ; boolean_T ponrkj5gat_ltu3syw14q ; boolean_T
pg0cp3yfpb_ojunzewo4f ; boolean_T caj2lvvanz_o2tow3gxzm ; boolean_T
mnpufinffy_ipgns4eet5 ; boolean_T fin0tlxq2w_fkr0r45bcn ; boolean_T
ejwic3uv1f_izlwqhinl5 ; boolean_T bauafbz0yu_fft32lqtda ; boolean_T
amz4nxdwn1_gxhmnjv5xa ; dyc32xehtl ipbtas1tys ; orji2pbk05 bm3dpymkhz ;
dyc32xehtl ifzbhw4mrws ; orji2pbk05 phrpuocqmvu ; } eo4bbte2ey ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real_T mi4mocbazh ; real_T mtonzezz2z [ 2 ] ; real_T
ddv3ztj2wp [ 3 ] ; real_T mh4zpxvxof ; real_T mlv55q4rs4 ; real_T bw2ribqmwm
; real_T pvooxnzvxd ; real_T gxd2vu1ibf ; real_T f2ynnmexgv ; real_T
h3csutamah ; real_T js3ly0p0tr ; struct { void * LoggedData ; void *
SignalProbe ; } mpopad3fr1 ; real32_T b3fmbw5stg [ 2 ] ; real32_T aq2aymvaio
[ 3 ] ; real32_T dzwopklw3c ; real32_T d4fp3a2mpz [ 15 ] ; real32_T
fl0vv44tbs [ 2 ] ; real32_T as5a0ikbk1 [ 2 ] ; real32_T ncgo1wegzg ; real32_T
mirtkskmtr ; real32_T jduomia1pb [ 5 ] ; real32_T od5c00niot [ 4 ] ; real32_T
dqfv1m130o [ 10 ] ; real32_T meognsjf1t [ 2 ] ; real32_T gcgpru4rcb [ 2 ] ;
real32_T peklmaellz [ 2 ] ; real32_T bsetqjfri4 ; real32_T dsjbzv2lh4 [ 2 ] ;
real32_T gixvkpnpus [ 2 ] ; real32_T ow5xb5ovt0 [ 2 ] ; real32_T krs1cvkxzk [
2 ] ; real32_T c4kiksmhh2 ; int32_T bbkjtf4kuy ; uint32_T l3lcputuyl ;
uint32_T pjgu33zeph ; uint32_T dxm3w2i52x ; real32_T orkq4iljgu ; real32_T
b1nmhkw4zo ; real32_T n0mydijbcx ; real32_T iwg03owvar ; real32_T mf2pp40f5v
[ 2 ] ; real32_T pwlp5beuqs [ 2 ] ; uint16_T gaxgdudnvc ; uint8_T fxisjak2ua
; int8_T dq5lalhp1e ; int8_T fpr1qi0oiw ; int8_T klyrn0mwhb ; int8_T
mfifybuxty ; int8_T a1oodzfxvv ; int8_T mgysgsd2g4 ; int8_T idn2v5d33m ;
uint8_T de4yc1bkky ; uint8_T jd3dqtmo2p ; uint8_T f1jy25gy04 ; uint8_T
gdn4qfzvsk ; boolean_T cqi2pi21ow ; boolean_T kh1khihcrt ; boolean_T
iftedegxuv ; boolean_T g4zcogq4xi ; gabr0rnvjj ipbtas1tys ; imbf3wrgri
bm3dpymkhz ; gabr0rnvjj ifzbhw4mrws ; imbf3wrgri phrpuocqmvu ; hrtts4l5bc
ciy1c2o0rv ; hrtts4l5bc jvbbqhrajh ; hrtts4l5bc clwiujjdqo ; hrtts4l5bc
acfz1zxm4t ; hrtts4l5bc ghadbep3bbv ; } dmp1xsadgu ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real_T b3ouxrig41 ; } k5baggiqtb ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { ZCSigState b1rw3rggh2 ; } ph1mky0ofs ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { real_T hsv [ 57600 ] ; real_T o2lyn0kysk [ 19200 ] ; uint8_T
imgRGB [ 57600 ] ; uint8_T b_varargout_3 [ 19200 ] ; uint8_T b_varargout_2 [
19200 ] ; uint8_T b_varargout_1 [ 19200 ] ; boolean_T jyj4vjw1db [ 19200 ] ;
int16_T inSize [ 8 ] ; real_T eavemda1lk_mbvzarwird [ 2 ] ; real_T
nrf0fqeiex_cl54gopm0x [ 2 ] ; real_T py4lbfe4av ; real_T centroid_idx_1 ;
real_T centroid_idx_0 ; int32_T iy ; int32_T pixListNinc ; int32_T ns ;
int32_T ms ; int32_T numLoops ; int32_T p ; int32_T idx ; int32_T n ; int32_T
i ; int32_T b_k ; uint32_T pixIdx ; uint32_T start_pixIdx ; uint32_T
walkerIdx ; uint32_T centerIdx ; uint32_T padIdx ; uint8_T currentLabel ;
boolean_T maxNumBlobsReached ; eo4bbte2ey otjykwnhb3s ; } ircitwx3zdm ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { uint32_T cj12lkyakd [ 19200 ] ; int16_T b3ftvzsipr [ 19200 ]
; int16_T ioh3emfun0 [ 19200 ] ; uint8_T ldp1hu5bce [ 19764 ] ; bjqsgn0csy
l152eirbdu ; real_T a34qjyehg2 ; uint32_T kog3g2sgtz ; boolean_T jjrfotind4 ;
dmp1xsadgu otjykwnhb3s ; } nllkaxiwhzw ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { k5baggiqtb otjykwnhb3s ; } h5liyesltnn ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { ph1mky0ofs otjykwnhb3s ; } cspyln32yuv ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct bpvdgm2xq5_ { uint8_T P_0 ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct je33m1dqwd_ { real32_T P_0 ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct fpqg1jdlo0_ { real32_T P_0 ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct nu4qaxumex_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ;
real_T P_4 ; real_T P_5 ; real_T P_6 ; real32_T P_7 [ 2 ] ; real32_T P_8 [ 2
] ; real32_T P_9 ; real32_T P_10 ; real32_T P_11 ; real32_T P_12 ; real32_T
P_13 ; real32_T P_14 ; real32_T P_15 ; real32_T P_16 ; real32_T P_17 [ 2 ] ;
real32_T P_18 ; real32_T P_19 ; real32_T P_20 ; real32_T P_21 [ 2 ] ;
real32_T P_22 ; real32_T P_23 ; real32_T P_24 ; real32_T P_25 ; real32_T P_26
; real32_T P_27 ; real32_T P_28 ; real32_T P_29 ; real32_T P_30 ; real32_T
P_31 ; real32_T P_32 ; real32_T P_33 ; real32_T P_34 ; real32_T P_35 ;
real32_T P_36 ; real32_T P_37 ; real32_T P_38 ; real32_T P_39 ; real32_T P_40
; real32_T P_41 ; real32_T P_42 ; real32_T P_43 ; real32_T P_44 ; real32_T
P_45 ; real32_T P_46 ; uint32_T P_47 ; uint32_T P_48 ; uint32_T P_49 ;
uint32_T P_50 ; uint32_T P_51 ; uint16_T P_52 ; uint16_T P_53 ; real_T P_54 ;
real_T P_55 ; real_T P_56 ; real_T P_57 ; real_T P_58 [ 4 ] ; real_T P_59 [ 4
] ; real_T P_60 ; real_T P_61 ; real_T P_62 ; real_T P_63 ; real_T P_64 ;
real_T P_65 ; real_T P_66 ; real_T P_67 [ 2 ] ; real_T P_68 ; real_T P_69 ;
real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T P_73 ; real_T P_74 ; real_T
P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ; real_T P_79 ; real_T P_80 [
4 ] ; real_T P_81 [ 2 ] ; real_T P_82 [ 2 ] ; real_T P_83 [ 4 ] ; real_T P_84
[ 2 ] ; real_T P_85 [ 2 ] ; real_T P_86 ; real_T P_87 [ 4 ] ; real_T P_88 [ 2
] ; real_T P_89 ; real_T P_90 ; real_T P_91 ; real_T P_92 ; real_T P_93 [ 2 ]
; real_T P_94 [ 3 ] ; real_T P_95 [ 4 ] ; real_T P_96 [ 2 ] ; real_T P_97 [ 2
] ; real_T P_98 [ 4 ] ; real_T P_99 [ 2 ] ; real_T P_100 [ 2 ] ; real_T P_101
; real_T P_102 [ 3 ] ; real_T P_103 [ 16 ] ; real_T P_104 [ 8 ] ; real_T
P_105 [ 8 ] ; real32_T P_106 ; real32_T P_107 ; real32_T P_108 ; real32_T
P_109 [ 2 ] ; real32_T P_110 ; real32_T P_111 ; real32_T P_112 ; real32_T
P_113 ; real32_T P_114 ; real32_T P_115 ; real32_T P_116 ; real32_T P_117 ;
real32_T P_118 ; real32_T P_119 ; real32_T P_120 ; real32_T P_121 ; real32_T
P_122 [ 4 ] ; real32_T P_123 [ 4 ] ; real32_T P_124 ; real32_T P_125 ;
real32_T P_126 ; real32_T P_127 [ 6 ] ; real32_T P_128 [ 6 ] ; real32_T P_129
; real32_T P_130 [ 6 ] ; real32_T P_131 ; real32_T P_132 [ 2 ] ; real32_T
P_133 [ 2 ] ; real32_T P_134 ; real32_T P_135 [ 2 ] ; real32_T P_136 [ 2 ] ;
real32_T P_137 ; real32_T P_138 [ 6 ] ; real32_T P_139 [ 6 ] ; real32_T P_140
; real32_T P_141 ; real32_T P_142 [ 6 ] ; real32_T P_143 [ 6 ] ; real32_T
P_144 ; real32_T P_145 ; real32_T P_146 ; real32_T P_147 ; real32_T P_148 ;
real32_T P_149 ; real32_T P_150 ; real32_T P_151 ; real32_T P_152 ; real32_T
P_153 ; real32_T P_154 ; real32_T P_155 ; real32_T P_156 ; real32_T P_157 [ 2
] ; real32_T P_158 [ 2 ] ; real32_T P_159 ; real32_T P_160 ; real32_T P_161 ;
real32_T P_162 ; real32_T P_163 ; real32_T P_164 ; real32_T P_165 ; real32_T
P_166 ; real32_T P_167 ; real32_T P_168 ; real32_T P_169 ; real32_T P_170 ;
real32_T P_171 ; real32_T P_172 ; real32_T P_173 ; real32_T P_174 [ 4 ] ;
real32_T P_175 ; real32_T P_176 ; real32_T P_177 ; real32_T P_178 [ 16 ] ;
real32_T P_179 ; real32_T P_180 ; real32_T P_181 [ 4 ] ; real32_T P_182 [ 2 ]
; real32_T P_183 [ 2 ] ; real32_T P_184 ; real32_T P_185 [ 4 ] ; real32_T
P_186 [ 4 ] ; real32_T P_187 [ 2 ] ; real32_T P_188 [ 2 ] ; real32_T P_189 [
4 ] ; real32_T P_190 ; real32_T P_191 [ 2 ] ; real32_T P_192 [ 4 ] ; real32_T
P_193 [ 2 ] ; real32_T P_194 [ 2 ] ; real32_T P_195 ; real32_T P_196 [ 4 ] ;
real32_T P_197 [ 4 ] ; real32_T P_198 [ 2 ] ; real32_T P_199 [ 2 ] ; real32_T
P_200 [ 4 ] ; real32_T P_201 ; real32_T P_202 [ 2 ] ; real32_T P_203 ;
real32_T P_204 ; real32_T P_205 [ 16 ] ; real32_T P_206 [ 8 ] ; real32_T
P_207 [ 8 ] ; real32_T P_208 [ 4 ] ; real32_T P_209 [ 16 ] ; real32_T P_210 [
16 ] ; real32_T P_211 [ 8 ] ; real32_T P_212 [ 8 ] ; real32_T P_213 [ 16 ] ;
real32_T P_214 [ 4 ] ; real32_T P_215 [ 4 ] ; uint32_T P_216 ; uint32_T P_217
; uint32_T P_218 ; uint32_T P_219 ; uint32_T P_220 ; uint32_T P_221 ;
uint32_T P_222 ; uint32_T P_223 ; uint32_T P_224 ; uint16_T P_225 ; uint16_T
P_226 ; uint16_T P_227 ; boolean_T P_228 ; boolean_T P_229 ; uint8_T P_230 ;
uint8_T P_231 ; uint8_T P_232 ; uint8_T P_233 ; uint8_T P_234 ; fpqg1jdlo0
ipbtas1tys ; je33m1dqwd bm3dpymkhz ; fpqg1jdlo0 ifzbhw4mrws ; je33m1dqwd
phrpuocqmvu ; bpvdgm2xq5 ciy1c2o0rv ; bpvdgm2xq5 jvbbqhrajh ; bpvdgm2xq5
clwiujjdqo ; bpvdgm2xq5 acfz1zxm4t ; bpvdgm2xq5 ghadbep3bbv ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct ileg2v2ld1r_ { real_T P_1 ; uint32_T P_2 ; uint16_T P_3 ; real_T P_4 ;
real_T P_5 ; real_T P_6 ; real_T P_7 [ 2 ] ; real_T P_8 ; nu4qaxumex
otjykwnhb3s ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
struct diqjpw4041 { struct SimStruct_tag * _mdlRefSfcnS ; struct {
rtwCAPI_ModelMappingInfo mmi ; rtwCAPI_ModelMapLoggingInstanceInfo
mmiLogInstanceInfo ; void * dataAddress [ 34 ] ; int32_T * vardimsAddress [
34 ] ; RTWLoggingFcnPtr loggingPtrs [ 34 ] ; sysRanDType * systemRan [ 29 ] ;
int_T systemTid [ 29 ] ; } DataMapInfo ; } ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
typedef struct { ipf5ube4r0 rtm ; } lhjbdsj2rjg ;
#endif
extern struct_8SSZ93PxvPkADZcA4gG8MD rtP_Sensors ; extern void ha1ipjbq54 (
uint8_T * o3vpgniqky ) ; extern void gwlyno50ln ( void ) ; extern void
k3yxem35zg ( void ) ; extern void bog0frvixl ( void ) ; extern void
pyvd4pdf3i ( void ) ; extern void pyvd4pdf3iTID1 ( void ) ; extern void
flightControlSystem ( const CommandBus * iarztl0jur , const SensorsBus *
pxdb2gu5va , real32_T pikqq4svts [ 4 ] , uint8_T * o3vpgniqky ) ; extern void
flightControlSystemTID1 ( void ) ; extern void o2f5l50guo ( void ) ; extern
void f4qzdbbxmw ( SimStruct * _mdlRefSfcnS , int_T mdlref_TID0 , int_T
mdlref_TID1 , void * sysRanPtr , int contextTid , rtwCAPI_ModelMappingInfo *
rt_ParentMMI , const char_T * rt_ChildPath , int_T rt_ChildMMIIdx , int_T
rt_CSTATEIdx ) ; extern void mr_flightControlSystem_MdlInfoRegFcn ( SimStruct
* mdlRefSfcnS , char_T * modelName , int_T * retVal ) ; extern mxArray *
mr_flightControlSystem_GetDWork ( ) ; extern void
mr_flightControlSystem_SetDWork ( const mxArray * ssDW ) ; extern void
mr_flightControlSystem_RegisterSimStateChecksum ( SimStruct * S ) ; extern
mxArray * mr_flightControlSystem_GetSimStateDisallowedBlocks ( ) ; extern
const rtwCAPI_ModelMappingStaticInfo * flightControlSystem_GetCAPIStaticMap (
void ) ;
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
extern void ghadbep3bb ( uint8_T * hfpztkhwej , bpvdgm2xq5 * localP ) ;
extern void gcledvfwzt ( orji2pbk05 * localB , je33m1dqwd * localP ) ; extern
void alfdzl2fz1 ( orji2pbk05 * localB , imbf3wrgri * localDW , je33m1dqwd *
localP ) ; extern void phrpuocqmv ( ipf5ube4r0 * const accn4cnket , boolean_T
hjrswm4ob0 , const real32_T ndqlqfbq0n [ 2 ] , real32_T pp4ryk1bnn , const
real32_T crftt4mdlv [ 2 ] , const real32_T pc1pu0u41d [ 2 ] , real32_T
kemszrfmdj , real32_T k3tun14l4o , orji2pbk05 * localB , imbf3wrgri * localDW
, je33m1dqwd * localP ) ; extern void e0j2slboh1 ( dyc32xehtl * localB ,
fpqg1jdlo0 * localP ) ; extern void ng2z3yysbc ( dyc32xehtl * localB ,
gabr0rnvjj * localDW , fpqg1jdlo0 * localP ) ; extern void ifzbhw4mrw (
ipf5ube4r0 * const accn4cnket , boolean_T ny1m4yhfkt , const real32_T
izmwj1ddpc [ 2 ] , const real32_T fppyei0jac [ 2 ] , real32_T fjag4trd4p ,
const real32_T fn1cyjs1o0 [ 2 ] , dyc32xehtl * localB , gabr0rnvjj * localDW
, fpqg1jdlo0 * localP ) ; extern void ic5jb3movn ( eo4bbte2ey * localB ,
dmp1xsadgu * localDW , nu4qaxumex * localP ) ; extern void bxsrqc204k (
dmp1xsadgu * localDW , nu4qaxumex * localP ) ; extern void kegjp2lgms (
eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex * localP ) ; extern
void lsjhvu4egy ( eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex *
localP ) ; extern void otjykwnhb3 ( ipf5ube4r0 * const accn4cnket , const
CommandBus * ipxpc4eli1 , const SensorsBus * fp0u5nlpgw , const real_T
ay1xsyaztb [ 2 ] , eo4bbte2ey * localB , dmp1xsadgu * localDW , nu4qaxumex *
localP , ph1mky0ofs * localZCE ) ; extern void otjykwnhb3TID1 ( eo4bbte2ey *
localB , nu4qaxumex * localP ) ;
#endif
void mr_flightControlSystem_CreateInitRestoreData ( ) ; void
mr_flightControlSystem_CopyFromInitRestoreData ( ) ; void
mr_flightControlSystem_DestroyInitRestoreData ( ) ;
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
extern lhjbdsj2rjg lhjbdsj2rj ;
#endif
#ifndef flightControlSystem_MDLREF_HIDE_CHILD_
extern ircitwx3zdm ksm0js2nhsy ; extern nllkaxiwhzw dqykr4eggmg ; extern
cspyln32yuv f51itwtzkqf ;
#endif
#endif
